package com.orparga.electricplan;

import android.content.Context;
import android.content.res.Resources;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.provider.DocumentsContract;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewParent;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;

import static android.content.Context.LAYOUT_INFLATER_SERVICE;

public class Row_Import_Plane extends LinearLayout {
    Row_Import_Plane_Manager summoner;
    Row_Import_Plane this_row;
    Context context;
    Uri uri;
    LayoutInflater inflater;
    ArrayList<String>projectList;
    Select_Project_Spinner_Adapter select_project_spinner_adapter;
    protected View tagContainer;
    Button accept;
    private String[] TAGS_Sugested;
    protected ArrayList<String> TagsCreated;public ArrayList<String> getTagsCreated (){
        return (ArrayList<String>)TagsCreated.clone();}
        protected boolean bNewVersion=false;public boolean getbNewVersion(){return bNewVersion;}
    protected boolean bMoreOptions=false;public boolean getbMoreOptions(){return bMoreOptions;}
        protected String planeName="";public String getPlaneName(){return planeName;}
    protected int versionNumber =0;public int getVersionNumber() {
        return versionNumber;
    }
    protected String projectName="";public String getProjectName() {
        return projectName;
    }
    protected String subFoldersString ="";public String getSubFoldersString() {
        return subFoldersString;
    }
    protected String fileName_without_extension ="";
    public String getFileName_without_extension() {
        return fileName_without_extension;
    }
    protected String extension="";public String getExtension(){return extension;}
    protected String fileName_from_intentSend="";public String getFileName_from_intentSend() {
        return fileName_from_intentSend;
    }
    protected Plane planeAccepted;public Plane getPlaneAccepted() {
        return planeAccepted;
    }
    protected AutoCompleteTextView tagView;
    View.OnClickListener onDeleteListener =new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            onClickDelete(v);
        }
    };
    View.OnClickListener onOKListener=new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            onClickOK(v);
        }
    };
    View.OnClickListener onMasOpcionesListener=new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            onClickMasOpciones(v);
        }
    };
    View.OnClickListener onDescartarListener=new OnClickListener() {
        @Override
        public void onClick(View v) {summoner.row_plane_declined(this_row);
        }
    };
    CheckBox.OnCheckedChangeListener onCheckedChange_planeVersion =new CompoundButton.OnCheckedChangeListener() {
        @Override
        public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
            TextView txt_Plane=findViewById(R.id.row_import_plane_txt_plane_name);
            Spinner spi_Plane=findViewById(R.id.row_import_plane_spinner_plane);

            if(isChecked){
                ArrayList<Plane> planeList=IniSpinner_Plane(null);
                IniTagListFromPlane((Plane)spi_Plane.getSelectedItem());
                txt_Plane.setVisibility(GONE);
                spi_Plane.setVisibility(VISIBLE);
            }
            else{
                txt_Plane.setVisibility(VISIBLE);
                spi_Plane.setVisibility(GONE);

            }

        }
    };

    private void IniTagListFromPlane(Plane selectedItem) {
        TagsCreated=new ArrayList<String>();
        //busca la zona de la "Ficha" dode el usuario podrá introducir los Tags de búsqueda rápida
        LinearLayout tagListContainer=findViewById(R.id.tag_list_container);
        tagListContainer.removeAllViews();

        for(Tag tag:selectedItem.tagList){
            TagsCreated.add(tag.Name);
            FixTagView(tag.Name,tagListContainer);
        }
        addNewTagView(tagListContainer);
    }

    AdapterView.OnItemSelectedListener onPlaneSelectedListener=new AdapterView.OnItemSelectedListener() {
        @Override
        public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
            Plane planeSelected=(Plane)parent.getItemAtPosition(position);
            IniTagListFromPlane(planeSelected);
        }

        @Override
        public void onNothingSelected(AdapterView<?> parent) {

        }
    };
    AdapterView.OnItemSelectedListener onFolderSelectedListener=new AdapterView.OnItemSelectedListener() {
        @Override
        public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
            LinearLayout ll_newFolderName = findViewById(R.id.row_import_plane_ll_new_folder_name);
            if (position == 0) {
                ll_newFolderName.setVisibility(VISIBLE);
                EditText txtNewFolderName = ll_newFolderName.findViewById(R.id.row_import_plane_txt_new_folder_name);
                if (txtNewFolderName.requestFocus()) {
                    InputMethodManager imm = (InputMethodManager) context.getSystemService(Context.INPUT_METHOD_SERVICE);
                    imm.showSoftInput(txtNewFolderName, InputMethodManager.SHOW_IMPLICIT);
                }
            } else {
                ll_newFolderName.setVisibility(GONE);
            }
        }

        @Override
        public void onNothingSelected(AdapterView<?> parent) {

        }
    };
    AdapterView.OnItemSelectedListener onProjectSelectedListener=new AdapterView.OnItemSelectedListener() {
        @Override
        public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
            LinearLayout ll_newProjectName = findViewById(R.id.row_import_plane_ll_new_project_name);
            LinearLayout ll_selectFolder = findViewById(R.id.row_import_plane_ll_select_folder);
            CheckBox chkPlane = findViewById(R.id.row_import_plane_check_version);
            if (position == 0) {
                //Si el usuario selecciona la opción "nuevo proyecto"
                //Primero, Visualiza el view para introducir un nombre de proyecto
                ll_newProjectName.setVisibility(VISIBLE);
                EditText txtProjectName = ll_newProjectName.findViewById(R.id.row_import_plane_txt_new_project_name);
                if (txtProjectName.requestFocus()) {
                    InputMethodManager imm = (InputMethodManager) context.getSystemService(Context.INPUT_METHOD_SERVICE);
                    imm.showSoftInput(txtProjectName, InputMethodManager.SHOW_IMPLICIT);
                }
                //Segundo, oculta la zona destinada a seleccionar una carpeta dentro del proyecto
                ll_selectFolder.setVisibility(GONE);
                //Tercero, desactiva el checkbox que permite seleccionar un plano existente dentro del proyecto
                 chkPlane.setChecked(false);
                chkPlane.setVisibility(GONE);
            } else {
                //Si el usuario selecciona un proyecto existente
                ll_newProjectName.setVisibility(GONE);
                ll_selectFolder.setVisibility(VISIBLE);
                //Visualiza el checkBox "nueva version de plano existente" solo si "mas opciones" está activo
                LinearLayout ll_masOpciones=findViewById(R.id.row_import_plane_ll_opciones_extra);
                if(ll_masOpciones.isShown()) {
                    chkPlane.setVisibility(VISIBLE);
                }
                else {
                    chkPlane.setVisibility(GONE);

                }
                //por defecto, el plano NO es una version de un plano existente.
                chkPlane.setChecked(false);

            }
            String selected_project_spinner_adapter = (String) parent.getItemAtPosition(position);
            IniSpinner_Folder(selected_project_spinner_adapter);
        }

        @Override
        public void onNothingSelected(AdapterView<?> parent) {

        }
    };
    View.OnClickListener onAceptarListener=new OnClickListener() {
        @Override
        public void onClick(View v) {
            {
                //Guarda el estado del linearLayout "Mas opciones"
                LinearLayout ll_MoreOptions= findViewById(R.id.row_import_plane_ll_opciones_extra);
                if(ll_MoreOptions.getVisibility()==VISIBLE)bMoreOptions=false;
                else bMoreOptions=true;

                //Guarda el estado del checkbox "nueva version de plano existente"
                CheckBox chkNuevaVersion=findViewById(R.id.row_import_plane_check_version);
                bNewVersion=chkNuevaVersion.isChecked();

                //Guarda el nombre del plano
                if(bNewVersion)
                {
                    planeName=((Plane)((Spinner)findViewById(R.id.row_import_plane_spinner_plane)).getSelectedItem()).Name;
                }
                else{
                    planeName = ((EditText) this_row.findViewById(R.id.row_import_plane_txt_plane_name)).getText().toString();
                }
                planeAccepted = new Plane(planeName);
                String reducedPath = getReducedPath_From_Uri(uri);
                PlaneVersion planeVersion = new PlaneVersion(reducedPath);

                //Guarda el listado de Tags... guardado en TagsCreated

                //Guarda el nombre del proyecto escogido
                Spinner spnProject=findViewById(R.id.row_imported_plane_project_spinner);
                if(spnProject.getSelectedItemPosition()==0){
                    EditText txtProject=findViewById(R.id.row_import_plane_txt_new_project_name);
                    projectName=txtProject.getText().toString();
                    summoner.row_new_project_requested(this_row);
                }
                else projectName=(String)spnProject.getSelectedItem();
                //guada el subdirectorio escogido
                subFoldersString ="";
                Spinner spnFolder=findViewById(R.id.row_import_plane_spinner_folder);
                if(spnFolder.getSelectedItemPosition()==0){
                    EditText txtFolder=findViewById(R.id.row_import_plane_txt_new_folder_name);
                    projectName=txtFolder.getText().toString();
                }
                else projectName=(String)spnFolder.getSelectedItem();
                //guarda el nombre del archivo escogido para el plano
                EditText txtFile=findViewById(R.id.row_import_plane_txt_new_filename);
                TextView txtExtension=findViewById(R.id.row_import_plane_txt_extension);
                fileName_without_extension =txtFile.getText().toString();
                extension=txtExtension.getText().toString();
                //guarda el nombre recibido en el intent a traes de la Uri
                fileName_from_intentSend=getReducedPath_From_Uri(uri);
                summoner.row_plane_accepted(this_row);


            }
    }};
    View.OnKeyListener onKey_TagView =new View.OnKeyListener() {
        public boolean onKey(View v, int keyCode, KeyEvent event) {
            {
            // If the event is a key-down event on the "enter" button
            if (event.getAction() == KeyEvent.ACTION_DOWN)
            {
                String textTAG=((AutoCompleteTextView)v).getText().toString().toLowerCase();
                int index=TagsCreated.indexOf(textTAG);
                TextView errorText=findViewById(R.id.text_error_row_imported_plane);
                ImageView okView=findViewById(R.id.row_new_tag_btn_ok);
                if(index==-1)
                {
                    errorText.setVisibility(View.INVISIBLE);
                    okView.setVisibility(View.VISIBLE);
                    //Si no está en la lista permite el nuevo Tag
                    if (keyCode == KeyEvent.KEYCODE_ENTER) {
                        // Perform action on key press
                        TagsCreated.add(textTAG);
                        ViewParent row_new_tag_current=v.getParent();
                        ViewParent tag_list_container_current=row_new_tag_current.getParent();
                        FixTagView(textTAG,((LinearLayout)tag_list_container_current));

                        addNewTagView((LinearLayout)tag_list_container_current);
                        return true;
                    }
                }
                //Si el tag está ya está en la lista
                //muestra un mensaje de error
                Resources res=context.getResources();
                errorText.setText(res.getString(R.string.activity_add_file_3_text_error_A)+" "
                        +textTAG+" "
                        +res.getString(R.string.activity_add_file_3_text_error_B));
                errorText.setVisibility(View.VISIBLE);
                okView.setVisibility(View.INVISIBLE);
                return true;

            }
            return false;
        }
    }};
    TextWatcher textWatcher_tagView =new TextWatcher() {

        public void afterTextChanged(Editable s) {
            String textTAG=s.toString().toLowerCase();
            int index=TagsCreated.indexOf(textTAG);
            TextView errorText=findViewById(R.id.text_error_row_imported_plane);
            ImageView okView=findViewById(R.id.row_new_tag_btn_ok);

            if(index!=-1)
            {
                //Si el tag está ya está en la lista
                //muestra un mensaje de error
                Resources res=context.getResources();
                if(errorText!=null) {
                    errorText.setText(res.getString(R.string.activity_add_file_3_text_error_A) + " "
                            + textTAG + " "
                            + res.getString(R.string.activity_add_file_3_text_error_B));
                    errorText.setVisibility(View.VISIBLE);
                }
                if(okView!=null)okView.setVisibility(View.INVISIBLE);
            }
            else {
                //Si no está en la lista permite el nuevo Tag
                if(errorText!=null)errorText.setVisibility(View.INVISIBLE);
                if(okView!=null)okView.setVisibility(View.VISIBLE);
            }
        }

        public void beforeTextChanged(CharSequence s, int start, int count, int after) {

        }

        public void onTextChanged(CharSequence s, int start, int before, int count) {
        }
    };

    OnKeyListener onKey_NewProjectName=new OnKeyListener() {
        @Override
        public boolean onKey(View v, int keyCode, KeyEvent event) {
            {// If the event is a key-down event on the "enter" button
            if (event.getAction() == KeyEvent.ACTION_DOWN)
            {
                String newProjectName=((EditText)v).getText().toString().toLowerCase();
                TextView errorText=findViewById(R.id.row_imported_plane_txt_projectName_error);
                if(accept==null)accept=(Button)findViewById(R.id.row_import_plane_ll_btn_OK);
                switch (CHECK_PROJECT_NAME_RETURN_VALUE.checkProjectName(PassingData.GENERAL_FOLDER_NAME,newProjectName))
                {

                    case OK:
                        errorText.setVisibility(GONE);
                        accept.setEnabled(true);
                        break;
                    case TOO_SHORT:
                        errorText.setText(context.getResources().getString(R.string.row_imported_plane_nuevo_proyecto_error_empty));
                        errorText.setVisibility(VISIBLE);
                        accept.setEnabled(false);
                        break;
                    case ALREADY_EXISTS:
                        errorText.setText(context.getResources().getString(R.string.row_imported_plane_nuevo_proyecto_error_exists));
                        errorText.setVisibility(VISIBLE);
                        accept.setEnabled(false);
                        break;
                    case INVALID_CARACTERES:
                        errorText.setText(context.getResources().getString(R.string.row_imported_plane_nuevo_proyecto_error_caracteres));
                        errorText.setVisibility(VISIBLE);
                        accept.setEnabled(false);
                        break;
                }
                return true;

            }
            return false;
        }}
    };
    /**
     * si el usuario está introduciendo un nombre nuevo de proyecto, la app
     * todavía no muede saber que qué directorio almacenar el plano, así que
     * oculta el LinearLayout destinado a seleccionar dicho directorio
     */
    OnFocusChangeListener onFocus_NewProjectName= new OnFocusChangeListener() {
        @Override
        public void onFocusChange(View v, boolean hasFocus) {
            EditText newProjectName = findViewById(R.id.row_import_plane_txt_new_project_name);
            if (hasFocus) {
                //Si el usuario está introduciendo un nombre de proyecto, oculta el selector de directorio
                LinearLayout ll_Select_Folder = findViewById(R.id.row_import_plane_ll_select_folder);
                ll_Select_Folder.setVisibility(GONE);
            } else {
                //Si el usuario ha acabado, visualiza el selector de directorio
                String strNewProjectName = ((EditText) v).getText().toString().toLowerCase();

                switch (CHECK_PROJECT_NAME_RETURN_VALUE.checkProjectName(PassingData.GENERAL_FOLDER_NAME, strNewProjectName)) {

                    case OK:
                        IniSpinner_Folder(strNewProjectName);
                        LinearLayout ll_Select_Folder = findViewById(R.id.row_import_plane_ll_select_folder);
                        ll_Select_Folder.setVisibility(VISIBLE);
                        break;
                }
            }
        }
    };
    public Row_Import_Plane(Context context, Uri uri,Row_Import_Plane_Manager summoner) {
        super(context);
        this.context=context;
        this.summoner=summoner;
        this.uri=uri;
        this_row=this;
        inflater = (LayoutInflater)context.getSystemService(LAYOUT_INFLATER_SERVICE);

        LayoutInflater.from(getContext()).inflate(
                R.layout.row_import_plane, this);

        IniImage();
        IniPlaneName();
        IniTags();
        IniButons();
        IniSpinner_Project();
        IniSpinner_Folder(null);
        IniTXT_File();
        IniTXT_Extension();

    }
    private void IniImage(){

        //Añade un espacio para previsualizar la plano en proceso de importacion (PPI)
        ImageView imageView=findViewById(R.id.intent_receive_plane_image);
        //imageView.setImageURI(null);
        imageView.setImageURI(uri);
        //Debido a una pifiada de los chicos de google...
        //la altura de la imagen debe ser recalculada después
        //de ser añadida al imageView
        adjustBitmapHeight(imageView,uri);

    }
    private void IniTags(){
        TAGS_Sugested=getResources().getStringArray(R.array.tag_sugestions);
        TagsCreated=new ArrayList<String>();
//busca la zona de la "Ficha" dode el usuario podrá introducir los Tags de búsqueda rápida
        LinearLayout tagListContainer=findViewById(R.id.tag_list_container);
        addNewTagView(tagListContainer);

    }
    private void IniPlaneName(){
        //Crea un nombre inicial para el PPI basado en el nombre del archivo recibido y lo presenta
        //en un control de texto editable
        String Path=uri.getPath();
        String planeName;
        int slash=Path.lastIndexOf('/');
        int dot=Path.lastIndexOf('.');
        if((dot!=-1)&&(slash!=-1))
        {
            planeName=Path.substring(slash+1,dot);
        }
        else
        {
            planeName="default";
        }
        EditText newName_EditText=findViewById(R.id.row_import_plane_txt_plane_name);
        newName_EditText.setText(planeName);

        //Inicializa los eventos del checkbox "nueva version de plano existente"
        CheckBox chkVersion=findViewById(R.id.row_import_plane_check_version);
        chkVersion.setOnCheckedChangeListener(onCheckedChange_planeVersion);
    }
    private void cosaRara (Uri uri){
        String realPath="";
        String wholeID = DocumentsContract.getDocumentId(uri);
        // Split at colon, use second item in the array
        String id = wholeID.split(":")[1];
        String[] column = { MediaStore.Images.Media.DATA };
        // where id is equal to
        String sel = MediaStore.Images.Media._ID + "=?";
        Cursor cursor = context.getContentResolver().query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, column, sel, new String[]{ id }, null);
        int columnIndex = 0;
        if (cursor != null) {
            columnIndex = cursor.getColumnIndex(column[0]);
            if (cursor.moveToFirst()) {
                realPath = cursor.getString(columnIndex);
            }
            cursor.close();
        }
    }
    private void IniButons(){
        //Busca los botones para añadirles los eventos "onClick"
        TextView masOpciones=findViewById(R.id.row_import_plane_mas_opciones);
        masOpciones.setOnClickListener(onMasOpcionesListener);
        if(accept==null)accept=(Button)findViewById(R.id.row_import_plane_ll_btn_OK);
        accept.setOnClickListener(onAceptarListener);
        Button discart=findViewById(R.id.row_import_plane_ll_btn_Discart);
        discart.setOnClickListener(onDescartarListener);

    }
    private void IniSpinner_Project(){

        //inicializa el spinner
        Spinner projectSpinner=((Spinner)this_row.findViewById(R.id.row_imported_plane_project_spinner));
        projectList =FileHandling.getProjectList(context,PassingData.getGeneralFolderName((AppCompatActivity)context));
        select_project_spinner_adapter=new Select_Project_Spinner_Adapter(context,projectList);
        projectSpinner.setAdapter(select_project_spinner_adapter);
        projectSpinner.setOnItemSelectedListener(onProjectSelectedListener);
        //Busca la posicion del spinner correspondiente al proyecto actual para ponerlo por defecto.
        String currentProject;
        if (PassingData.E_plane_project==null)
        {
            currentProject=PassingData.getCurrentProjectNameFromSharedPreferences(context);
        }
        else
        {
            currentProject=PassingData.E_plane_project.ProjectName;
        }
        for(int n=0;n<projectList.size();n++){
            if(projectList.get(n).equals(currentProject))
            {
                projectSpinner.setSelection(n);
                break;
            }
        }

        //Inicializza el Edit Text destinado a introducir el nombre del proyecto en caso de "proyecto nuevo
        EditText newProjectName=findViewById(R.id.row_import_plane_txt_new_project_name);
        newProjectName.setOnKeyListener(onKey_NewProjectName);
        newProjectName.setOnFocusChangeListener(onFocus_NewProjectName);
    }


    //Carga el cuadro de texto de "nombre nuevo"
    private void IniTXT_File(){

        EditText editPlaneName = findViewById(R.id.row_import_plane_txt_new_filename);
        String newFileName;
        CHECK_PROJECT_NAME_RETURN_VALUE return_value;

        //Primero, prueba a obtener el nombre del plano desde el nombre del archivo de imagen recivida en el Uri
        newFileName = E_Plane_Project.nameFromPath(uri.getPath());
        return_value=CHECK_PROJECT_NAME_RETURN_VALUE.checkFileName(newFileName);
        if(return_value!=CHECK_PROJECT_NAME_RETURN_VALUE.OK) {
            newFileName="";
        }
        editPlaneName.setText(newFileName);
    }
    private void IniTXT_Extension(){
        TextView txtExtension=findViewById(R.id.row_import_plane_txt_extension);
        txtExtension.setText(getExtensionFromUri(uri));
    }

    private ArrayList<Plane> IniSpinner_Plane(String selectedProject) {
        Spinner projectSpinner=((Spinner)this_row.findViewById(R.id.row_imported_plane_project_spinner));
        if(selectedProject==null)
        {
            selectedProject=((String) (projectSpinner.getSelectedItem()));
        }
        else if(selectedProject.equals("")){
            selectedProject=((String) (projectSpinner.getSelectedItem()));
        }
        Spinner planeSpinner=((Spinner)this_row.findViewById(R.id.row_import_plane_spinner_plane));
        //ArrayList<String> planeNameList= FileHandling.getPlaneNamesList(selectedProject);
        ArrayList<Plane> planeNameList= FileHandling.getPlaneList(selectedProject);

        Select_Plane_Spinner_Adapter select_plane_spinner_adapter=new Select_Plane_Spinner_Adapter(context,planeNameList);
        planeSpinner.setAdapter(select_plane_spinner_adapter);
        planeSpinner.setOnItemSelectedListener(onPlaneSelectedListener);

        return planeNameList;
    }
    /**
     * Inicializa la tabla del combo box del spinner_Folder con los directorios
     * del proyecto "selectedProject". Si este es null o "", usa como proyecto
     * el seleccionado en el spinner_project.
     * La primera entrada del Spinner es un un string con las palabras "Nueva carpeta".
     * La entrada preseleccionada por defecto es la carpeta principal del
     * proyecto.
     * Si el proyecto seleccionado no es válido, solo aparece en el spinner la primera
     * entrada con las palabras "nueva carpeta".
     * @param selectedProject proyecto que se usará para obtener los subdirectorios
     */
    private void IniSpinner_Folder(String selectedProject){
        Spinner projectSpinner=((Spinner)this_row.findViewById(R.id.row_imported_plane_project_spinner));
        if(selectedProject==null)
        {
            selectedProject=((String) (projectSpinner.getSelectedItem()));
        }
        else if(selectedProject.equals("")){
            selectedProject=((String) (projectSpinner.getSelectedItem()));
        }
        Spinner folderSpinner=((Spinner)this_row.findViewById(R.id.row_import_plane_spinner_folder));
        ArrayList<String> folderList= FileHandling.getFolderList(context,selectedProject);
        Select_Folder_Spinner_Adapter select_folder_spinner_adapter=new Select_Folder_Spinner_Adapter(context,folderList);
        folderSpinner.setAdapter(select_folder_spinner_adapter);
        folderSpinner.setOnItemSelectedListener(onFolderSelectedListener);

        //Por defecto... el nuevo plano se guardará en el directorio principal del proyecto
        folderSpinner.setSelection(1);
    }


    private void addNewTagView(LinearLayout tagListContainer) {

        //Crea el contenedor del tag editable
        tagContainer = inflater.inflate(R.layout.row_new_tag, null);
        //Crea unespacio donde el usuario podrá editar un nuevo tag basado en un View editable
        // y con ventana de sugerencias
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(context,
                R.layout.simple_dropdown_item, TAGS_Sugested);
        tagView = (AutoCompleteTextView)tagContainer.findViewById(R.id.row_TAG);
        tagView.setThreshold(0);
        tagView.setAdapter(adapter);
        tagView.setImeActionLabel("Custom text", KeyEvent.KEYCODE_ENTER);
        tagView.setOnKeyListener(onKey_TagView);
        tagView.addTextChangedListener(textWatcher_tagView);
        String textTAG=tagView.getText().toString().toLowerCase();
        int index=TagsCreated.indexOf(textTAG);
        if(index!=-1)
        {
            tagView.setText("");
            for (String s : TAGS_Sugested) {
                index = TagsCreated.indexOf(s);
                if (index == -1) {
                    tagView.setText(s);
                    break;
                }
            }
        }
        else
        {
            tagView.setText(textTAG);
        }
        //Agrega el boton"OK"
        ImageView btnOK=tagContainer.findViewById(R.id.row_new_tag_btn_ok);
        btnOK.setOnClickListener(onOKListener);
        btnOK.setVisibility(View.VISIBLE);
        //Una vez está preparado el espacio para introducir el TAG, lo añade al contenedor principal
        tagListContainer.addView(tagContainer);
    }
    protected void FixTagView(String tagText,LinearLayout container){

        View fixedtagContainer = inflater.inflate(R.layout.row_fixed_tag, null);
        TextView fixedTag=fixedtagContainer.findViewById(R.id.Text_row_fixedTAG);
        ImageView fixedDelete=fixedtagContainer.findViewById(R.id.image_delete);
        fixedTag.setText(tagText);
        fixedDelete.setOnClickListener(onDeleteListener);

        LinearLayout tagListContainer=container.findViewById(R.id.tag_list_container);
        tagListContainer.removeView(tagContainer);
        tagListContainer.addView(fixedtagContainer);
    }
    public String getReducedPath_From_Uri (Uri uri){
        String path=uri.getPath();
        String reducedPath=path;
        int index=path.indexOf(':');
        if(index!=-1)
            reducedPath=path.substring(index+1);
        return reducedPath;
    }
    public String getExtensionFromUri(Uri uri){
        String ext="";
        String path=uri.getPath();

        int index=path.lastIndexOf('.');
        if(index!=-1)
            ext=path.substring(index+1);

        return ext;
    }
    private boolean adjustBitmapHeight (final ImageView imageView,final Uri uri) {

        //String reducedPath=getReducedPath_From_Uri(uri);
        //Bitmap bitmap1 = BitmapFactory.decodeFile(reducedPath);
        //Bitmap bitmap2 = BitmapFactory.decodeFile(uri.getPath());
        Bitmap bitmap3=null,bitmap4=null;
        InputStream ims;
        try {
            ims = context.getContentResolver().openInputStream(uri);
            // just display image in imageview
            bitmap3=BitmapFactory.decodeStream(ims);
            //imageView.setImageBitmap(bitmap3);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            return false;
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
        Log.d("adjustBitmapHeight",uri.getPath());
        if (bitmap3 != null) {
            int bHeight = bitmap3.getHeight();
            int bWidth = bitmap3.getWidth();
            final float ratio = (float) bWidth / (float) bHeight;
            imageView.post(new Runnable() {
                @Override
                public void run() {
                    int height, width;
                    height = imageView.getHeight(); //height is ready
                    width = imageView.getWidth(); //width is ready
                    int newHeight = (int) (((float) width) / ratio);
                    imageView.getLayoutParams().height = newHeight;
                    imageView.requestLayout();
                }
            });
            return true;
        }
        return false;
    }
    protected void onClickDelete(View v){
        LinearLayout tagListContainer=findViewById(R.id.tag_list_container);
        LinearLayout ll=(LinearLayout)v.getParent();
        TextView tv=ll.findViewById(R.id.Text_row_fixedTAG);
        String text=tv.getText().toString();
        int index=TagsCreated.indexOf(text);
        if(index!=-1)TagsCreated.remove(index);
        tagListContainer.removeView((View)v.getParent());
        UpdateTxTTagError();
    }

    /**
     * Actualiza el cuadro de texto de error en Tag revisando el listado de tags en memoria
     * @return Devuelve true si no hay error y por lo tanto se ha ocultado
     * el mensaje de error, Devuelve false en caso de error.
     */
    private boolean UpdateTxTTagError() {

        AutoCompleteTextView v = findViewById(R.id.row_TAG);
        String textTAG = ((AutoCompleteTextView) v).getText().toString().toLowerCase();
        int index = TagsCreated.indexOf(textTAG);
        TextView errorText = findViewById(R.id.text_error_row_imported_plane);
        ImageView okView = findViewById(R.id.row_new_tag_btn_ok);
        if (index == -1) {
            errorText.setVisibility(View.INVISIBLE);
            okView.setVisibility(View.VISIBLE);
            //Si no está en la lista permite el nuevo Tag

            return true;
        }
        //Si el tag está ya está en la lista
        //muestra un mensaje de error
        Resources res = context.getResources();
        errorText.setText(res.getString(R.string.activity_add_file_3_text_error_A) + " "
                + textTAG + " "
                + res.getString(R.string.activity_add_file_3_text_error_B));
        errorText.setVisibility(View.VISIBLE);
        okView.setVisibility(View.INVISIBLE);
        return false;

    }

    public void onClickOK(View v){
        // Perform action on key press
        String textTAG=((TextView)findViewById(R.id.row_TAG)).getText().toString().toLowerCase();

        TagsCreated.add(textTAG);
        ViewParent row_new_tag_current=v.getParent();
        ViewParent tag_list_container_current=row_new_tag_current.getParent();
        FixTagView(textTAG,((LinearLayout)tag_list_container_current));

        addNewTagView((LinearLayout)tag_list_container_current);
    }
    public void onClickMasOpciones(View v){
         LinearLayout ll_masOpciones=findViewById(R.id.row_import_plane_ll_opciones_extra);
        TextView txt=findViewById(R.id.row_import_plane_mas_opciones);
        CheckBox chk=findViewById(R.id.row_import_plane_check_version);
        if(ll_masOpciones.isShown())
        {
            ll_masOpciones.setVisibility(GONE);
            chk.setVisibility(GONE);
            txt.setText(R.string.row_imported_plane_mas_opciones);
        }
        else
        {
            ll_masOpciones.setVisibility(VISIBLE);
            chk.setVisibility(VISIBLE);
            txt.setText(R.string.row_imported_plane_menos_opciones);

        }
    }

    public void addProjectToList (String newProjectRequested){
//        Spinner spinnerProject =findViewById(R.id.row_imported_plane_project_spinner);
//        String projectPath=FileHandling.constructProjectFilePath(projectName);
        //projectList.add(newProjectRequested);
        select_project_spinner_adapter.add(newProjectRequested);
        select_project_spinner_adapter.notifyDataSetChanged();
    }

}
