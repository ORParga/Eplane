package com.orparga.electricplan;

public class FileName {
    String NameWithExtension;
    String NameWithoutExtension;
    String Extension;
    String NameWithoutNumber;
    String Number;
    int iNumber;
    int dotPosition;

    public String getNameWithExtension() {
        return NameWithExtension;
    }

    public String getNameWithoutExtension() {
        return NameWithoutExtension;
    }

    public String getExtension() {
        return Extension;
    }

    public String getNameWithoutNumber() {
        return NameWithoutNumber;
    }

    public String getNumber() {
        return Number;
    }

    public int getiNumber() {
        return iNumber;
    }

    public int getDotPosition() {
        return dotPosition;
    }

    public FileName(String NameWithExtension) {
        this.NameWithExtension = NameWithExtension;
        dotPosition = NameWithExtension.lastIndexOf('.');
        if (dotPosition != -1) {
            NameWithoutExtension = NameWithExtension.substring(0, dotPosition);
            Extension = NameWithExtension.substring(dotPosition);
        } else {
            NameWithoutExtension = NameWithExtension;
            Extension = "";
        }

        try {
            Number = NameWithoutExtension.substring(NameWithoutExtension.length() - 2);
            iNumber = Integer.parseInt(Number);
        } catch (NumberFormatException | IndexOutOfBoundsException e) {
            NameWithoutNumber = NameWithoutExtension;
            Number = "";
            iNumber = 0;
            return;
        }
        NameWithoutNumber = NameWithoutExtension.substring(0, NameWithoutExtension.length() - 2);
    }
}

