package com.orparga.electricplan;

import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.util.ArrayList;

public class Activity_Add_File_3 extends AppCompatActivity {

    protected View tagContainer; // Creating an instance for View Object
    protected AutoCompleteTextView tagView;
    protected LayoutInflater inflater;
    protected ArrayList<String> TagsCreated;
    protected AppCompatActivity context;
    View.OnClickListener onClickListener=new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            onClickDelete(v);
        }
    };

    private String[] TAGS_Sugested = new String[] {
            "Electricidad", "Fontaneria"
    };
    View.OnKeyListener onKeyListener=new View.OnKeyListener() {
        public boolean onKey(View v, int keyCode, KeyEvent event) {
            // If the event is a key-down event on the "enter" button
            if (event.getAction() == KeyEvent.ACTION_DOWN)
            {
                String textTAG=((AutoCompleteTextView)v).getText().toString().toLowerCase();
                int index=TagsCreated.indexOf(textTAG);
                TextView errorText=context.findViewById(R.id.text_error_add_file_3);
                ImageView okView=context.findViewById(R.id.row_new_tag_btn_ok);
                if(index==-1)
                {
                    errorText.setVisibility(View.INVISIBLE);
                    okView.setVisibility(View.VISIBLE);
                    //Si no está en la lista permite el nuevo Tag
                    if (keyCode == KeyEvent.KEYCODE_ENTER) {
                        // Perform action on key press
                        TagsCreated.add(textTAG);
                        FixTagView(textTAG);
                        return true;
                    }
                }
                //Si el tag está ya está en la lista
                //muestra un mensaje de error
                Resources res=context.getResources();
                errorText.setText(res.getString(R.string.activity_add_file_3_text_error_A)+" "
                        +textTAG+" "
                        +res.getString(R.string.activity_add_file_3_text_error_B));
                errorText.setVisibility(View.VISIBLE);
                okView.setVisibility(View.INVISIBLE);
                return true;

            }
            return false;
        }
    };
    TextWatcher textWatcher=new TextWatcher() {

        public void afterTextChanged(Editable s) {
            String textTAG=s.toString().toLowerCase();
            int index=TagsCreated.indexOf(textTAG);
            TextView errorText=context.findViewById(R.id.text_error_add_file_3);
            ImageView okView=context.findViewById(R.id.row_new_tag_btn_ok);
            if(index!=-1)
            {
                //Si el tag está ya está en la lista
                //muestra un mensaje de error
                Resources res=context.getResources();
                errorText.setText(res.getString(R.string.activity_add_file_3_text_error_A)+" "
                        +textTAG+" "
                        +res.getString(R.string.activity_add_file_3_text_error_B));
                errorText.setVisibility(View.VISIBLE);
                if(okView!=null)okView.setVisibility(View.INVISIBLE);
            }
            else {
                //Si no está en la lista permite el nuevo Tag
                errorText.setVisibility(View.INVISIBLE);
                if(okView!=null)okView.setVisibility(View.VISIBLE);
            }
        }

        public void beforeTextChanged(CharSequence s, int start, int count, int after) {

        }

        public void onTextChanged(CharSequence s, int start, int before, int count) {
        }
    };

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        context=this;
        setContentView(R.layout.activity_add_file_3);
        TextView tittle=findViewById(R.id.text_add_file_3_tittle);
        tittle.setText(PassingData.from_activity_project_name);
        tittle=findViewById(R.id.text_add_file_3_tittle2);
        tittle.setText(PassingData.from_activity_plane_name);
        TAGS_Sugested=getResources().getStringArray(R.array.tag_sugestions);
        TagsCreated=new ArrayList<String>();
        addNewTagView();
    }
    @Override
    protected void onResume() {
        super.onResume();
        PassingData.from_activity= PassingData.FROM_ACTIVITY.ADD_FILE_3_start;

    }
    protected void FixTagView(String tagText)
    {

        View fixedtagContainer = inflater.inflate(R.layout.row_fixed_tag, null);
        TextView fixedTag=fixedtagContainer.findViewById(R.id.Text_row_fixedTAG);
        ImageView fixedDelete=fixedtagContainer.findViewById(R.id.image_delete);
        fixedTag.setText(tagText);
        fixedDelete.setOnClickListener(onClickListener);

        LinearLayout tagListContainer=findViewById(R.id.tag_list_container);
        tagListContainer.removeView(tagContainer);
        tagListContainer.addView(fixedtagContainer);
        addNewTagView();
    }
    protected void addNewTagView()
    {
        inflater = (LayoutInflater)getBaseContext().getSystemService(LAYOUT_INFLATER_SERVICE);
        tagContainer = inflater.inflate(R.layout.row_new_tag, null);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
                R.layout.simple_dropdown_item, TAGS_Sugested);
        tagView = (AutoCompleteTextView)
                tagContainer.findViewById(R.id.row_TAG);
        tagView.setThreshold(0);
        tagView.setAdapter(adapter);
        tagView.setImeActionLabel("Custom text", KeyEvent.KEYCODE_ENTER);
        tagView.setOnKeyListener(onKeyListener);
        tagView.addTextChangedListener(textWatcher);
        String textTAG=tagView.getText().toString().toLowerCase();
        int index=TagsCreated.indexOf(textTAG);
        if(index!=-1)
        {
            tagView.setText("");
            for (String s : TAGS_Sugested) {
                index = TagsCreated.indexOf(s);
                if (index == -1) {
                    tagView.setText(s);
                    break;
                }
            }
        }
        else
        {
            tagView.setText(textTAG);
        }
        ImageView btnOK=tagContainer.findViewById(R.id.row_new_tag_btn_ok);
        btnOK.setVisibility(View.VISIBLE);
        LinearLayout tagListContainer=findViewById(R.id.tag_list_container);
        tagListContainer.addView(tagContainer);
    }
    protected void onClickDelete(View v){
        LinearLayout tagListContainer=findViewById(R.id.tag_list_container);
        LinearLayout ll=(LinearLayout)v.getParent();
        TextView tv=ll.findViewById(R.id.Text_row_fixedTAG);
        String text=tv.getText().toString();
        int index=TagsCreated.indexOf(text);
        if(index!=-1)TagsCreated.remove(index);
        tagListContainer.removeView((View)v.getParent());
    }
    public void onClickOK(View v){
        // Perform action on key press
        String textTAG=((TextView)findViewById(R.id.row_TAG)).getText().toString().toLowerCase();

        TagsCreated.add(textTAG);
        FixTagView(textTAG);

    }

    public void onClickSiguiente(View view) {
        Intent intent;
        PassingData.from_activity= PassingData.FROM_ACTIVITY.ADD_FILE_3_start;
        Plane plane= PassingData.from_activity_plane;
        for (String tag:TagsCreated){
            plane.tagList.add(new Tag(tag));
        }
        try {
            PassingData.E_plane_project.Save_To_File();
        } catch (IOException e) {
            Toast.makeText(context,getResources().getString(R.string.error_al_guardar_archivo),Toast.LENGTH_SHORT).show();
        }
        intent = new Intent(this, Activity_Add_File_4.class);
        startActivity(intent);
    }

    public void onClickFinalizar(View view) {
        PassingData.from_activity= PassingData.FROM_ACTIVITY.ADD_FILE_3_start;
        Plane plane= PassingData.from_activity_plane;
        for (String tag:TagsCreated){
            plane.tagList.add(new Tag(tag));
        }try {
            PassingData.E_plane_project.Save_To_File();
        } catch (IOException e) {
            Toast.makeText(context,getResources().getString(R.string.error_al_guardar_archivo),Toast.LENGTH_SHORT).show();
        }
        Intent intent = new Intent( context, MainActivity.class );
        intent.setFlags( Intent.FLAG_ACTIVITY_CLEAR_TOP );
        this.startActivity( intent );
    }
}
