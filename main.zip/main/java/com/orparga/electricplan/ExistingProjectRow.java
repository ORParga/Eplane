package com.orparga.electricplan;

public class ExistingProjectRow {
    private String sProjectFilePath;
    private String sProjectName;
    private int iIcon;

    public ExistingProjectRow(String sProjectName, int iIcon) {
        this.sProjectName = sProjectName;
        this.iIcon = iIcon;
    }
    public String getsProjectName() {
        return sProjectName;
    }

    public int getiIcon() {
        return iIcon;
    }

}
