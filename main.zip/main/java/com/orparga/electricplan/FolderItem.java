package com.orparga.electricplan;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.SubMenu;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.io.File;
import java.util.ArrayList;

import static com.orparga.electricplan.PassingData.MainMenu;

public class FolderItem {
    public enum TYPE {Folder,Item,Tagged,Undefined}
    public enum STATUS {Expanded,Colapsed};

    static public String NewFolderDefaultName="New_Folder";

    public Plane plane;
    public ArrayList <FolderItem> Menu;
    public String Tittle;
    public FolderItem thisFolderItem;
    public TYPE type=TYPE.Undefined;
    public STATUS status =STATUS.Expanded;

    public void setSelected(boolean selected) {
        this.selected = selected;
        if (MenuItemLayout != null) {
            TextView tv = MenuItemLayout.findViewById(R.id.texto);
            ImageView plus = MenuItemLayout.findViewById(R.id.plus);
            ImageView icon = MenuItemLayout.findViewById(R.id.icon);

            if (selected) {
                tv.setBackgroundResource(R.color.colorBackgroundMenuItemSelected);
                plus.setBackgroundResource(R.color.colorBackgroundMenuItemSelected);
                icon.setBackgroundResource(R.color.colorBackgroundMenuItemSelected);
            } else {
                tv.setBackgroundColor(PassingData.getCurrent_background_color());
                plus.setBackgroundColor(PassingData.getCurrent_background_color());
                icon.setBackgroundColor(PassingData.getCurrent_background_color());
            }
            tv.invalidate();
            plus.invalidate();
            icon.invalidate();
        }
    }

    public boolean selected=false;
    public LinearLayout MenuItemLayout;
    public String FullPath ="";
    public boolean PathLoaded=false;
    public FolderItemManager folderItemManager=null;

    private LinearLayout.OnLongClickListener onLongClickListener;
    private LinearLayout.OnClickListener onClickListener;

    public FolderItem() {IniFolderItem(null,NewFolderDefaultName,type,FullPath,status,folderItemManager);
    }
    public FolderItem(Plane plane,String tittle){
        IniFolderItem(plane,tittle,type,FullPath,status,folderItemManager);
    }
    public FolderItem(Plane plane,String tittle, TYPE type,FolderItemManager folderItemManager){
        IniFolderItem(plane,tittle,type,"",status,folderItemManager);
    }
    public FolderItem(Plane plane,String tittle, TYPE type,String FullPath,FolderItemManager folderItemManager){
        IniFolderItem(plane,tittle,type,FullPath,status,folderItemManager);
    }
    public FolderItem(Plane plane,String tittle, STATUS status,FolderItemManager folderItemManager){
        IniFolderItem(plane,tittle,type,FullPath,status,folderItemManager);

    }

    protected void IniFolderItem (Plane plane,String tittle, TYPE type,String FullPath,STATUS status,FolderItemManager folderItemManager)
    {
        this.Menu=new ArrayList<FolderItem>();
        this.plane=plane;
        this.Tittle=tittle;
        this.type=type;
        this.FullPath =FullPath;
        this.status=status;
        this.PathLoaded=true;
        this.thisFolderItem=this;
        this.folderItemManager=folderItemManager;

    }
    public FolderItem add (Plane plane,String tittle,TYPE type,FolderItemManager folderItemManager)
    {
        FolderItem fi=new FolderItem(plane,tittle,type,folderItemManager);
        Menu.add(fi);

        return fi;
    }
    public FolderItem add (Plane plane,String tittle,TYPE type,String FullPath,FolderItemManager folderItemManager)
    {
        FolderItem fi=new FolderItem(plane,tittle,type,FullPath,folderItemManager);
        Menu.add(fi);

        return fi;
    }
    public void CreateMenuView (AppCompatActivity act, LinearLayout parent_linearLayout)
    {
        //Crea el parent_linearLayout que va a contener el nombre, el icono y el simbolo +
        //propios del archivo
        LayoutInflater inflater = (LayoutInflater)   act.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        final LinearLayout LL =(LinearLayout)inflater.inflate(R.layout.menu_item_layout,parent_linearLayout,false);
        parent_linearLayout.addView(LL);
        MenuItemLayout=LL;
        //Definimos cómo se comporta cuando pulsamos sobre el archivo
        onClickListener=new View.OnClickListener() {
            File imgFile;
            @Override
            public void onClick(View v) {
                folderItemManager.singleClick(thisFolderItem);
            }
        };
        LL.setOnClickListener(onClickListener);
        //Una pulsacion larga sobre un archivo o una carpeta, la selecciona o al deselecciona
        onLongClickListener=new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {{
                folderItemManager.longClick(thisFolderItem);
                return true;
            }
            }};
        LL.setOnLongClickListener(onLongClickListener);
        //Osrganiza el interior del layout: el texto, el icono y el simbolo mas.
        TextView tv = LL.findViewById(R.id.texto);
        ImageView plus=LL.findViewById(R.id.plus);
        ImageView icon=LL.findViewById(R.id.icon);
        tv.setText(Tittle);
        switch (type)
        {
            case Folder:
                icon.setImageResource(R.drawable.ic_icons8_abrir_carpeta);
                LinearLayout LL_Inner = LL.findViewById(R.id.FolderContainer);
                for (int n = 0; n < Menu.size(); n++) {
                    Menu.get(n).CreateMenuView(act, LL_Inner);
                }
                if(status==STATUS.Expanded) {
                    plus.setImageResource(R.drawable.ic_minus);
                    LL_Inner.setVisibility(View.VISIBLE);
                }
                else
                {
                    LL_Inner.setVisibility(View.GONE);
                    plus.setImageResource(R.drawable.ic_plus);

                }
                break;
            case Item:
                plus.setVisibility(View.GONE);
                LinearLayout.LayoutParams params=new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);

                params.setMargins(
                        (int)act.getResources().getDimension(R.dimen.indent_MenuItem),
                        (int)act.getResources().getDimension(R.dimen.border_menuItem),
                        (int)act.getResources().getDimension(R.dimen.border_menuItem),
                        (int)act.getResources().getDimension(R.dimen.border_menuItem));
                parent_linearLayout.setLayoutParams(params);

                break;
            case Tagged:
                plus.setVisibility(View.GONE);
                break;
        }
    }


    public FolderItem get (int i)
    {
        if (Menu.size()<i)return null;
        return Menu.get(i);
    }
    public FolderItem getFirstFolderItemSelected()
    {
        FolderItem returnValue;

        if(selected) return this;

        if(Menu!=null)
        {
            for(int n=0;n<Menu.size();n++)
            {
                if((returnValue=Menu.get(n).getFirstFolderItemSelected())!=null)return returnValue;
            }
        }

        return null;
    }

    public static boolean isAnySelected (FolderItem folderItem){
        if(folderItem==null)return false;
        if(folderItem.selected)return true;
        for(FolderItem subFolder:folderItem.Menu)
            if (isAnySelected(subFolder))return true;
        return false;
    }

    public static void fillFolder(File folder, FolderItem folderItem,FolderItemManager folderItemManager) {
        String folderName,fileName,FullPath,AbsolutePath,CanonicalPath;
        try {
            File[] files = folder.listFiles();
            for (int i = 0; i < files.length; i++) {
                if (files[i].isDirectory()) {
                    folderName = files[i].getName();
                    FullPath = files[i].getPath();
                    folderItem.add(null,folderName, FolderItem.TYPE.Folder,FullPath,folderItemManager);
                    fillFolder(files[i], folderItem.get(folderItem.Menu.size() - 1),folderItemManager);
                }
                if (files[i].isFile()) {
                    fileName = files[i].getName();
                    FullPath = files[i].getPath();
                    folderItem.add(null,fileName, FolderItem.TYPE.Item, FullPath,folderItemManager);
                }

            }
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }

    }
    public static void UnSelectThree (FolderItem tree)
    {
        if(tree==null)return;

        if(tree.selected) {
            tree.setSelected(false);
        }

        if(tree.type==TYPE.Folder)
        {
            if(tree.Menu!=null)
            {
                for(int n=0;n<tree.Menu.size();n++)
                {
                    UnSelectThree(tree.Menu.get(n));
                }
            }
        }


    }

    public static ArrayList<FolderItem> getSelectedItems (FolderItem folderItem) {
        ArrayList<FolderItem> returnList = new ArrayList<>();
        ArrayList<FolderItem> subFolderList = new ArrayList<>();

        if (folderItem == null) return null;
        if (folderItem.selected) {
            returnList.add(folderItem);
        }
        if (folderItem.type == TYPE.Folder) {
            if (folderItem.Menu != null) {
                for (FolderItem subFolder : folderItem.Menu) {
                    subFolderList = FolderItem.getSelectedItems(subFolder);
                    if (subFolderList != null) returnList.addAll(subFolderList);
                }
            }

        }
        return returnList;
    }
    public static ArrayList<FolderItem> getFolders (ArrayList<FolderItem> SourceList) {
        ArrayList<FolderItem> returnList = new ArrayList<>();

        if (SourceList == null) return returnList;
        for(FolderItem item:SourceList){
            if(item.type==TYPE.Folder){
                returnList.add(item);
            }
        }
        return returnList;
    }
    public static ArrayList<FolderItem> getNotFolders (ArrayList<FolderItem> SourceList) {
        ArrayList<FolderItem> returnList = new ArrayList<>();

        if (SourceList == null) return returnList;
        for(FolderItem item:SourceList){
            if(item.type!=TYPE.Folder){
                returnList.add(item);
            }
        }
        return returnList;
    }
    public FolderItem findParent (FolderItem tree){

        if(tree==null)return null;

        if(tree.Menu==null)return null;

        for(FolderItem item:tree.Menu){
            if(item==this)return tree;
            FolderItem found=findParent(item);
            if(found!=null)return found;
        }
        return null;
    }
    public void DeleteChild (FolderItem child){
        if(child==null)return;
        int indexOfChild=Menu.indexOf(child);
        if(indexOfChild==-1)return;
        Menu.remove(child);
    }
}
