package com.orparga.electricplan;

import android.content.Context;
import android.os.Environment;

import java.io.File;
import java.util.regex.Pattern;

enum CHECK_PROJECT_NAME_RETURN_VALUE {
    OK,
    TOO_SHORT,
    ALREADY_EXISTS,
    INVALID_CARACTERES,
    EMPTY_NAME;

    /**
     * Comprueba si el String es válido para un nombre de proyecto
     * @param generalFolderName El nombre de la carpeta de la app. (no la ruta)
     * @param projectName El nombre de proyecto a verificar
     * @return INVALID_CARACTERES - si hay un carácter no admisible por el sistema de archivos
     *          ALREADY_EXISTS - si el nombre del proyecto ya está en uso
     *          EMPTY_NAME - si projectName es una cadena vacía
     *          OK - si el nombre es válido
     */
    public static CHECK_PROJECT_NAME_RETURN_VALUE checkProjectName (String generalFolderName, String projectName){

        if(projectName.equals(""))return EMPTY_NAME;
        //Primero comprueva si los Strings son válidos como nombres de archivo
        boolean isSafeFilename = Pattern.matches("^[^<>:;,?\"*|/\\\\]+$", projectName);
        if(!isSafeFilename)return INVALID_CARACTERES;
        isSafeFilename = Pattern.matches("^[^<>:;,?\"*|/\\\\]+$", generalFolderName);
        if(!isSafeFilename)return INVALID_CARACTERES;
        //Después comprueba si el archivo ya está en uso
        String FolderPath= Environment.getExternalStorageDirectory()+"/"+
                generalFolderName+"/"+
                projectName;
        File folder=new File(FolderPath);
        if (folder!=null) if (folder.exists()) return ALREADY_EXISTS;

        return OK;
    }
    public static CHECK_PROJECT_NAME_RETURN_VALUE checkFileName (String BasicFileWithOutExtension) {
        boolean isSafeFilename = Pattern.matches("^[^<>:;,?\"*|/\\\\]+$", BasicFileWithOutExtension);
        if(!isSafeFilename)return INVALID_CARACTERES;
        if(BasicFileWithOutExtension.equals(""))return EMPTY_NAME;

        return OK;

    }
        public static CHECK_PROJECT_NAME_RETURN_VALUE checkFileName (Context context,String generalFolderName, String projectName,String Subfolders, String BasicFileWithExtension){

        boolean isSafeFilename;
        String[] parts;
        String comodin="";
        String separator="/";
        //Comprueva si la ruta de "Subfolders es válida solo si no está vacía
        if(!Subfolders.equals("")) {
            //comprueba cada

            if (Subfolders.contains("\\")) {
                //Si el tramo de Subfolders está separado pro barra invertida,
                parts = Subfolders.split("\\\\");
                for (String part : parts) {
                    isSafeFilename = Pattern.matches("^[^<>:;,?\"*|/\\\\]+$", BasicFileWithExtension);
                    if (!isSafeFilename) return INVALID_CARACTERES;
                    if (part.equals("")) return EMPTY_NAME;
                    separator="\\\\";
                }
            } else {
                parts = Subfolders.split("/");
                //Si el tramo de Subfolders está separado por barra,
                for (String part : parts) {
                    isSafeFilename = Pattern.matches("^[^<>:;,?\"*|/\\\\]+$", BasicFileWithExtension);
                    if (!isSafeFilename) return INVALID_CARACTERES;
                    if (part.equals("")) return EMPTY_NAME;
                    comodin=Subfolders+"\\\\";
                    separator="/";
                }
            }
            //agrega el separador final sólo si la cadena no está vacía
            comodin=Subfolders+separator;
        }

        //Primero comprueva si los Strings son válidos como nombres de archivo
        isSafeFilename = Pattern.matches("^[^<>:;,?\"*|/\\\\]+$", BasicFileWithExtension);
        if(!isSafeFilename)return INVALID_CARACTERES;
        if(BasicFileWithExtension.equals(""))return EMPTY_NAME;
        isSafeFilename = Pattern.matches("^[^<>:;,?\"*|/\\\\]+$", projectName);
        if(!isSafeFilename)return INVALID_CARACTERES;
        if(projectName.equals(""))return EMPTY_NAME;
        isSafeFilename = Pattern.matches("^[^<>:;,?\"*|/\\\\]+$", generalFolderName);
        if(!isSafeFilename)return INVALID_CARACTERES;
        if(generalFolderName.equals(""))return EMPTY_NAME;


        //Después comprueba si el archivo ya está en uso
        String FolderPath= Environment.getExternalStorageDirectory()+"/"+
                generalFolderName+separator+
                projectName+separator+
                comodin+
                BasicFileWithExtension;
        File folder=new File(FolderPath);
        if (folder!=null) if (folder.exists()) return ALREADY_EXISTS;

        return OK;
    }
}
