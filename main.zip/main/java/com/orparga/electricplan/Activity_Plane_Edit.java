package com.orparga.electricplan;

import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.os.Parcelable;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class Activity_Plane_Edit extends AppCompatActivity implements Tag_ViewContainerManager {

    Plane selectedPlane;
    static String FolderPath, Extension;
    Tag_ViewContainer tag_viewContainer;
    TextView errorText,txtErrorFile;
    EditText etxt_Name,etxt_File;
    Button btnApply;
    TextWatcher tWatcherName = new TextWatcher() {

        public void afterTextChanged(Editable s) {
            String textName = s.toString();


            E_Plane_Project.RETURN_VALUE return_value = PassingData.E_plane_project.checkPlaneName(textName);
            switch (return_value) {

                case OK: {
                    //Si no está en la lista permite el nuevo Nombre de plano
                    errorText.setVisibility(View.GONE);
                    updateApply();
                    break;
                }
                case NOT_A_STRING: {
                    errorText.setVisibility(View.GONE);
                    updateApply();
                    break;
                }
                case ALREADY_EXISTS:
                case IS_THE_LAST: {
                    //Si el nombre del plano no se ha modificado, se continua alegremente
                    if(textName.toLowerCase().equals(selectedPlane.Name.toLowerCase())){
                        errorText.setVisibility(View.GONE);
                        updateApply();
                    }
                    else {
                        //Si el nombre de plano está ya está en la lista
                        //muestra un mensaje de error
                        errorText.setText(getResources().getString(R.string.activity_plane_edit_text_error_A) + " "
                                + textName + " "
                                + getResources().getString(R.string.activity_plane_edit_text_error_B));
                        errorText.setVisibility(View.VISIBLE);
                        updateApply();
                    }
                    break;
                }
                case INVALID_CARACTERES: {
                    errorText.setText(getResources().getString(R.string.activity_plane_edit_text_error_C) + " "
                            + " " + "^<>:;,.?\"*|/\\");
                    errorText.setVisibility(View.VISIBLE);
                    updateApply();
                    break;
                }
            }
        }


        public void beforeTextChanged(CharSequence s, int start, int count, int after) {

        }

        public void onTextChanged(CharSequence s, int start, int before, int count) {
        }
    };

    TextWatcher tWatcherFile = new TextWatcher() {

        public void afterTextChanged(Editable s) {
            String textFile = s.toString().toLowerCase();


            E_Plane_Project.RETURN_VALUE return_value =
                    PassingData.E_plane_project.checkPlaneFileName(
                            FolderPath, textFile, Extension);
            switch (return_value) {

                case OK: {
                    //Si no está en la lista permite el nuevo Nombre de plano
                    txtErrorFile.setVisibility(View.GONE);
                    updateApply();
                    break;
                }
                case NOT_A_STRING: {
                    txtErrorFile.setVisibility(View.GONE);
                    updateApply();
                    break;
                }
                case ALREADY_EXISTS:
                case IS_THE_LAST: {
                    //Si el archivo del plano es el mismo que el original se continua alegremente
                    if(textFile.toLowerCase().equals(
                            (FileHandling.getFileNameWithoutExtension_from_Path(selectedPlane.last().Path)).toLowerCase())){
                        txtErrorFile.setVisibility(View.GONE);
                    }
                    else {
                        //Si el nombre de plano está ya está en la lista
                        //muestra un mensaje de error
                        txtErrorFile.setText(getResources().getString(R.string.activity_plane_edit_text_error_D) + " "
                                + textFile + " "
                                + getResources().getString(R.string.activity_plane_edit_text_error_E));
                        txtErrorFile.setVisibility(View.VISIBLE);
                    }
                    updateApply();
                    break;
                }
                case INVALID_CARACTERES: {
                    txtErrorFile.setText(getResources().getString(R.string.activity_plane_edit_text_error_C) + " "
                            + " " + "^<>:;,.?\"*|/\\");
                    txtErrorFile.setVisibility(View.VISIBLE);
                    updateApply();
                    break;
                }
            }
        }

        ;


        public void beforeTextChanged(CharSequence s, int start, int count, int after) {

        }

        public void onTextChanged(CharSequence s, int start, int before, int count) {
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_plane_edit);

        //Inicializa las variables globales
        FolderItem selectedFolder = PassingData.for_activity_plane_edit_SelectedFolder;
        selectedPlane = selectedFolder.plane;
        errorText = findViewById(R.id.activity_plane_edit_error_name);
        txtErrorFile=findViewById(R.id.activity_plane_edit_error_file);
        btnApply = findViewById(R.id.activity_plane_edit_button_apply);

        //Inicializa el Visualizador de Tags
        tag_viewContainer = findViewById(R.id.tag_view_container);
        tag_viewContainer.Ini_Tag_ViewContainer(this,selectedPlane);

        //Inicializa los Views de texto "Nombre" , "carpeta", "Archivo" y "extension"
        etxt_Name = findViewById(R.id.activity_plane_edit_name);
        etxt_Name.setText(selectedPlane.Name);
        etxt_Name.addTextChangedListener(tWatcherName);

        TextView etxt_Folder = findViewById(R.id.activity_plane_text_folder);
        FolderPath = FileHandling.getFolder_from_Path(selectedPlane.last().Path);
        etxt_Folder.setText(FolderPath);
        etxt_Folder.setSelected(true);

        etxt_File = findViewById(R.id.activity_plane_edit_file);
        etxt_File.setText(FileHandling.getFileNameWithoutExtension_from_Path(selectedPlane.last().Path));
        etxt_File.addTextChangedListener(tWatcherFile);

        TextView etxt_Ext = findViewById(R.id.activity_plane_text_ext);
        Extension = FileHandling.getExtension_from_Path(selectedPlane.last().Path);
        etxt_Ext.setText(Extension);
    }

    public void onClickCancelar(View v) {

        finish();
    }

    public void onClickAplicar(View v) {
        selectedPlane.tagList.clear();
        for (String tag:tag_viewContainer.TagsCreated){
            selectedPlane.tagList.add(new Tag(tag));
        }
        selectedPlane.Name=etxt_Name.getText().toString();
        FileHandling.renameFile(selectedPlane.last().Path,etxt_File.getText().toString());
        finish();
    }
    private void updateApply (){
        if((errorText.getVisibility()==View.GONE)&&(errorText.getVisibility()==View.GONE))
        {
            btnApply.setEnabled(true);
        }
        else
        {
            btnApply.setEnabled(false);
        }
    }

    @Override
    public void TagList_Modified() {
        updateApply();
    }
}
