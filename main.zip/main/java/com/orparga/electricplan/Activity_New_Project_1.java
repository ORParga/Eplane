package com.orparga.electricplan;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.Spinner;

import java.util.ArrayList;

import static com.orparga.electricplan.PassingData.createBasicProjectPath;

public class Activity_New_Project_1 extends AppCompatActivity {

    AppCompatActivity context;
    E_Plane_Project E_plane_project_temp;
    String Existing_project_Path_for_CallBAck;
    String Existing_project_Name_for_CallBAck;
    RadioButton radioButton;
    enum CHECKED {NEW,EXIST}
    CHECKED checked= CHECKED.NEW;
    final int NEW_PROJECT_1_PERMISION_CODE_FOR_LOAD_E_PLANE_PROJECT =100;

    View.OnClickListener onClickSiguiente=new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            {
            Intent intent;
                E_Plane_Project.RETURN_VALUE return_value;
            switch (checked)
            {
                case NEW:
                    intent = new Intent(context, Activity_New_Project_2.class);
                    PassingData.from_activity= PassingData.FROM_ACTIVITY.NEW_PROJECT_1_end;
                    startActivity(intent);
                    break;
                case EXIST:
                    Spinner spinner=findViewById(R.id.combo_existing_project);
                    ExistingProjectRow SelectedProject=(ExistingProjectRow)spinner.getSelectedItem();
                    E_plane_project_temp =new E_Plane_Project();
                    Existing_project_Name_for_CallBAck=SelectedProject.getsProjectName();
                    Existing_project_Path_for_CallBAck=createBasicProjectPath(SelectedProject.getsProjectName());
                    return_value=E_plane_project_temp.RP_Load_From_File(
                            context,
                            NEW_PROJECT_1_PERMISION_CODE_FOR_LOAD_E_PLANE_PROJECT,
                            Existing_project_Path_for_CallBAck);
                    switch (return_value) {

                        case OK:
                            afterCallback_OK();
                            break;
                        case CALLBACK_INVOKED:
                            break;
                        default:
                            break;
                    }
                    PassingData.from_activity= PassingData.FROM_ACTIVITY.NEW_PROJECT_1_end;
                    break;
            }
        }}};

    private ArrayList<ExistingProjectRow>existingProjectList;
    private ExistinProjectAdapter existinProjectAdapter;
    AdapterView.OnItemSelectedListener comboListener;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_project_1);
        PassingData.from_activity= PassingData.FROM_ACTIVITY.NEW_PROJECT_1_start;
        PassingData.from_activity_project_name="";
        initGlobals();
        initList();
        initCombo();
    }

    @Override
    protected void onResume() {
        super.onResume();
        PassingData.from_activity= PassingData.FROM_ACTIVITY.NEW_PROJECT_1_start;
        Spinner spinner=findViewById(R.id.combo_existing_project);
        ExistingProjectRow SelectedProject=(ExistingProjectRow)spinner.getSelectedItem();
        PassingData.from_activity_project_name=SelectedProject.getsProjectName();
    }
    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        switch (requestCode) {
            case NEW_PROJECT_1_PERMISION_CODE_FOR_LOAD_E_PLANE_PROJECT:
                E_plane_project_temp.Write_External_Storage_Permision_Callback_For_Load_Project(this,grantResults,Existing_project_Path_for_CallBAck);
                afterCallback_OK();
                return;
        }
    }
    private void afterCallback_OK()
    {

        PassingData.E_plane_project=E_plane_project_temp;
        PassingData.from_activity_project_name=Existing_project_Name_for_CallBAck;
        PassingData.setBasicProjectName(context, PassingData.from_activity_project_name);
        context.finish();
    }
    private void initGlobals() {
        context=this;

        Button buttonNext=findViewById(R.id.activity_new_project_1_btn_Next);
        buttonNext.setOnClickListener(onClickSiguiente);
    }

    private void initCombo() {
        Spinner spinnerExistingProject=findViewById(R.id.combo_existing_project);

        existinProjectAdapter=new ExistinProjectAdapter(this,existingProjectList);
        spinnerExistingProject.setAdapter(existinProjectAdapter);

        comboListener=new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                ExistingProjectRow clikedProject=(ExistingProjectRow)parent.getItemAtPosition(position);
                String clickedProjectName=clikedProject.getsProjectName();
                Button btnNext=findViewById(R.id.activity_new_project_1_btn_Next);
                btnNext.setText(
                        getResources().getString(R.string.activity_new_project_1_text_btn_change_to)+
                        " "+clickedProjectName);
                btnNext.invalidate();
                if(checked!=CHECKED.EXIST)
                checkButtonExist (findViewById(R.id.radio_2_new_project_1));
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                checkButtonNew (findViewById(R.id.radio_1_new_project_1));

            }
        };
        spinnerExistingProject.setOnItemSelectedListener(comboListener);
    }

    private void initList(){
        ArrayList<String> projectList=PassingData.fileHandling.getProjectsList();

        existingProjectList=new ArrayList<>();
        for(int n=0;n<projectList.size();n++)
        {
            existingProjectList.add(new ExistingProjectRow((projectList.get(n)),R.drawable.newproject));
        }
    }

    public void checkButtonNew (View v){

        radioButton=findViewById(R.id.radio_2_new_project_1);
        radioButton.setChecked(false);
        ((RadioButton)v).setChecked(true);
        checked=CHECKED.NEW;
        Button btnSiguiente= findViewById(R.id.activity_new_project_1_btn_Next);
        btnSiguiente.setText(getResources().getString(R.string.siguiente));
    }
    public void checkButtonExist (View v){
        radioButton=findViewById(R.id.radio_1_new_project_1);
        radioButton.setChecked(false);
        ((RadioButton)v).setChecked(true);
        checked=CHECKED.EXIST;
        Button btnSiguiente= findViewById(R.id.activity_new_project_1_btn_Next);
        btnSiguiente.setText(getResources().getString(R.string.cambiar_a)+" "+PassingData.from_activity_project_name);
    }
}
