package com.orparga.electricplan;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class Select_Folder_Spinner_Adapter extends ArrayAdapter<String> {

    public Select_Folder_Spinner_Adapter(Context context, ArrayList<String> FolderList) {
        super(context, 0, FolderList);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        return initView(position, convertView, parent);
    }

    @Override
    public View getDropDownView(int position, View convertView, ViewGroup parent) {
        return initView(position, convertView, parent);
    }

    private View initView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.row_select_folder,
                    parent, false);
        }
        ImageView imageViewIcon = convertView.findViewById(R.id.row_select_folder_image);
        imageViewIcon.setImageResource(R.drawable.ic_icons8_abrir_carpeta);
        TextView textViewName = convertView.findViewById(R.id.row_select_folder_text);

        String Folder="";
        if(getCount()>position)
            Folder = getItem(position);
        textViewName.setText(Folder);


        return convertView;

    }
}
