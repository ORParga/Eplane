package com.orparga.electricplan;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Debug;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class Intent_receive_plane extends AppCompatActivity implements Row_Import_Plane_Manager{
    protected AppCompatActivity context;
    protected ArrayList<Row_Import_Plane> row_import_planes;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        context=this;
        //TODO: Remove me.  Debug only!
//        while (!Debug.isDebuggerConnected()) {
//            try {
//                Log.d("Intent_receive_plane", "Waiting for debugger");
//                Thread.sleep(1000);
//            } catch (InterruptedException e) {
//                e.printStackTrace();
//            }
//        }
        PassingData.LoadConfiguration(this);
        setContentView(R.layout.intent_receive_plane);
        // Get intent, action and MIME type
        Intent intent = getIntent();
        String action = intent.getAction();
        String type = intent.getType();

        row_import_planes=new ArrayList<>();
        if (Intent.ACTION_SEND.equals(action) && type != null) {
            //if (type.startsWith("image/")) {
                handleSendImage(intent); // Handle single image being sent
            //}
        } else if (Intent.ACTION_SEND_MULTIPLE.equals(action) && type != null) {
            //if (type.startsWith("image/")) {
                handleSendMultipleImages(intent); // Handle multiple images being sent
            //}
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        PassingData.from_activity= PassingData.FROM_ACTIVITY.Intent_receive_plane_start;

    }
    private void handleSendImage(Intent intent) {
        Uri imageUri = (Uri) intent.getParcelableExtra(Intent.EXTRA_STREAM);
        if (imageUri != null) {

            TextView textView=findViewById(R.id.intent_receive_plane_tittle);
            textView.setText("Archivo recibido.");
            LinearLayout container=findViewById(R.id.intent_reveive_plane_container);

            inflate_New_Image_inContainer(imageUri,container);
        }
    }
    private void handleSendMultipleImages(Intent intent) {
        String ese="";
        ArrayList<Uri> imageUris = intent.getParcelableArrayListExtra(Intent.EXTRA_STREAM);
        if (imageUris != null) {
            TextView textView=findViewById(R.id.intent_receive_plane_tittle);
            if(imageUris.size()>1)ese="s";
            textView.setText(""+imageUris.size()+" archivo"+ese+" recibido"+ese+".");
            LinearLayout container=findViewById(R.id.intent_reveive_plane_container);
            for (Uri currentUri:imageUris){
                inflate_New_Image_inContainer(currentUri,container);
            }
            }
    }
    protected void inflate_New_Image_inContainer ( Uri uri,LinearLayout container)
    {
        //Crea una nueva "Ficha" donde se alvergarán todos los controles necesarios para
        //editar todos los detalles del plano en proceso de importación (PPI)
        Row_Import_Plane row_import_plane=new Row_Import_Plane(this,uri,this);
        row_import_planes.add(row_import_plane);


        //Una vez tenemos la "Ficha" preparada, la añadimos a la activity principal
        container.addView(row_import_plane);
    }
    @Override
    public void row_erase(Row_Import_Plane row_import_plane) {
        int index=row_import_planes.indexOf(row_import_plane);
        if(index!=-1)
        {
            row_import_planes.remove(index);
            LinearLayout container=findViewById(R.id.intent_reveive_plane_container);
            container.removeView(row_import_plane);
        }

    }

    @Override
    public void row_plane_accepted(Row_Import_Plane row_import_plane) {
        //Si el usuario ha elegido que el plano se guarde en un subdirectorio.
        //este se añade al nombre de archivo que se para a "copyFile"
        String subFoldersString=row_import_plane.getSubFoldersString();
        if(!subFoldersString.equals(""))
        {
            subFoldersString+="/";
        }
        //String destPath= Environment.getExternalStorageDirectory()+PassingData.getBasicProjectName()+row_import_plane.getSubFoldersString()+row_import_plane.getFileName_without_extension();
        //if(FileHandling.CopyPngFile(this,row_import_plane.getFileName_from_intentSend(),destPath)){
        String usedPath=FileHandling.CopyPngFile(this,row_import_plane.uri,subFoldersString+row_import_plane.getFileName_without_extension());
        if(FileHandling.lastError== FileHandling.RETURN_VALUE.OK){
            //Si no ha habido error al copiar el archivo,lo añadimos al .json del proyecto
            String strTempProjectPath=FileHandling.constructProjectFilePath(row_import_plane.getProjectName());
            E_Plane_Project temp_E_plane_project=new E_Plane_Project();
            temp_E_plane_project.Load_From_File(this,strTempProjectPath,false);
            if(row_import_plane.getbNewVersion()){
                //Si el plano recibido es una nueva version de un plano existente,
                //buscamos el "planelist" correspondiente donde añadirlo
                for(Plane plane:temp_E_plane_project.planeList){
                    if(plane.getName().equals(row_import_plane.getPlaneName())){
                        PlaneVersion planeVersion=new PlaneVersion(usedPath);
                        planeVersion.Date=E_Plane_Project.getCurrentTime();
                        planeVersion.Operario=PassingData.getUser();
                        plane.add(planeVersion);
                    }
                }
            }
            else{
                //Si el plano recibido es un plano nuevo, lo añadimos.
                PlaneVersion planeVersion=new PlaneVersion(usedPath);
                planeVersion.Date=E_Plane_Project.getCurrentTime();
                planeVersion.Operario=PassingData.getUser();

                Plane plane=new Plane(row_import_plane.planeName);
                plane.add(planeVersion);
                plane.tagList=E_Plane_Project.getTagList_from_StringList( row_import_plane.getTagsCreated());
                temp_E_plane_project.planeList.add(plane);
            }

            try {
                temp_E_plane_project.Save_To_File();

            }
            catch (Exception e){
                Toast.makeText(this,getResources().getString(R.string.error_al_guardar_archivo),Toast.LENGTH_SHORT).show();
            }
        }
        row_erase(row_import_plane);

        if(row_import_planes.size()==0)
        {
            PassingData.from_activity= PassingData.FROM_ACTIVITY.Intent_receive_plane_end;
            Intent startIntent = new Intent(context, MainActivity.class);
            startIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(startIntent);
            this.finish();
        }

    }


    @Override
    public void row_plane_declined(Row_Import_Plane row_import_plane) {

        row_erase(row_import_plane);

        if(row_import_planes.size()==0)
        {
            PassingData.from_activity= PassingData.FROM_ACTIVITY.Intent_receive_plane_end;
            Intent startIntent = new Intent(context, MainActivity.class);
            startIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(startIntent);
            this.finish();
        }
    }

    @Override
    public void row_new_project_requested(Row_Import_Plane row_import_plane) {
        int nRow=0;
        for(nRow=0;nRow<row_import_planes.size();nRow++){
            row_import_planes.get(nRow).addProjectToList(row_import_plane.projectName);
        }
    }

}
