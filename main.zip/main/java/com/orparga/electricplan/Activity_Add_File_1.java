package com.orparga.electricplan;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.annotation.Nullable;
import android.support.v4.content.FileProvider;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Date;


public class Activity_Add_File_1 extends AppCompatActivity {
    private static final int PICK_IMAGE =1001 ;
    private static final int CAMERA_REQUEST_CODE=1000;
    InputStream inputStream;
    FileOutputStream fos;
    Bitmap bitmap;
    String mCurrentPhotoPath;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_file_1);
        TextView tittle=findViewById(R.id.text_add_file_1_tittle);
        tittle.setText(PassingData.from_activity_project_name);
    }
    @Override
    protected void onResume() {
        super.onResume();
        PassingData.from_activity= PassingData.FROM_ACTIVITY.ADD_FILE_1_start;
    }

    @Override
    protected void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        ImageView imageView;
        String FilePath;
        switch (requestCode)
        {
            case CAMERA_REQUEST_CODE:
                //Extrae el bitmap del archivo temporal
                //bitmap=(Bitmap)data.getExtras().get("data");
                bitmap=BitmapFactory.decodeFile(mCurrentPhotoPath);
                if(bitmap!=null) {
                    //Comprime el bitmap para que ocupe menos memoria
                    Bitmap bitmap2 = Bitmap.createScaledBitmap(bitmap,  600 ,600, true);//this bitmap2 you can use only for display

                    //Muestra el bitmap en pantalla
                    imageView = findViewById(R.id.image_add_file_1);
                    imageView.setImageBitmap(bitmap2);
                    imageView.invalidate();
                    //Guarda la foto en un archivo temporal
                    FilePath = SavePhotoTemporaly(bitmap);
                    PassingData.from_activity_plane_file_path = FilePath;
                    PassingData.from_activity_plane = PassingData.E_plane_project.add_Plane(FilePath);
                    try {
                        PassingData.E_plane_project.Save_To_File();
                    } catch (IOException e) {
                        Toast.makeText(this, getResources().getString(R.string.error_al_guardar_archivo), Toast.LENGTH_SHORT).show();
                    }
                    //Muestra los botónes "siguiente" y "finalizar"
                    LinearLayout button_Bar = findViewById(R.id.ll_button_bar);
                    button_Bar.setVisibility(View.VISIBLE);
                }
                break;
            case PICK_IMAGE:
                if (null != data) {
                    Uri selectedImage = data.getData();
                    try {
                        //Extrae el bitmap de los datos de Intent
                        inputStream = getContentResolver().openInputStream(data.getData());
                    } catch (FileNotFoundException e) {
                        e.printStackTrace();

                        Toast.makeText(this,getResources().getString(R.string.activity_add_file_1_Toast_error_1),Toast.LENGTH_SHORT).show();
                        break;
                    }
                    try {
                        //muestra el bitmap en pantalla
                        bitmap = BitmapFactory.decodeStream(inputStream);

                        imageView = findViewById(R.id.image_add_file_1);
                        imageView.setImageBitmap(bitmap);
                        imageView.invalidate();
                        //Guarda la foto en un archivo temporal
                        FilePath= SavePhotoTemporaly(bitmap);
                        PassingData.from_activity_plane_file_path=FilePath;
                        PassingData.from_activity_plane =PassingData.E_plane_project.add_Plane(FilePath);
                        try {
                            PassingData.E_plane_project.Save_To_File();
                        } catch (IOException e) {
                            Toast.makeText(this,getResources().getString(R.string.error_al_guardar_archivo),Toast.LENGTH_SHORT).show();
                        }

                        //Muestra los botones "Siguiente" y "finalizar"
                        LinearLayout button_Next = findViewById(R.id.ll_button_bar);
                        button_Next.setVisibility(View.VISIBLE);
                    }
                    catch (Exception e)
                    {
                        e.printStackTrace();
                        imageView = findViewById(R.id.image_add_file_1);
                        imageView.setImageResource(android.R.color.transparent);
                        LinearLayout button_Next = findViewById(R.id.ll_button_bar);
                        button_Next.setVisibility(View.INVISIBLE);

                    }
                    break;
                }
                else{
                    Toast.makeText(this,getResources().getString(R.string.activity_add_file_1_Toast_error_1),Toast.LENGTH_SHORT).show();
                    break;

                }
        }
    }
    public void onClickFoto(View view) {
        File photoFile = null;
        try {
            photoFile = createImageFile();
        } catch (IOException ex) {
            // Error occurred while creating the File
            Log.d("CAM","Error create image file");
            ex.printStackTrace();
        }
        if (photoFile != null) {
            //Uri imageUri = Uri.fromFile(photoFile);
            Uri imageUri = FileProvider.getUriForFile(this,
                    BuildConfig.APPLICATION_ID + ".provider",
                    photoFile);
            Intent cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            cameraIntent.putExtra(android.provider.MediaStore.EXTRA_OUTPUT,
                    imageUri);
            cameraIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivityForResult(cameraIntent, CAMERA_REQUEST_CODE);
        }
    }

    public void onClickArchivo(View view) {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(Intent.createChooser(intent, "Select Picture"), PICK_IMAGE);
    }
    private File createImageFile() throws IOException {
        // Create an image file name
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
        String imageFileName = "JPEG_" + timeStamp + "_";
        String ProjectPath=PassingData.getBasicProjectFolderPath();
        File projectDir=new File(ProjectPath);
        File storageDir = Environment.getExternalStoragePublicDirectory(
                Environment.DIRECTORY_PICTURES);
        File image = File.createTempFile(
                imageFileName,  /* prefix */
                ".jpg",         /* suffix */
                projectDir      /* directory */
        );

        // Save a file: path for use with ACTION_VIEW intents
        mCurrentPhotoPath = image.getAbsolutePath();
        return image;
    }
    protected String SavePhotoTemporaly(Bitmap bitmap)
    {
        //Guarda la foto en "ROM" de forma temporal
        String FilePath=FileHandling.createTempFilePath();
        try {
            fos = new FileOutputStream(FilePath);
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, fos);
        } catch (IOException e) {
            e.printStackTrace();
            Toast.makeText(this,getResources().getText(R.string.error_al_guardar_archivo),Toast.LENGTH_SHORT).show();
            FilePath="";

        }catch (Exception e)
        {
            e.printStackTrace();
            Toast.makeText(this,getResources().getText(R.string.error_al_guardar_archivo),Toast.LENGTH_SHORT).show();
            FilePath="";
        }
        finally {
            try {
                fos.close();
            } catch (IOException e) {
                e.printStackTrace();
                FilePath="";
            }
        }
        return FilePath;
    }
    public void onClickSiguiente(View view) {
        PassingData.from_activity= PassingData.FROM_ACTIVITY.ADD_FILE_1_end;
        startActivity(new Intent(this, Activity_Add_File_2.class));
    }

    public void onClickFinalizar(View view) {
        PassingData.from_activity= PassingData.FROM_ACTIVITY.ADD_FILE_1_end;
        Intent intent=new Intent(this, MainActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(intent);

    }
}
