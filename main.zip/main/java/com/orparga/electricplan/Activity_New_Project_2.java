package com.orparga.electricplan;

import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;

public class Activity_New_Project_2 extends AppCompatActivity {

    AppCompatActivity context;
    TextWatcher textWatcher=new TextWatcher() {

        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {

        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {

        }

        public void afterTextChanged(Editable s) {
            Resources res = context.getResources();
            String textNewProjectName = s.toString().toLowerCase();
            TextView txtError = context.findViewById(R.id.activity_new_project_2_txtError);
            Button btnNext= context.findViewById(R.id.activity_new_project_2_Next);
            Button btnFinish= context.findViewById(R.id.activity_new_project_2_finish);
            CHECK_PROJECT_NAME_RETURN_VALUE ret=CHECK_PROJECT_NAME_RETURN_VALUE.checkProjectName(PassingData.GENERAL_FOLDER_NAME,textNewProjectName);
            if (ret == CHECK_PROJECT_NAME_RETURN_VALUE.ALREADY_EXISTS) {
                //Si ya hay un archivo con el nombre introducido: Error
                txtError.setText(res.getString(R.string.activity_new_project_2_text_Error_Name_A1) + " "
                        + textNewProjectName + " "
                        + res.getString(R.string.activity_new_project_2_text_Error_Name_A2));
                txtError.setVisibility(View.VISIBLE);
                btnNext.setEnabled(false);
                btnFinish.setEnabled(false);
                return;
            }
            if (ret == CHECK_PROJECT_NAME_RETURN_VALUE.INVALID_CARACTERES) {
                //Si se introduce un caracter no válido:Error
                txtError.setText( textNewProjectName + " "
                        +res.getString(R.string.activity_new_project_2_text_Error_Name_B));
                txtError.setVisibility(View.VISIBLE);
                btnNext.setEnabled(false);
                btnFinish.setEnabled(false);
                return;
            }

            txtError.setVisibility(View.INVISIBLE);
            btnNext.setEnabled(true);
            btnFinish.setEnabled(true);
        }
    };
        @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_project_2);
        this.context=this;
        EditText NewProjectName= findViewById(R.id.activity_new_project_2_editText_New_Name);
        NewProjectName.addTextChangedListener(textWatcher);
    }
    @Override
    protected void onResume() {
        super.onResume();
        //Viene de : Seleccionar que queremos proyecto nuevo
        //Vuelve de: Seleccionar imagen de plano
        switch (PassingData.from_activity) {
            case NEW_PROJECT_1_end:
                PassingData.from_activity_project_name = "";
                PassingData.from_activity= PassingData.FROM_ACTIVITY.NEW_PROJECT_2_start;
                break;
            case ADD_FILE_1_start:
                EditText projectEditText = findViewById(R.id.activity_new_project_2_editText_New_Name);
                projectEditText.setText(PassingData.from_activity_project_name);
                PassingData.from_activity= PassingData.FROM_ACTIVITY.NEW_PROJECT_2_start;
                break;
            default:
                PassingData.from_activity_project_name = "";
                PassingData.from_activity= PassingData.FROM_ACTIVITY.NEW_PROJECT_2_start;
                break;
        }

    }
    public void onClickCancelar(View view) {
        //invoca la anterior Activity
        PassingData.from_activity= PassingData.FROM_ACTIVITY.NEW_PROJECT_2_start;
        finish();
    }
    public void onClickSiguiente(View view) {

        CreateAndSaveNewProject();
        //invoca la siguiente Activity
        Intent intent = new Intent(this, Activity_Add_File_1.class);
        PassingData.from_activity= PassingData.FROM_ACTIVITY.NEW_PROJECT_2_end;
        startActivity(intent);
    }
    public void onClickFinalizar(View view) {
        CreateAndSaveNewProject();
        //Vuevle al la Activity principal
        Intent intent = new Intent(this, MainActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PassingData.from_activity= PassingData.FROM_ACTIVITY.NEW_PROJECT_2_end;
        startActivity(intent);
    }
    protected boolean CreateAndSaveNewProject (){
        boolean returnValue=true;

        //Recupera el nombre del nuevo proyecto del cuadro de texto
        EditText projectEditText=findViewById(R.id.activity_new_project_2_editText_New_Name);
        //Guarda el nuevo nombre en una variable especial para que la siguiente activity sepa que narices hemos hecho
        PassingData.from_activity_project_name=projectEditText.getText().toString();
        //Crea un nuevo objeto "E-Plane-project" con el que la App trabajará directamente
        PassingData.E_plane_project =new E_Plane_Project(PassingData.GENERAL_FOLDER_NAME,PassingData.from_activity_project_name);
        //Una variable global en vías de "deprecated" para hacer algo que sería mejor que hiciera el objeto E_Plane_Project:
        // memorizar el nombre del proyecto nuevo, aunque tambien guarda ese nombre en sharedPreferences
        PassingData.setBasicProjectName(this,PassingData.from_activity_project_name);
        //Guarga el nuevo objeto en la "ROM" ... cosa que se debe hacer tras cada modificacion.
        // Guardado Dinamico !acabemos con los botones "Save" y "Save as..."
        try {
            PassingData.E_plane_project.Save_To_File(this,PassingData.E_plane_project.ProjectPathInfo.getFullPath());
        } catch (IOException e) {
            e.printStackTrace();
            Toast.makeText((this),getResources().getString(R.string.save_new_project_error),Toast.LENGTH_SHORT).show();
            returnValue=false;
        }

        return returnValue;
    }
}
