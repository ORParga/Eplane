package com.orparga.electricplan;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Matrix;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.support.annotation.NonNull;
import android.support.v4.view.PagerAdapter;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;

public class Activity_Setup_Tabs extends PagerAdapter {
    private Context context;

    enum RadioButtons {TEXT,BACKGROUND,BORDER,UNDEFINED};

    View activity_setup_child;

    //Apareacnce TAb

    ThemeAdapter themeAdapter;
    CharSequence[] charSequences;

    Spinner comboBox;
    RadioGroup radioGroup;
    RadioButton radioButtonText,radioButtonBackground,radioButtonBorder;
    LinearLayout setup_aspect_sample_box;
    TextView setup_aspect_sample_text;
    ImageView imgSource1, imgSource2;
    Button RestoreButton,SaveButton, ApplyButton;
    int touchedRGB=0;
    View.OnTouchListener imgSourceOnTouchListener;
    View.OnClickListener radioButtonOnClickListener;

    //Performance Tab***************

    //Globals

    public Activity_Setup_Tabs(Context context) {
        this.context = context;
    }

    @Override
    public int getCount() {
        return 3;
    }

    @Override
    public boolean isViewFromObject(@NonNull View view, @NonNull Object o) {
        return o == view;
    }
    @Override
    public Object instantiateItem(final ViewGroup container, int position) {
        switch (position) {
            case 0:
                activity_setup_child = LayoutInflater.from(context).inflate(R.layout.activity_setup_aspect, null);

                // *****************Combo Box ****************************************************

                charSequences=IniSpinner();

                comboBox = (Spinner) activity_setup_child.findViewById(R.id.comboBox);
                themeAdapter= new ThemeAdapter(context,PassingData.themeList);
                comboBox.setAdapter(themeAdapter);
                comboBox.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                    @Override
                    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                        if(position!=0) {
                            Theme themeSelected = (Theme) parent.getItemAtPosition(position);
                            PassingData.setup_aspect_PointerOfThemeSelectedInComboBox =position;
                            PassingData.setup_aspect_sample_text_color=themeSelected.getColor_text();
                            PassingData.setup_aspect_sample_back_color=themeSelected.getColor_background();
                            PassingData.setup_aspect_sample_border_color=themeSelected.getColor_border();
                            setup_aspect_sample_text.setBackgroundColor(themeSelected.getColor_background());
                            setup_aspect_sample_text.setTextColor(themeSelected.getColor_text());
                            setup_aspect_sample_box.setBackgroundColor(themeSelected.getColor_border());

//                            ApplyButton = activity_setup_child.findViewById(R.id.setup_aspect_Apply_button);
//                            SaveButton = activity_setup_child.findViewById(R.id.setup_aspect_save_button);
//                            RestoreButton = activity_setup_child.findViewById(R.id.setup_aspect_restore_button);

                            PassingData.setup_aspect_apply_button_enabled=true;
                            PassingData.setup_aspect_save_button_enabled=true;
                            PassingData.setup_aspect_restore_button_enabled=true;
                            if(ApplyButton!=null)ApplyButton.setEnabled(true);
                            if(SaveButton!=null)SaveButton.setEnabled(true);
                            if(RestoreButton!=null)RestoreButton.setEnabled(true);
                            ApplyButton.invalidate();
                            SaveButton.invalidate();
                            RestoreButton.invalidate();
                        }
                    }

                    @Override
                    public void onNothingSelected(AdapterView<?> parent) {

                    }
                });
                // *****************Radio Buttons ****************************************************
                radioGroup=activity_setup_child.findViewById(R.id.radioGroup_setup_aspect_colors);
                radioButtonText=activity_setup_child.findViewById(R.id.radio_setup_aspect_text);
                radioButtonBackground=activity_setup_child.findViewById(R.id.radio_setup_aspect_background);
                radioButtonBorder=activity_setup_child.findViewById(R.id.radio_setup_aspect_border);


                // *****************Sample text ****************************************************
                setup_aspect_sample_text=activity_setup_child.findViewById(R.id.setup_aspect_sample_text);
                setup_aspect_sample_box=activity_setup_child.findViewById(R.id.setup_aspect_sample_box);
                setup_aspect_sample_text.setBackgroundColor(PassingData.current_background_color);
                setup_aspect_sample_text.setTextColor(PassingData.current_text_color);
                setup_aspect_sample_box.setBackgroundColor(PassingData.current_border_color);

                // *****************Pick Image  ****************************************************
                imgSource1 = (ImageView)activity_setup_child.findViewById(R.id.setup_wheel);
                CreateOnTouchListener();
                imgSource1.setOnTouchListener(imgSourceOnTouchListener);

                //**********************Butttons****************************************************

                ApplyButton = activity_setup_child.findViewById(R.id.setup_aspect_Apply_button);
                SaveButton = activity_setup_child.findViewById(R.id.setup_aspect_save_button);
                RestoreButton = activity_setup_child.findViewById(R.id.setup_aspect_restore_button);
                //**************** Posicion inicial ************************************************

                Theme currentTheme=PassingData.themeList.get(
                        PassingData.setup_aspect_PointerOfThemeSelectedInComboBox);
                comboBox.setSelection(PassingData.setup_aspect_PointerOfThemeSelectedInComboBox);
                setup_aspect_sample_text.setBackgroundColor(currentTheme.getColor_background());
                setup_aspect_sample_text.setTextColor(currentTheme.getColor_text());
                setup_aspect_sample_box.setBackgroundColor(currentTheme.getColor_border());

                ApplyButton = activity_setup_child.findViewById(R.id.setup_aspect_Apply_button);
                SaveButton = activity_setup_child.findViewById(R.id.setup_aspect_save_button);
                RestoreButton = activity_setup_child.findViewById(R.id.setup_aspect_restore_button);

                PassingData.setup_aspect_apply_button_enabled=false;
                ApplyButton.setEnabled(false);
                SaveButton.setEnabled(PassingData.setup_aspect_save_button_enabled);
                RestoreButton.setEnabled(PassingData.setup_aspect_restore_button_enabled);


                break;
            case 1:
                activity_setup_child = LayoutInflater.from(context).inflate(R.layout.activity_setup_performance, null);
                break;
            default:
                activity_setup_child = LayoutInflater.from(context).inflate(R.layout.activity_setup_about, null);
                break;
        }
        container.addView(activity_setup_child);
        return activity_setup_child;
    }
    @Override
    public void destroyItem(ViewGroup container, int position, Object object) {
        container.removeView((View) object);
    }
    @Override
    public CharSequence getPageTitle(int position) {
        switch (position) {
            case 0:
                return context.getResources().getString(R.string.activity_setup_Tab_aspect);
            case 1:
                return context.getResources().getString(R.string.activity_setup_Tab_performance);
            case 2:
                return context.getResources().getString(R.string.activity_setup_Tab_about);
            default:
                return "undefined";
        }
    }

    private void CreateOnTouchListener (){
        imgSourceOnTouchListener= new View.OnTouchListener(){

            @Override
            public boolean onTouch(View view, MotionEvent event) {

                float eventX = event.getX();
                float eventY = event.getY();
                float[] eventXY = new float[] {eventX, eventY};


                Matrix invertMatrix = new Matrix();
                ((ImageView)view).getImageMatrix().invert(invertMatrix);

                invertMatrix.mapPoints(eventXY);
                int x = Integer.valueOf((int)eventXY[0]);
                int y = Integer.valueOf((int)eventXY[1]);


                Drawable imgDrawable = ((ImageView)view).getDrawable();
                Bitmap bitmap = ((BitmapDrawable)imgDrawable).getBitmap();

                int bitmapWidth= bitmap.getWidth();
                int ViewWidth= view.getWidth();

                float scale=(float)ViewWidth/(float)bitmapWidth;

                scale=1/scale;
                x=(int)((float)x*scale);
                y=(int)((float)y*scale);
                //Limit x, y range within bitmap
                if(x < 0){
                    x = 0;
                }else if(x > bitmap.getWidth()-1){
                    x = bitmap.getWidth()-1;
                }

                if(y < 0){
                    y = 0;
                }else if(y > bitmap.getHeight()-1){
                    y = bitmap.getHeight()-1;
                }

                touchedRGB = bitmap.getPixel(x, y);
                switch (checkButton())
                {
                    case TEXT:
                        PassingData.setup_aspect_sample_text_color=touchedRGB;
                        setup_aspect_sample_text.setTextColor(touchedRGB);
                        setup_aspect_sample_text.invalidate();
                        break;
                    case BACKGROUND:
                        PassingData.setup_aspect_sample_back_color=touchedRGB;
                        setup_aspect_sample_text.setBackgroundColor(touchedRGB);
                        setup_aspect_sample_text.invalidate();
                        break;
                    case BORDER:
                        PassingData.setup_aspect_sample_border_color=touchedRGB;
                        setup_aspect_sample_box.setBackgroundColor(touchedRGB);
                        setup_aspect_sample_box.invalidate();
                        break;
                    case UNDEFINED:
                        break;
                }
                if(comboBox.getSelectedItemPosition()!=0)
                {
                    //Si se ha modificado el color de alguna parte
                    //el theme ya no es el mismo que figura en el
                    //combo box. Por lo tanto, la aplicacion
                    //debe activar la opcion de guardado y colocar
                    //"Nuevo tema" como nombre del tema que se está modificando

                    comboBox.setSelection(0,true);
                    PassingData.setup_aspect_PointerOfThemeSelectedInComboBox =0;
                }
                if(!PassingData.setup_aspect_apply_button_enabled)
                {
                    PassingData.setup_aspect_apply_button_enabled=true;
                    ApplyButton.setEnabled(true);
                }
                if(!PassingData.setup_aspect_save_button_enabled)
                {
                    PassingData.setup_aspect_save_button_enabled=true;
                    SaveButton.setEnabled(true);
                }
                return true;
            }};
    }

    private void CreateOnClickListener (){
        radioButtonOnClickListener=new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        };
    }

    public RadioButtons checkButton(){
        int radioId=radioGroup.getCheckedRadioButtonId();

        if(radioButtonText.getId()== radioId)return RadioButtons.TEXT;
        if(radioButtonBackground.getId()==radioId)return RadioButtons.BACKGROUND;
        if(radioButtonBorder.getId()== radioId)return RadioButtons.BORDER;
        return RadioButtons.UNDEFINED;
    }

    private CharSequence[] IniSpinner (){
        CharSequence[] charSequences=new CharSequence[2];

        charSequences[0]= new CharSequence() {
            String string="Light Side";
            @Override
            public int length() {
                return string.length();
            }

            @Override
            public char charAt(int index) {
                return string.charAt(index);
            }

            @Override
            public CharSequence subSequence(int start, int end) {
                return string.subSequence(start,end);
            }
        };

        charSequences[1]= new CharSequence() {
            String string="Dark Side";
            @Override
            public int length() {
                return string.length();
            }

            @Override
            public char charAt(int index) {
                return string.charAt(index);
            }

            @Override
            public CharSequence subSequence(int start, int end) {
                return string.subSequence(start,end);
            }
        };
        return charSequences;
    }
}
