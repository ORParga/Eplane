package com.orparga.electricplan;

import android.util.Pair;

import org.json.JSONException;
import org.json.JSONObject;

public class PlaneVersion {
    String Name="";
    String Operario="";
    String Path="";
    String Date="";

    Coor coor;
    Overprinted overprinted;

    public PlaneVersion(JSONObject jsonPlaneVersion){
        JSONObject jsonObject;

        try {
            Name = jsonPlaneVersion.getString("Name");
        }catch (JSONException e) {
            e.printStackTrace();
        }
        try {
            Operario = jsonPlaneVersion.getString("Operario");
        }catch (JSONException e) {
            e.printStackTrace();
        }
        try {
            Path=jsonPlaneVersion.getString("Path");
        }catch (JSONException e) {
            e.printStackTrace();
        }
        try {
            Date=jsonPlaneVersion.getString("Date");
        }catch (JSONException e) {
            e.printStackTrace();
        }
        try {
            jsonObject=jsonPlaneVersion.getJSONObject("coor");
            coor=new Coor(jsonObject);
        }catch (JSONException e) {
            e.printStackTrace();
        }
        try {
            jsonObject=jsonPlaneVersion.getJSONObject("overprinted");
            overprinted=new Overprinted(jsonObject);

        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    public PlaneVersion(String PicturePath)
    {
        Name=NameFromPath(PicturePath);
        Path=PicturePath;
        coor=new Coor();
        overprinted=new Overprinted();
    }

    public JSONObject To_JSONObject() {
        JSONObject jsonPlaneVersion=new JSONObject();

        try {
            if(Name==null)Name="";
            jsonPlaneVersion.put("Name",Name);
        } catch (JSONException|NullPointerException e) {
        }
        try {
            if(Operario==null)Operario="";
            jsonPlaneVersion.put("Operario",Operario);
        } catch (JSONException|NullPointerException e) {
        }
        try {
            if(Path==null)Path="";
            jsonPlaneVersion.put("Path",Path);
        } catch (JSONException|NullPointerException e) {
        }
        try {
            if(Date==null)Date="";
            jsonPlaneVersion.put("Date",Date);
        } catch (JSONException|NullPointerException e) {
        }
        try {
            jsonPlaneVersion.put("coor",coor.To_JSONObject());
        } catch (JSONException|NullPointerException e) {
        }
        try {
            jsonPlaneVersion.put("overprinted",overprinted.To_JSONObject());
        } catch (JSONException|NullPointerException e) {
        }
        return jsonPlaneVersion;
    }

    public static String NameFromPath (String Path)
    {
        int index=Path.indexOf('.');
        if(index!=-1)
        {
            Path=Path.substring(0,index);
        }

        index=Path.lastIndexOf('/');
        if(index!=-1)
        {
            Path=Path.substring(index);
        }
        return Path;

    }
}
