package com.orparga.electricplan;

import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.design.widget.TabLayout;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.InputType;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;

import org.json.JSONArray;


public class Activity_Setup extends AppCompatActivity {
    Toolbar toolbar;
    TabLayout tabs;
    private ViewPager viewPager;
    Activity_Setup_Tabs activity_setup_tabs;
    String m_Text;

    TabLayout.OnTabSelectedListener onTabSelectedListener = new TabLayout.OnTabSelectedListener() {
        @Override
        public void onTabSelected(TabLayout.Tab tab) {

        }

        @Override
        public void onTabUnselected(TabLayout.Tab tab) {

        }

        @Override
        public void onTabReselected(TabLayout.Tab tab) {

        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        //Inicializa el layout
        setTheme(R.style.AppTheme);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_setup);
        //Inicializa la barra de tareas
        toolbar = (Toolbar) findViewById(R.id.tool_bar);
        setSupportActionBar(toolbar);

        viewPager = findViewById(R.id.setup_view_adapter);
        activity_setup_tabs = new Activity_Setup_Tabs(this);
        viewPager.setAdapter(activity_setup_tabs);
        tabs = findViewById(R.id.tabs_setup);
        tabs.setupWithViewPager(viewPager);
        //tabs.addOnTabSelectedListener(onTabSelectedListener);


    }

    public void onClickSave(View v) {
        int color1, color2, color3;


        showDialogSaveTheme("New Theme", "");
    }

    public void onClickRestore(View v) {
        //Set global variables to "Light-Side" theme

        PassingData.current_theme_Name = PassingData.current_theme_Name_default;
        PassingData.current_text_color = PassingData.current_text_color_default;
        PassingData.current_background_color = PassingData.current_background_color_default;
        PassingData.current_border_color = PassingData.current_border_color_default;

        PassingData.setup_aspect_PointerOfThemeSelectedInComboBox = 0;
        PassingData.setup_aspect_sample_text_color = PassingData.current_text_color;
        PassingData.setup_aspect_sample_back_color = PassingData.current_background_color;
        PassingData.setup_aspect_sample_border_color = PassingData.current_border_color;
        PassingData.setup_aspect_apply_button_enabled = false;
        PassingData.setup_aspect_save_button_enabled = false;
        PassingData.setup_aspect_restore_button_enabled = false;

        //SetButtons to disabled

        Button ApplyButton = findViewById(R.id.setup_aspect_Apply_button);
        Button SaveButtton = findViewById(R.id.setup_aspect_save_button);
        Button RestoButton = findViewById(R.id.setup_aspect_restore_button);
        ApplyButton.setEnabled(false);
        SaveButtton.setEnabled(false);
        RestoButton.setEnabled(false);
        //Set comboBox to "Light-Side" theme
        Spinner spinner = findViewById(R.id.comboBox);
        spinner.setSelection(0);
        //Set sampleText to "Light-Side" theme
        TextView sampleText = findViewById(R.id.setup_aspect_sample_text);
        LinearLayout sampleBox = findViewById(R.id.setup_aspect_sample_box);
        sampleText.setTextColor(PassingData.setup_aspect_sample_text_color);
        sampleText.setBackgroundColor(PassingData.setup_aspect_sample_back_color);
        sampleBox.setBackgroundColor(PassingData.current_border_color);
        sampleText.invalidate();
        sampleBox.invalidate();
        //Set UI to "Light-Side" theme
    }

    public void onClickAplicar(View v) {
        Aplicar();
        SaveCurrentColorsInSharedPreferences();
    }

    public void Aplicar() {

        PassingData.current_theme_Name = PassingData.themeList.get(PassingData.setup_aspect_PointerOfThemeSelectedInComboBox).getName();
        PassingData.current_background_color = PassingData.setup_aspect_sample_back_color;
        PassingData.current_text_color = 0xFF000000 | PassingData.setup_aspect_sample_text_color;
        PassingData.current_border_color = PassingData.setup_aspect_sample_border_color;

        PassingData.setup_aspect_apply_button_enabled = false;
        PassingData.setup_aspect_restore_button_enabled = true;
        Button ApplyButton = findViewById(R.id.setup_aspect_Apply_button);
        Button RestoButton = findViewById(R.id.setup_aspect_restore_button);
        ApplyButton.setEnabled(false);
        RestoButton.setEnabled(true);



    }
    public void SaveCurrentColorsInSharedPreferences()
    {

        SharedPreferences preferences = getSharedPreferences("config", Context.MODE_PRIVATE);

        if(preferences!=null)
        {
            SharedPreferences.Editor editor = preferences.edit();
            if(editor!=null) {
                editor.putString("current_theme_Name", PassingData.current_theme_Name);
                editor.putInt("current_text_color", PassingData.current_text_color);
                editor.putInt("current_background_color", PassingData.current_background_color);
                editor.putInt("current_border_color", PassingData.current_border_color);

                editor.apply();
            }
        }
    }

    public void onClickCancelar(View v) {
        finish();
    }

    private void showDialogSaveTheme(String tittle, String newName) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(tittle);

        // Set up the input
        final EditText input = new EditText(this);
        input.setText(newName);
        // Specify the type of input expected; this, for example, sets the input as a password, and will mask the text
        input.setInputType(InputType.TYPE_CLASS_TEXT);
        builder.setView(input);

        // Set up the buttons
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                m_Text = input.getText().toString();
                PassingData.setup_aspect_save_button_enabled = false;
                Button SaveButton = viewPager.findViewById(R.id.setup_aspect_save_button);
                SaveButton.setEnabled(false);

                Theme theme = new Theme(m_Text, PassingData.setup_aspect_sample_back_color, PassingData.setup_aspect_sample_text_color, PassingData.setup_aspect_sample_border_color);
                PassingData.themeList.add(theme);
                ((Spinner)viewPager.findViewById(R.id.comboBox)).setSelection(PassingData.themeList.size()-1);
                JSONArray jsonArray = PassingData.themeList_To_JSonArray(PassingData.themeList, 3);
                PassingData.JSonArray_To_File(jsonArray);
                Aplicar();
            }
        });
        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });

        builder.show();
    }
}
