package com.orparga.electricplan;

public interface Row_Import_Plane_Manager {
    abstract public void row_erase(Row_Import_Plane row_import_plane);
    abstract public void row_plane_accepted(Row_Import_Plane row_import_plane);
    abstract public void row_plane_declined(Row_Import_Plane row_import_plane);
    abstract public void row_new_project_requested(Row_Import_Plane row_import_plane);
    }
