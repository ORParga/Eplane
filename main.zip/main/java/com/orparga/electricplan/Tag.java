package com.orparga.electricplan;

import android.net.Uri;
import android.view.View;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;


public class Tag {
    public String Name="";
    public ArrayList<Tag> SubTags;

    public Tag (){
        Name="";
        SubTags=new ArrayList<>();
    }
    public Tag (String Name){
        this.Name=Name;
        SubTags=new ArrayList<>();
    }
    public Tag (String Name,Tag... SubTag){
        this.Name=Name;
        SubTags=new ArrayList<Tag>();
        for(Tag currentTag:SubTag)SubTags.add(currentTag);
    }
    public Tag (JSONObject jsonTag){
        JSONArray jsonArraySubTags;
        try {
            Name=jsonTag.getString("Name");

            jsonArraySubTags=jsonTag.getJSONArray("SubTags");
            SubTags=new ArrayList<Tag>();
            for (int n=0;n<jsonArraySubTags.length();n++) {
                SubTags.add(new Tag(jsonArraySubTags.getJSONObject(n)));
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    public void add (Tag subTag) {
        SubTags.add(subTag);
    }
    public Tag get (int index){
        return SubTags.get(index);
    }
    public int size (){
        return SubTags.size();
    }

    public JSONObject To_JSONObject() {

        JSONObject jsonTag=new JSONObject();
        JSONArray jsonArraySubTag=new JSONArray();
        try {
            jsonTag.put("Name",Name);
            for(int n=0;n<SubTags.size();n++)
            {
                jsonArraySubTag.put(SubTags.get(n).To_JSONObject());
            }
            jsonTag.put("SubTags",jsonArraySubTag);
        } catch (JSONException e) {
            e.printStackTrace();
            return null;
        }
        return jsonTag;
    }

    public void add(ArrayList<String> tagsCreated) {
        for(String tagName:tagsCreated)
        {
            Tag tag=new Tag(tagName);
            add(tag);
        }
    }

    /**
     * contiene un String con el nombre del tag que ve el usuario
     * un "boolean" que indica si el Tag está seleccionado
     * o deseleccionado y un puntero al textView con el que
     *se relacciona
     */
    public static class ListedTag
    {
        String name;
        boolean Selected;
        TextView textView;

        /**
         * contiene un String con el nombre del tag que ve el usuario
         * un "boolean" que indica si el Tag está seleccionado
         * o deseleccionado y un puntero al textView con el que
         * se relacciona
         *
         * @param name Nombre o etiqueta que se mostraría al usuario
         * @param selected Indica asi el usuario ha seleccionado o deseleccionado el Tag
         * @param textView TextView que se muestra al usuario
         */
        public ListedTag(String name, boolean selected, TextView textView) {
            this.name = name;
            Selected = selected;
            this.textView = textView;
        }
    }
    public static ListedTag getTagfromView(ArrayList<Tag.ListedTag> listedTags,View tagView)
    {
        for(int n=0;n<listedTags.size();n++)
        {
            if(listedTags.get(n).textView==tagView)
            {
                return listedTags.get(n);
            }
        }
        return null;
    }

    public String getReducedPath_From_Uri (Uri uri){
        String path=uri.getPath();
        String reducedPath=path;
        int index=path.indexOf(':');
        if(index!=-1)
            reducedPath=path.substring(index+1);
        return reducedPath;
    }
    public String getExtensionFromUri(Uri uri){
        String ext="";
        String path=uri.getPath();

        int index=path.lastIndexOf('.');
        if(index!=-1)
            ext=path.substring(index+1);

        return ext;
    }
}
