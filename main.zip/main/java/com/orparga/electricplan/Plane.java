package com.orparga.electricplan;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class Plane {
    protected String Name="";
    public String getName() {return Name;}
    public void setName(String name) { Name = name; }

    ArrayList<PlaneVersion> v;
    ArrayList<Tag> tagList;

    public Plane (){
        v=new ArrayList<PlaneVersion>();
    }
    public Plane (JSONObject jsonObject) {
        JSONArray PlaneVersionJSONArray,jsonTagList;
        try{
            setName(jsonObject.getString("Name"));
            PlaneVersionJSONArray=jsonObject.getJSONArray("v");
            v=new ArrayList<PlaneVersion>();
            for(int n=0;n<PlaneVersionJSONArray.length();n++)
            {
                JSONObject currentObject =PlaneVersionJSONArray.getJSONObject(n);
                PlaneVersion currentPlaneVersion= new PlaneVersion(currentObject);
                v.add(currentPlaneVersion);
            }
            jsonTagList=jsonObject.getJSONArray("tag");
            tagList=new ArrayList<Tag>();
            for(int n=0;n<jsonTagList.length();n++)
            {
                JSONObject currentObject =jsonTagList.getJSONObject(n);
                Tag currentTag= new Tag(currentObject);
                tagList.add(currentTag);
            }
        }
        catch (JSONException e)
        {
            e.printStackTrace();
        }
    }
    public Plane (String planeName)
    {
        Name=planeName;
        v=new ArrayList<PlaneVersion>();
        tagList=new ArrayList<Tag>();
    }
    public void add (PlaneVersion planeVersion){
        v.add(planeVersion);
    }
    /**
     * Devuelve una version del plano
     * @param index el numero de version de plano solicitado
     * @return PlaneVersion
     */
    public PlaneVersion get (int index){
        return v.get(index);
    }
    /**
     * Devuelve la última version del plano plano
     * @return PlaneVersion
     */
    public PlaneVersion get (){
        return v.get(v.size()-1);
    }
    public PlaneVersion last (){
        return v.get(v.size()-1);
    }

    public JSONObject To_JSONObject() {
        JSONObject jsonPlane=new JSONObject();

        try {
            JSONArray jsonArrayPlaneList = new JSONArray();
            JSONArray jsonArrayTagList = new JSONArray();

            if(v!=null){
                for (int n=0;n<v.size();n++){
                    JSONObject jsonObject=v.get(n).To_JSONObject();
                    jsonArrayPlaneList.put(jsonObject);
                }}
            if(tagList!=null){
                for (int n=0;n<tagList.size();n++){
                    JSONObject jsonObject=tagList.get(n).To_JSONObject();
                    jsonArrayTagList.put(jsonObject);
                }}

            jsonPlane.put("Name",Name);
            jsonPlane.put("v",jsonArrayPlaneList);
            jsonPlane.put("tag",jsonArrayTagList);

        } catch (JSONException e) {
            e.printStackTrace();
        }

        return jsonPlane;
    }
}
