package com.orparga.electricplan;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.AttributeSet;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;

import static android.content.Context.LAYOUT_INFLATER_SERVICE;

public class Tag_ViewContainer extends ViewGroup {
    Context context;
    Plane plane;
    Tag_ViewContainerManager tag_viewContainerManager;
    LayoutInflater inflater;
    String testingCustomView;
    Tag_ViewContainer tagListContainer;
    private String[] TAGS_Sugested;
    protected ArrayList<String> TagsCreated;public ArrayList<String> getTagsCreated (){
        return (ArrayList<String>)TagsCreated.clone();}


     public Tag_ViewContainer (Context context, AttributeSet attrs){
        super(context,attrs);
            TypedArray a = context.getTheme().obtainStyledAttributes(
                    attrs,
                    R.styleable.Tag_ViewContainer,
                    0, 0);

            try {
                testingCustomView = a.getString(R.styleable.Tag_ViewContainer_testingCustomView);
                //bitmapFullPath_initial= a.getString(R.styleable.Zoom6_path);
            } finally {
                a.recycle();
            }

            this.context=context;
            initGlobals();
        }

    @Override
    protected void onLayout(boolean changed, int l, int t, int r, int b) {
        final int count = getChildCount();
        int curWidth, curHeight, curLeft, curTop, maxHeight;

        //get the available size of child view
        final int childLeft = this.getPaddingLeft();
        final int childTop = this.getPaddingTop();
        final int childRight = this.getMeasuredWidth() - this.getPaddingRight();
        final int childBottom = this.getMeasuredHeight() - this.getPaddingBottom();
        final int childWidth = childRight - childLeft;
        final int childHeight = childBottom - childTop;

        maxHeight = 0;
        curLeft = childLeft;
        curTop = childTop;

        for (int i = 0; i < count; i++) {
            View child = getChildAt(i);

            if (child.getVisibility() == GONE)
                continue;

            //Get the maximum size of the child
            child.measure(MeasureSpec.makeMeasureSpec(childWidth, MeasureSpec.AT_MOST), MeasureSpec.makeMeasureSpec(childHeight, MeasureSpec.AT_MOST));
            curWidth = child.getMeasuredWidth();
            curHeight = child.getMeasuredHeight();

            //do the layout
            child.layout(curLeft, curTop, curLeft + curWidth, curTop + curHeight);
            curTop += curHeight;
        }
    }
    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        int count = getChildCount();
        // Measurement will ultimately be computing these values.
        int maxHeight = 0;
        int maxWidth = 0;
        int childState = 0;
        int mLeftWidth = 0;
        int rowCount = 0;

        // Iterate through all children, measuring them and computing our dimensions
        // from their size.
        for (int i = 0; i < count; i++) {
            final View child = getChildAt(i);

            if (child.getVisibility() == GONE)
                continue;

            // Measure the child.
            measureChild(child, widthMeasureSpec, heightMeasureSpec);
            maxWidth += Math.max(maxWidth, child.getMeasuredWidth());
            mLeftWidth += child.getMeasuredWidth();

                maxHeight += child.getMeasuredHeight();
                rowCount++;
            childState = combineMeasuredStates(childState, child.getMeasuredState());
        }

        // Check against our minimum height and width
        maxHeight = Math.max(maxHeight, getSuggestedMinimumHeight());
        maxWidth = Math.max(maxWidth, getSuggestedMinimumWidth());

        // Report our final dimensions.
        setMeasuredDimension(resolveSizeAndState(maxWidth, widthMeasureSpec, childState),
                resolveSizeAndState(maxHeight, heightMeasureSpec, childState << MEASURED_HEIGHT_STATE_SHIFT));
    }
    private void initGlobals(){

            inflater = (LayoutInflater)context.getSystemService(LAYOUT_INFLATER_SERVICE);
            TAGS_Sugested=context.getResources().getStringArray(R.array.tag_sugestions);
            TagsCreated=new ArrayList<String>();
            tagListContainer=this;
        }

    public void Ini_Tag_ViewContainer(Tag_ViewContainerManager tag_viewContainerManager, Plane plane){
        this.plane=plane;
        this.tag_viewContainerManager=tag_viewContainerManager;
        IniTagListFromPlane();
    }

    private  void IniTagListFromPlane() {
       TagsCreated=new ArrayList<String>();
        //busca la zona de la "Ficha" dode el usuario podrá introducir los Tags de búsqueda rápida
        tagListContainer.removeAllViews();

        for(Tag tag:plane.tagList){
            TagsCreated.add(tag.Name);
            AddFixedTag(tag.Name);
        }
        addNewTagView(tagListContainer);
    }

    protected  void FixTagView( String tagText, Tag_ViewContainer container,LinearLayout row_new_tag_converting_to_fixed_tag){

        //Convierte el tag de tipo "newTag" en tag de tipo "fixedTag"
        View fixedtagContainer = inflater.inflate(R.layout.row_fixed_tag, null);
        TextView fixedTag=fixedtagContainer.findViewById(R.id.Text_row_fixedTAG);
        ImageView fixedDelete=fixedtagContainer.findViewById(R.id.image_delete);
        fixedTag.setText(tagText);
        fixedDelete.setOnClickListener(onDeleteListener);

        //Crea un nuevo tag de tipo "newTag"
        View tagContainer = inflater.inflate(R.layout.row_new_tag, null);
        //LinearLayout tagListContainer=container.findViewById(R.id.tag_list_container);
        container.removeView(row_new_tag_converting_to_fixed_tag);
        container.addView(fixedtagContainer);
    }
    protected void AddFixedTag (String tagText){

        View fixedtagContainer = inflater.inflate(R.layout.row_fixed_tag, null);
        TextView fixedTag=fixedtagContainer.findViewById(R.id.Text_row_fixedTAG);
        ImageView fixedDelete=fixedtagContainer.findViewById(R.id.image_delete);
        fixedTag.setText(tagText);
        fixedDelete.setOnClickListener(onDeleteListener);
        tagListContainer.addView(fixedtagContainer);
    }

    private void addNewTagView(Tag_ViewContainer tagListContainer) {

        AutoCompleteTextView tagView;
        //Crea el contenedor del tag editable
        View tagContainer = inflater.inflate(R.layout.row_new_tag, null);
        //Crea unespacio donde el usuario podrá editar un nuevo tag basado en un View editable
        // y con ventana de sugerencias
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(context,
                R.layout.simple_dropdown_item, TAGS_Sugested);
        tagView = (AutoCompleteTextView)tagContainer.findViewById(R.id.row_TAG);
        tagView.setThreshold(0);
        tagView.setAdapter(adapter);
        tagView.setImeActionLabel("Custom text", KeyEvent.KEYCODE_ENTER);
        tagView.setOnKeyListener(onKey_TagView);
        tagView.addTextChangedListener(textWatcher_tagView);
        String textTAG=tagView.getText().toString().toLowerCase();
        int index=TagsCreated.indexOf(textTAG);
        if(index!=-1)
        {
            tagView.setText("");
            for (String s : TAGS_Sugested) {
                index = TagsCreated.indexOf(s);
                if (index == -1) {
                    tagView.setText(s);
                    break;
                }
            }
        }
        else
        {
            tagView.setText(textTAG);
        }
        //Agrega el boton"OK"
        ImageView btnOK=tagContainer.findViewById(R.id.row_new_tag_btn_ok);
        btnOK.setOnClickListener(onOKListener);
        btnOK.setVisibility(View.VISIBLE);
        //Una vez está preparado el espacio para introducir el TAG, lo añade al contenedor principal
        tagListContainer.addView(tagContainer);
        tagContainer.invalidate();
        //Informa al creador del TagContainer que hemos sido modificados
        tag_viewContainerManager.TagList_Modified();
    }

    View.OnKeyListener onKey_TagView =new View.OnKeyListener() {
        public boolean onKey(View v, int keyCode, KeyEvent event) {
            {
                // If the event is a key-down
                if (event.getAction() == KeyEvent.ACTION_DOWN)
                {
                    String textTAG=((AutoCompleteTextView)v).getText().toString().toLowerCase();
                    int index=TagsCreated.indexOf(textTAG);
                    TextView errorText=findViewById(R.id.text_error_row_imported_plane);
                    ImageView okView=findViewById(R.id.row_new_tag_btn_ok);
                    if(index==-1)
                    {
                        //Si no está en la lista permite el nuevo Tag
                        errorText.setVisibility(View.INVISIBLE);
                        okView.setVisibility(View.VISIBLE);
                        if (keyCode == KeyEvent.KEYCODE_ENTER) {
                            // Perform action on key press
                            TagsCreated.add(textTAG);
                            ViewParent row_new_tag_current=v.getParent();
                            ViewParent tag_list_container_current=row_new_tag_current.getParent();
                            FixTagView(textTAG,((Tag_ViewContainer)tag_list_container_current),(LinearLayout)row_new_tag_current);

                            addNewTagView((Tag_ViewContainer)tag_list_container_current);
                            return true;
                        }
                    }
                    //Si el tag está ya está en la lista
                    //muestra un mensaje de error
                    Resources res=context.getResources();
                    errorText.setText(res.getString(R.string.activity_add_file_3_text_error_A)+" "
                            +textTAG+" "
                            +res.getString(R.string.activity_add_file_3_text_error_B));
                    errorText.setVisibility(View.VISIBLE);
                    okView.setVisibility(View.INVISIBLE);
                    return true;

                }
                return false;
            }
        }};
    TextWatcher textWatcher_tagView =new TextWatcher() {

        public void afterTextChanged(Editable s) {
            String textTAG=s.toString().toLowerCase();
            int index=TagsCreated.indexOf(textTAG);
            TextView errorText=findViewById(R.id.text_error_row_imported_plane);
            ImageView okView=findViewById(R.id.row_new_tag_btn_ok);

            if(index!=-1)
            {
                //Si el tag está ya está en la lista
                //muestra un mensaje de error
                Resources res=context.getResources();
                if(errorText!=null) {
                    errorText.setText(res.getString(R.string.activity_add_file_3_text_error_A) + " "
                            + textTAG + " "
                            + res.getString(R.string.activity_add_file_3_text_error_B));
                    errorText.setVisibility(View.VISIBLE);
                }
                if(okView!=null)okView.setVisibility(View.INVISIBLE);
            }
            else {
                //Si no está en la lista permite el nuevo Tag
                if(errorText!=null)errorText.setVisibility(View.INVISIBLE);
                if(okView!=null)okView.setVisibility(View.VISIBLE);
            }
        }

        public void beforeTextChanged(CharSequence s, int start, int count, int after) {

        }

        public void onTextChanged(CharSequence s, int start, int before, int count) {
        }
    };

    View.OnClickListener onDeleteListener =new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            onClickDelete(v);
        }
    };
    View.OnClickListener onOKListener=new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            onClickOK(v);
        }
    };
    protected void onClickDelete(View v){
        Tag_ViewContainer tagListContainer=findViewById(R.id.tag_view_container);
        LinearLayout ll=(LinearLayout)v.getParent();
        TextView tv=ll.findViewById(R.id.Text_row_fixedTAG);
        String text=tv.getText().toString();
        int index=TagsCreated.indexOf(text);
        if(index!=-1)TagsCreated.remove(index);
        tagListContainer.removeView(ll);
        UpdateTxTTagError();
        //Informa al creador del TagContainer que hemos sido modificados
        tag_viewContainerManager.TagList_Modified();
    }
    public void onClickOK(View v){
        // Perform action on key press
        String textTAG=((TextView)findViewById(R.id.row_TAG)).getText().toString().toLowerCase();

        TagsCreated.add(textTAG);
        ViewParent row_new_tag_current=v.getParent();
        Tag_ViewContainer tag_list_container_current=(Tag_ViewContainer)row_new_tag_current.getParent();
        FixTagView(textTAG,tag_list_container_current,(LinearLayout)row_new_tag_current);

        addNewTagView((Tag_ViewContainer)tag_list_container_current);
    }
    /**
     * Actualiza el cuadro de texto de error en Tag revisando el listado de tags en memoria
     * @return Devuelve true si no hay error y por lo tanto se ha ocultado
     * el mensaje de error, Devuelve false en caso de error.
     */
    private boolean UpdateTxTTagError() {

        AutoCompleteTextView v = findViewById(R.id.row_TAG);
        String textTAG = ((AutoCompleteTextView) v).getText().toString().toLowerCase();
        int index = TagsCreated.indexOf(textTAG);
        TextView errorText = ((LinearLayout)getParent()).findViewById(R.id.text_error_row_imported_plane);
        ImageView okView = findViewById(R.id.row_new_tag_btn_ok);
        if (index == -1) {
            errorText.setVisibility(View.INVISIBLE);
            okView.setVisibility(View.VISIBLE);
            //Si no está en la lista permite el nuevo Tag

            return true;
        }
        //Si el tag está ya está en la lista
        //muestra un mensaje de error
        Resources res = context.getResources();
        errorText.setText(res.getString(R.string.tag_view_container_text_error_A) + " "
                + textTAG + " "
                + res.getString(R.string.tag_view_container_text_error_B));
        errorText.setVisibility(View.VISIBLE);
        okView.setVisibility(View.INVISIBLE);
        return false;

    }

}
