package com.orparga.electricplan;

import android.graphics.Bitmap;

public class ExistingPlaneRow {
    private String sPlanePath;
    private String sPlaneName;

    public Plane getPlane() {
        return plane;
    }

    private Plane plane;

    public String getsPlanePath() {
        return sPlanePath;
    }

    public String getsPlaneName() {
        return sPlaneName;
    }

    public Bitmap getBitmapPlan() {
        return bitmapPlan;
    }

    private Bitmap bitmapPlan;

    public ExistingPlaneRow(String sPlanPath, String sPlaneName, Plane plane)
    {
        this.sPlanePath =sPlanPath;
        this.sPlaneName = sPlaneName;
        this.plane=plane;
    }
}
