package com.orparga.electricplan;

import android.Manifest;
import android.app.Activity;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.Resources;
import android.os.Build;
import android.os.Environment;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.text.InputType;
import android.widget.EditText;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.TimeZone;
import java.util.regex.Pattern;

class E_Plane_Project_PathInfo{

    private String FullPath;
    private String GeneralFolderPath;
     private String ProjectFolderPath;
     private String ProjectFileName;
     private String ProjectBasicName;
     private String ProjectBasicNameWithoutNumber;
     private String Extension;
     private String NumberInName;
     private int iNumberInName;

     public String getFullPath() {return FullPath;}
    public String getGeneralFolder() {
     return GeneralFolderPath;
    }
    public String getProjectFolderPath() {
     return ProjectFolderPath;
    }
    public String getProjectFileName() { return ProjectFileName; }
     public String getProjectBasicName() {return ProjectBasicName; }
     public String getProjectBasicNameWithoutNumber() {return ProjectBasicNameWithoutNumber; }
    public String getNumberInName() {return NumberInName;}
     public int getiNumberInName() { return iNumberInName; }
     public String getExtension() { return Extension; }


    public E_Plane_Project_PathInfo (String FullPath){
        setFullPath(FullPath);
    }

     public E_Plane_Project_PathInfo(String generalFolderName, String project_name) {

         ProjectBasicName=project_name;

         GeneralFolderPath= Environment.getExternalStorageDirectory().toString() + "/" +generalFolderName;
         ProjectFolderPath=GeneralFolderPath+"/"+ProjectBasicName;
         Extension=".json";
         ProjectFileName=ProjectBasicName+Extension;
         FullPath=ProjectFolderPath+"/"+ProjectFileName;
         try {
             NumberInName=ProjectBasicName.substring(ProjectBasicName.length()-2);
             iNumberInName=Integer.parseInt(NumberInName);
             ProjectBasicNameWithoutNumber=ProjectBasicName.substring(0,ProjectBasicName.length()-2);
         } catch (NumberFormatException|IndexOutOfBoundsException e) {
             NumberInName="";
             iNumberInName=0;
             ProjectBasicNameWithoutNumber=ProjectBasicName;
         }
     }

     public void setFullPath(String fullPath) {
     this.FullPath=fullPath;
     int index=FullPath.lastIndexOf('/');
     ProjectFolderPath=FullPath.substring(0,index);
     ProjectFileName=FullPath.substring(index+1);
     index=FullPath.lastIndexOf('.') ;
     Extension=FullPath.substring(index);
     index=ProjectFolderPath.lastIndexOf('/') ;
     GeneralFolderPath=ProjectFolderPath.substring(0,index);
     index=ProjectFileName.lastIndexOf('.') ;
     ProjectBasicName=ProjectFileName.substring(0,index);

         try {
             NumberInName=ProjectBasicName.substring(ProjectBasicName.length()-2);
             iNumberInName=Integer.parseInt(NumberInName);
             ProjectBasicNameWithoutNumber=ProjectBasicName.substring(0,ProjectBasicName.length()-2);
         } catch (NumberFormatException|IndexOutOfBoundsException e) {
             NumberInName="";
             iNumberInName=0;
             ProjectBasicNameWithoutNumber=ProjectBasicName;
         }
    }

     public void setBasicProjectName(String GeneralFolderPath,String ProjectBasicName) {

         this.ProjectBasicName=ProjectBasicName;

         this.GeneralFolderPath = GeneralFolderPath;
         ProjectFolderPath=GeneralFolderPath+"/"+ProjectBasicName;
         ProjectFileName=ProjectBasicName+".json";
         FullPath=ProjectFolderPath+"/"+ProjectFileName;
         Extension=".json";
         try {
             NumberInName=ProjectBasicName.substring(ProjectBasicName.length()-2);
             iNumberInName=Integer.parseInt(NumberInName);
             ProjectBasicNameWithoutNumber=ProjectBasicName.substring(0,ProjectBasicName.length()-2);
         } catch (NumberFormatException|IndexOutOfBoundsException e) {
             NumberInName="";
             iNumberInName=0;
             ProjectBasicNameWithoutNumber=ProjectBasicName;
         }
     }
 }

public class E_Plane_Project {
    String AppVersion = "0";
    String User = "";
    protected String ProjectName = "";
    String APP_Folder_Name = "";
    ArrayList<Plane> planeList=new ArrayList<Plane>();
    Overprinted overprinted;
    Tag Jerarquia;

    E_Plane_Project_PathInfo ProjectPathInfo;
    E_Plane_Project_PathInfo ProjectPathInfo_Loading;



    public enum RETURN_VALUE {OK,
        CALLBACK_INVOKED,
        FAILURE,
        IOEXCEPTION,
        JSON_SYNTAX,
        NEW_PROJECT_INVOKED,
        PERMISION_DENIED,
        ALREADY_EXISTS,
        IS_THE_LAST,
        INVALID_CARACTERES,
        NOT_EXISTS,
        PLANE_REMOVED,
        PLANE_VERSION_REMOVED,
        NOT_A_STRING
    }

    private static final int NAME_UNUSEFUL=0;
    private static final int NAME_VALID_FOR_PROJECT_NAME=1;
    private static final int NAME_VALID_FOR_PLANE_NAME=2;
    private static final int NAME_VALID_FOR_PLANE_FILE=4;

    final String DEFAULT_USER = "Default_User";
    final String DEFAULT_VERSION = "0";
    final String DEFAULT_PROJECT_NAME= "Project_01";
    final String DEFAULT_APP_FOLDER_NAME = "E-Plane";

    ArrayList<String> Last_Error_Plane_Version_Removed;
    ArrayList<String> Last_Error_Plane_Removed;

    public E_Plane_Project() {
        AppVersion = DEFAULT_VERSION;
        User = DEFAULT_USER;
        ProjectName = DEFAULT_PROJECT_NAME;
        APP_Folder_Name = DEFAULT_APP_FOLDER_NAME;

        planeList = new ArrayList<Plane>();
        overprinted = new Overprinted();
        Jerarquia = new Tag();

        ProjectPathInfo=new E_Plane_Project_PathInfo(DEFAULT_APP_FOLDER_NAME,DEFAULT_PROJECT_NAME);
    }

    public E_Plane_Project(String GeneralFolderName,String ProjectBasicName) {

        ProjectPathInfo=new E_Plane_Project_PathInfo(GeneralFolderName,ProjectBasicName);
        User = DEFAULT_USER;
        ProjectName=ProjectBasicName;
        APP_Folder_Name=GeneralFolderName;

        planeList = new ArrayList<Plane>();
        overprinted = new Overprinted();
        Jerarquia = new Tag();

        ProjectPathInfo=new E_Plane_Project_PathInfo(GeneralFolderName,ProjectBasicName);
    }

    public E_Plane_Project(JSONObject jsonObject) {
        From_JSONObject(jsonObject);
    }

    public void From_JSONObject(JSONObject json_E_Plane_Project) {

        JSONArray planeJSONArray;
        JSONObject jsonOverprinted;
        JSONObject jsonJerarquia;

        try {
            AppVersion = (String) json_E_Plane_Project.get("AppVersion");
        } catch (JSONException e) {
            AppVersion = DEFAULT_VERSION;
        }

        try {
            User = (String) json_E_Plane_Project.get("User");
        } catch (JSONException e) {
            User = DEFAULT_USER;
        }

        try {
            ProjectName = (String) json_E_Plane_Project.get("ProjectName");
        } catch (JSONException e) {
            ProjectName = DEFAULT_PROJECT_NAME;
        }

        try {
            APP_Folder_Name = (String) json_E_Plane_Project.get("APP_Folder_Name");
        } catch (JSONException e) {
            APP_Folder_Name = DEFAULT_APP_FOLDER_NAME;
        }

        try {
            planeJSONArray = (JSONArray) json_E_Plane_Project.getJSONArray("planeList");
        } catch (JSONException | IllegalArgumentException e) {
            planeJSONArray = null;
        }
        if (planeJSONArray != null) {
            planeList = new ArrayList<Plane>();
            for (int n = 0; n < planeJSONArray.length(); n++) {
                JSONObject jsonObject1;
                try {
                    jsonObject1 = planeJSONArray.getJSONObject(n);
                } catch (JSONException | IllegalArgumentException e) {
                    jsonObject1 = null;
                }

                Plane plane = new Plane(jsonObject1);
                planeList.add(plane);
            }
        }

        try {
            jsonOverprinted = (JSONObject) json_E_Plane_Project.getJSONObject("overprinted");
        } catch (JSONException e) {
            e.printStackTrace();
            jsonOverprinted = null;
        }
        overprinted = new Overprinted(jsonOverprinted);

        try {
            jsonJerarquia = (JSONObject) json_E_Plane_Project.getJSONObject("Jerarquia");
        } catch (JSONException e) {
            e.printStackTrace();
            jsonJerarquia = null;
        }
        overprinted = new Overprinted(jsonJerarquia);

        ProjectPathInfo=new E_Plane_Project_PathInfo(APP_Folder_Name,ProjectName);
    }

    public JSONObject To_JSONObject() {
        JSONObject jsonObject = new JSONObject();
        JSONArray jsonArrayPlaneList = new JSONArray();

        if (planeList != null) {
            for (int n = 0; n < planeList.size(); n++) {
                jsonArrayPlaneList.put(planeList.get(n).To_JSONObject());
            }
        }


        try {
            jsonObject.put("AppVersion", AppVersion);
            jsonObject.put("User", User);
            jsonObject.put("ProjectName", ProjectName);
            jsonObject.put("APP_Folder_Name", APP_Folder_Name);
            jsonObject.put("planeList", jsonArrayPlaneList);
            jsonObject.put("overprinted", overprinted.To_JSONObject());
            jsonObject.put("Jerarquia", Jerarquia.To_JSONObject());
        } catch (JSONException e) {
            e.printStackTrace();
            return null;
        }

        return jsonObject;
    }

    public RETURN_VALUE RP_Save_To_File(Activity act, int PERMISION_CODE, String FullPath) {
        SharedPreferences SP;
        if (ContextCompat.checkSelfPermission(act,
                Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
            if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                act.requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, PERMISION_CODE);
                //ask for permission
                return RETURN_VALUE.CALLBACK_INVOKED;
            } else {
                //No tenemos permiso de lectura del sistema de archivosContext
                return RETURN_VALUE.FAILURE;
            }
        } else {
            //Tenemos acceso al sistema de archivos
            try {
                return Save_To_File(act, FullPath);
            } catch (IOException e) {
                //Tenemos permiso de acceso al sistema de archivos
                //pero aún así ha habido un error
                e.printStackTrace();
                return RETURN_VALUE.IOEXCEPTION;
            }
        }
    }

    public RETURN_VALUE Update_Object_From_FileSystemIntegrity(){

        RETURN_VALUE return_value=RETURN_VALUE.OK;
        File folder;
        File file;
        int nPlane,nPlaneVersion;
        Plane plane;
        PlaneVersion planeVersion;

        Last_Error_Plane_Version_Removed =new ArrayList<>();
        Last_Error_Plane_Removed =new ArrayList<>();
        int nPlaneVersionsFailure;

        folder=new File(this.ProjectPathInfo.getProjectFolderPath());
        if(folder.exists()){
            for(nPlane=0;nPlane<this.planeList.size();nPlane++){
                plane=planeList.get(nPlane);
                nPlaneVersionsFailure=0;
                for(nPlaneVersion=0;nPlaneVersion<plane.v.size();nPlaneVersion++){
                    // PlaneVersion planeVersion:plane.v){
                    planeVersion=plane.v.get(nPlaneVersion);
                    file=new File(planeVersion.Path);
                    if(!file.exists()){
                        nPlaneVersionsFailure++;
                        Last_Error_Plane_Version_Removed.add(planeVersion.Path);
                        plane.v.remove(planeVersion);
                        nPlaneVersion--;
                        if(return_value!=RETURN_VALUE.PLANE_REMOVED)
                            return_value=RETURN_VALUE.PLANE_VERSION_REMOVED;
                    }
                }
                if(plane.v.size()==0){
                    Last_Error_Plane_Removed.add(plane.Name);
                    this.planeList.remove(plane);
                    nPlane--;
                    return_value=RETURN_VALUE.PLANE_REMOVED;
                }
            }
        }
        else return RETURN_VALUE.NOT_EXISTS;
        return return_value;
    }
    public RETURN_VALUE Save_To_File(Activity act, String FullPath) throws IOException{

        int index=FullPath.lastIndexOf('/');
        String FolderPath=FullPath.substring(0,index);
        File folder;
        File file;
        FileWriter fileWriter;
        BufferedWriter writer = null;

        JSONObject json_E_Plane = To_JSONObject();
        String jsonText = json_E_Plane.toString();

        try {
            folder =new File (FolderPath);
            folder.mkdirs();
            file = new File(FullPath);
            fileWriter = new FileWriter(file);
            writer = new BufferedWriter(fileWriter);
            writer.write(jsonText);

        } catch (IOException e) {
            e.printStackTrace();
            throw e;
        } finally {
            try {
                if (writer != null)
                    writer.close();
                return RETURN_VALUE.OK;
            } catch (IOException e) {
                e.printStackTrace();
                throw e;
            }
        }
    }

    public RETURN_VALUE Save_To_File() throws IOException{

        String FolderPath=ProjectPathInfo.getProjectFolderPath();
        File folder;
        File file;
        FileWriter fileWriter;
        BufferedWriter writer = null;

        JSONObject json_E_Plane = To_JSONObject();
        String jsonText = json_E_Plane.toString();

        try {
            folder =new File (FolderPath);
            folder.mkdirs();
            file = new File(ProjectPathInfo.getFullPath());
            fileWriter = new FileWriter(file);
            writer = new BufferedWriter(fileWriter);
            writer.write(jsonText);

        } catch (IOException e) {
            e.printStackTrace();
            throw e;
        } finally {
            try {
                if (writer != null)
                    writer.close();
                return RETURN_VALUE.OK;
            } catch (IOException e) {
                e.printStackTrace();
                throw e;
            }
        }
    }

    public RETURN_VALUE RP_Load_From_File(Activity act, int PERMISION_CODE, String FullPath) {
        SharedPreferences SP;
        if (ContextCompat.checkSelfPermission(act,
                Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
            if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                act.requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, PERMISION_CODE);
                //ask for permission
                return RETURN_VALUE.CALLBACK_INVOKED;
            } else {
                //No tenemos permiso de lectura del sistema de archivosContext
                return RETURN_VALUE.FAILURE;
            }
        } else {
            //Tenemos acceso de lectura al sistema de archivos
            return Load_From_File(act, FullPath);
        }
    }

    public RETURN_VALUE Write_External_Storage_Permision_Callback_For_Load_Project(AppCompatActivity act, int[] grantResults, String FullPath) {

        if (grantResults.length > 0
                && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            return Load_From_File(act, FullPath);
        } else {

            // permission denied, boo! Disable the
            // functionality that depends on this permission.

            Toast.makeText(act, act.getResources().getString(R.string.Toast_2),  Toast.LENGTH_SHORT).show();
            return RETURN_VALUE.PERMISION_DENIED;
        }
    }

    public RETURN_VALUE Load_From_File(Activity act, String FullPath) {

        return Load_From_File(act,FullPath,true);
    }

    /**Carga los datos del objeto E_Plane_project a partir de un archivo json
     * Asume que la app tiene acceso al sistema de archivos
     * @param act activity invocadora. Necesaria para crear un cuadro de dialogo "Crear projecto"
     *            en caso de que no exista el archivo recivido. Puede ser null si "createIfNotExists"
     *            es false y si se prescinden de los "Toast" de aviso en caso de error.
     * @param FullPath ruta completa al archivo .json del proyecto E_Plane_Project a cargar
     * @param createIfNotExists si la ruta no es correcta o el archivo está dañado, presenta un
     *                          cuadro de dialogo al usuario dando la opcion de crear uno nuevo
     * @return RETURN_VALUE.OK - si el proyecto se ha cargado satisfactoriamente
     * RETURN_VALUE.NOT_EXISTS - Si el proyecto no existe y "createIfNotExist" es false
     * RETURN_VALUE.IOEXCEPTION - Si ha ocurrido un error generico en la lecctura de archivos... tal vez falta permiso de lectura
     * RETURN_VALUE.JSON_SYNTAX - Un error de sintaxis dentro del archivo .json
     * RETURN_VALUE.NEW_PROJECT_INVOKED - Si se ha presentado el cuadro de dialogo al usuario dándole la opcion de crear un archivo nuevo
     */
    public RETURN_VALUE Load_From_File(Activity act, String FullPath, boolean createIfNotExists) {

        ProjectPathInfo_Loading = new E_Plane_Project_PathInfo(FullPath);

        String jsonString = null;
        try {
            File file = new File(FullPath);
            if (file.exists()) {
                FileReader fileReader = new FileReader(file);
                int size = (int) file.length();
                char[] buffer = new char[size];
                fileReader.read(buffer);

                jsonString = new String(buffer);
                JSONObject jsonProject = new JSONObject(jsonString);
                this.From_JSONObject(jsonProject);
            } else {
                //Si el archivo no existe, lo crea
                if(createIfNotExists)
                {
                    return Create_New_ProjectFolder_And_Save_Project(act);
                }
                return RETURN_VALUE.NOT_EXISTS;
            }

        } catch (IOException e) {
            e.printStackTrace();
            if(act!=null)Toast.makeText(act,act.getResources().getString(R.string.Toast_1),Toast.LENGTH_SHORT).show();
            return RETURN_VALUE.IOEXCEPTION;
        } catch (JSONException e) {
            if(createIfNotExists) {
                //Si el archivo esta corrupto, crea uno nuevo
                Alert_ProjectJson_damaged_and_create_new(act, ProjectPathInfo_Loading.getProjectBasicName());
            }
            else
            {
                if(act!=null)Toast.makeText(act,act.getResources().getString(R.string.Toast_4),Toast.LENGTH_SHORT).show();
                return RETURN_VALUE.JSON_SYNTAX;
            }
            return RETURN_VALUE.NEW_PROJECT_INVOKED;

        }
        return RETURN_VALUE.OK;
    }

    protected RETURN_VALUE Create_New_ProjectFolder_And_Save_Project(Activity act) throws IOException {

        File folder = new File(ProjectPathInfo_Loading.getProjectFolderPath());
        File file = new File(ProjectPathInfo_Loading.getFullPath());
        //Crea el direcorio y subdirectorios
        folder.mkdirs();
        //Crea el archivo .json del proyectos
        file.createNewFile();
        return Save_To_File(act,ProjectPathInfo_Loading.getFullPath());
    }
    protected RETURN_VALUE Create_New_ProjectFolder_And_Save_Project(Activity act,String NewBasicProjectName) throws IOException {

        RETURN_VALUE returnValue;

        File folder = new File(ProjectPathInfo_Loading.getGeneralFolder()+"/"+NewBasicProjectName);
        String newFullPath=ProjectPathInfo_Loading.getGeneralFolder()+"/"+NewBasicProjectName+"/"+NewBasicProjectName+".json";
        File file = new File(newFullPath);
        //Crea el direcorio y subdirectorios
        folder.mkdirs();
        //Crea el archivo .json del proyectos
        file.createNewFile();
        if((returnValue=Save_To_File(act,newFullPath))==RETURN_VALUE.OK) {
            //Si no ha saltado ninguna excepcion, guardamos la información de la ruta
            ProjectPathInfo.setBasicProjectName(ProjectPathInfo_Loading.getGeneralFolder(),NewBasicProjectName);
        }
        return returnValue;
    }


    protected void Alert_ProjectJson_damaged_and_create_new(final Activity act,final String DamagedProjectName)  {
        Resources res=act.getResources();
        String tittle = res.getString(R.string.e_plane_project_AlertDialogTittle)+" "+
                DamagedProjectName+" "+
                res.getString(R.string.e_plane_project_AlertDialogTittle2);
        String newBasicProjectName = findBasicProjectName();

        AlertDialog.Builder builder = new AlertDialog.Builder(act);
        builder.setTitle(tittle);

        // Set up the input
        final EditText input = new EditText(act);
        input.setText(newBasicProjectName);
        // Specify the type of input expected; this, for example, sets the input as a password, and will mask the text
        input.setInputType(InputType.TYPE_CLASS_TEXT);
        builder.setView(input);

        // Set up the buttons
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String m_Text = input.getText().toString();
                try {
                    if(RETURN_VALUE.OK==Create_New_ProjectFolder_And_Save_Project(act,m_Text))
                    {
                        ProjectName=ProjectPathInfo.getProjectBasicName();
                        PassingData.setBasicProjectName(act,PassingData.E_plane_project.ProjectName);
                    }
                    else
                    {
                        Toast.makeText(act,act.getResources().getString(R.string.Toast_3),Toast.LENGTH_SHORT).show();
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }

            }
        });
        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });

        builder.show();
    }

    //Fullpath incluya el nombre del directorio del proyecto y el nombre del archivo de proyecto.
    //para encontrar el siguiente numero de proyecto disponible con el mismo nombre
    protected String BasicProjectName_plus_01(E_Plane_Project_PathInfo ProjectPathInfo, int lastIndex) {
        String returnValue;

        returnValue = "" + lastIndex;
        if (returnValue.length() < 2) returnValue = "0" + returnValue;

        returnValue = ProjectPathInfo.getProjectBasicNameWithoutNumber() + returnValue;

        return returnValue;
    }

    protected String findBasicProjectName() {

        String newPath;
        String returnValue;
        String lastBasicProjectName = ProjectPathInfo_Loading.getProjectBasicName();

        int index = ProjectPathInfo_Loading.getiNumberInName();
        while (index<100) {
            returnValue = BasicProjectName_plus_01(ProjectPathInfo_Loading, index);
            newPath=ProjectPathInfo_Loading.getGeneralFolder()+"/"+returnValue;
            File folder=new File(newPath);
            if (!folder.exists()) return returnValue;
            newPath+="/"+returnValue+".json";
            File file=new File(newPath);
            if(!file.exists())return returnValue;
            index++;
        }
        return "";
    }

    public Plane add_Plane(String PicturePath)
    {
        String name=nameFromPath(PicturePath);
        Plane plane=new Plane(name);
        PlaneVersion planeVersion=new PlaneVersion(PicturePath);
        plane.add(planeVersion);
        add_Plane(plane);
        return plane;
    }
    public Plane add_Plane(Plane plane)
    {
        planeList.add(plane);
        return plane;
    }
    public void deletePlane(Plane plane,boolean deleteFileToo) {
        planeList.remove(plane);
        if(deleteFileToo){
            for(PlaneVersion planeVersion:plane.v) {
                File planeFile = new File(planeVersion.Path);
                if(planeFile.exists()){
                    planeFile.delete();
                }
            }
        }
    }
    public static String nameFromPath (String FilePath)
    {
        String name="default";
        int index1=FilePath.lastIndexOf('/');
        int index2=FilePath.lastIndexOf('.');
        if((index1!=-1)&&(index2!=-1)) name=FilePath.substring(index1+1,index2);

        return name;
    }

    /**
     * Compbueba si el nombre del plano es un nombre de plano válido
     * Esto es; que no contenga ningún carácter ilegal yque no esté repetido
     * @param newFileName nuevo nombre de plano
     * @return
     * RETURN_VALUE.OK si el nombre es válido
     * RETURN_VALUE.IS_THE_LAST el nombre se ha encontrado sólo en el último miembro de la lista
     * RETURN_VALUE.INVALID_CARACTERES
     * RETURN_VALUE.ALREADY_EXISTS
     */
    public RETURN_VALUE checkPlaneName (String newFileName)
    {
        if(newFileName==null)return RETURN_VALUE.NOT_A_STRING;
        if(newFileName.equals(""))return RETURN_VALUE.NOT_A_STRING;
        //Primero separamos las partes del archivo, extension..numero...
        FileName fn=new FileName(newFileName);
        //Observar que el nombre de Plano se diferencia del nombre de archivo en que no acepta "punto"
        boolean isSafePlaneName = Pattern.matches("^[^<>:;,.?\"*|/\\\\]+$", newFileName);
        if(!isSafePlaneName)return RETURN_VALUE.INVALID_CARACTERES;
        //Comprovamos si el nombre ya está en el listado de planos
        for(int nPlane=0;nPlane<planeList.size();nPlane++)
        {
            Plane plane=planeList.get(nPlane);

            if(fn.getNameWithoutExtension().toLowerCase().equals(plane.getName().toLowerCase()))
            {
                //Hay que restarle 1 a planeList.size() porque el último plane es
                //el plano que se está comparando
                if(nPlane==planeList.size()-1)return RETURN_VALUE.IS_THE_LAST;
                return RETURN_VALUE.ALREADY_EXISTS;
            }
        }
        return RETURN_VALUE.OK;
    }

    public RETURN_VALUE checkPlaneFileName(String FolderPath,String newFileName,String Extension) {

        if(newFileName==null)return RETURN_VALUE.NOT_A_STRING;
        if(newFileName.equals(""))return RETURN_VALUE.NOT_A_STRING;
        //Observar que el nombre de Plano se diferencia del nombre de archivo en que no acepta "punto"
        boolean isSafePlaneName = Pattern.matches("^[^<>:;,.?\"*|/\\\\]+$", newFileName);
        if(!isSafePlaneName)return RETURN_VALUE.INVALID_CARACTERES;

        String fullPath=FolderPath+"/"+newFileName+"."+Extension;
        File newFile=new File(fullPath);
        if(newFile.exists())return RETURN_VALUE.ALREADY_EXISTS;
        return RETURN_VALUE.OK;
    }
    /**
     * Devuelve un string con el momento actual en formato:yy/MM/dd_HH:mm:ss
     * @return Devuelve un string con el momento actual en formato:yy/MM/dd_HH:mm:ss
     */
    public static String getCurrentTime() {
        String date;

        SimpleDateFormat sdf = new SimpleDateFormat("yy/MM/dd_HH:mm:ss");
        sdf.setTimeZone(TimeZone.getTimeZone("GMT+2"));
        date = sdf.format(new Date());
        return date;
    }

    /**
     * Crea un listado de tags a partir de un listado de Strings. Ninguna jerarquía ni agrupamiento es tenido en cuenta
     * @param stringList listado de strings... deben ser todos diferentes y estar formados por caránceres válidos.
     *                   Ninguna comprovacion de seguridad es realizada
     * @return Devuelve un listado de objetos "Tag" sin "subTags"
     */
    public static ArrayList<Tag> getTagList_from_StringList(ArrayList<String> stringList) {
        ArrayList<Tag> tagList=new ArrayList<>();
        Tag currentTag;
        for(String string:stringList) {
            currentTag = new Tag(string);
            tagList.add(currentTag);
        }
        return tagList;
    }

}