package com.orparga.electricplan;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;

public class ThemeAdapter extends ArrayAdapter<Theme> {
    public ThemeAdapter(Context context, ArrayList<Theme> themeList){
        super(context,0,themeList);
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @Nullable ViewGroup parent) {
        return initView(position,convertView,parent);
    }

    @Override
    public View getDropDownView(int position, @Nullable View convertView, @Nullable ViewGroup parent) {
        return initView(position,convertView,parent);
    }

    public View initView(int position,View convertView,ViewGroup parent)
    {
        if( convertView==null){
            convertView= LayoutInflater.from(getContext()).inflate(R.layout.theme_spiner_row,parent,false);
        }

        LinearLayout ll_background_color=convertView.findViewById(R.id.theme_row_color_back);
        LinearLayout ll_text_color=convertView.findViewById(R.id.theme_row_color_text);
        TextView theme_name=convertView.findViewById(R.id.theme_row_name);

        Theme requestedTheme= getItem(position);

        if(requestedTheme!=null) {
            if(position==0)
            {
                //El comboBox no debe mostrar colores en su primera opcion
                ///puessto que "Nuevo tema" es el que se activará cuando el
                //ususario cambie los colores. por lo tanto, el Alpha será el máximo
                ll_background_color.setBackgroundColor(0x00000000);
                ll_text_color.setBackgroundColor(0x00000000);
            }
            else {
                //Los cuadraditos de muestra deben ser
                //los guardados en el theme asociado con el puntero "position"
                ll_background_color.setBackgroundColor(requestedTheme.getColor_background());
                ll_text_color.setBackgroundColor(requestedTheme.getColor_text());
            }
            theme_name.setText(requestedTheme.getName());
        }

        return convertView;
    }
}
