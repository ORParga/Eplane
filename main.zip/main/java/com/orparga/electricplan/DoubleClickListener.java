package com.orparga.electricplan;

import android.util.Log;
import android.view.View;

public abstract class DoubleClickListener implements View.OnClickListener {

    private static final long DOUBLE_CLICK_TIME_DELTA = 400;//milliseconds

    long lastClickTime = 0;
    @Override
    public void onClick(View v) {
        long clickTime = System.currentTimeMillis();
        long delta=clickTime - lastClickTime;
        if ( delta< DOUBLE_CLICK_TIME_DELTA){
            onDoubleClick(v);
            Log.wtf("onDoubleClick delta",""+delta);
        } else {
            onSingleClick(v);
            Log.wtf("onSingleClick delta",""+delta);
        }
        lastClickTime = clickTime;
    }

    public abstract void onSingleClick(View v);
    public abstract void onDoubleClick(View v);
}
