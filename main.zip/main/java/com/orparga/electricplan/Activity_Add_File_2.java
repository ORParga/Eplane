package com.orparga.electricplan;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

public class Activity_Add_File_2 extends AppCompatActivity {

    AppCompatActivity context;


    enum CHECKED {NEW,EXIST}
    CHECKED checked= CHECKED.NEW;
    boolean thereAreAnyPlane=false;

    RadioButton radioExisting;
    Spinner comboPlane;
    ArrayList<ExistingPlaneRow> existingPlanList;
    ExistingPlanAdapter existingPlanAdapter;
    EditText editPlaneName;
    TextView txtError;
    Button btnAtras,btnNext,btnFinish;
    AdapterView.OnItemSelectedListener onItemSelectedListener=new AdapterView.OnItemSelectedListener() {
        @Override
        public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
            ExistingPlaneRow existingPlaneRow =(ExistingPlaneRow) parent.getItemAtPosition(position);
           }

        @Override
        public void onNothingSelected(AdapterView<?> parent) {

        }
    };

    TextWatcher textWatcher=new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {

        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {

        }

        @Override
        public void afterTextChanged(Editable s) {
            updateUIaccordingToNewPlaneName();
        }
    };
    protected void updateUIaccordingToNewPlaneName()
    {

        txtError=findViewById(R.id.activity_add_file_2_txtError);
        editPlaneName=findViewById(R.id.activity_add_file_2_editText_newFile);
        btnFinish=findViewById(R.id.activity_add_file_2_btn_Finish);
        btnNext=findViewById(R.id.activity_add_file_2_btn_Next);
        String BasicFileNamename=editPlaneName.getText().toString();
        String FileName=BasicFileNamename+"png";
        CHECK_PROJECT_NAME_RETURN_VALUE ret=
                CHECK_PROJECT_NAME_RETURN_VALUE.checkFileName(
                        context,
                        PassingData.GENERAL_FOLDER_NAME,
                        PassingData.getBasicProjectName(),
                        "",
                        FileName);
        switch (ret) {
            case INVALID_CARACTERES:
                txtError.setVisibility(View.VISIBLE);
                txtError.setText(getResources().getString(R.string.activity_add_file_2_error_invalid));
                btnFinish.setEnabled(false);
                btnNext.setEnabled(false);
                break;
            case ALREADY_EXISTS:
                txtError.setVisibility(View.VISIBLE);
                txtError.setText(getResources().getString(R.string.activity_add_file_2_error_already_exists));
                btnFinish.setEnabled(false);
                btnNext.setEnabled(false);
                break;
            case TOO_SHORT:
                txtError.setVisibility(View.VISIBLE);
                txtError.setText(getResources().getString(R.string.activity_add_file_2_error_too_short));
                btnFinish.setEnabled(false);
                btnNext.setEnabled(false);
                break;
            default:
            case OK:
                txtError.setVisibility(View.INVISIBLE);
                btnFinish.setEnabled(true);
                btnNext.setEnabled(true);
                break;
        }
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_file_2);
        TextView tittle=findViewById(R.id.text_add_file_2_tittle);
        tittle.setText(PassingData.from_activity_project_name);

    }
    @Override
    protected void onResume() {
        super.onResume();
        PassingData.from_activity = PassingData.FROM_ACTIVITY.ADD_FILE_2_start;
        comboPlane = findViewById(R.id.combo_existing_plane);
        comboPlane.setEnabled(false);
        radioExisting = findViewById(R.id.radio_exist_add_file_2);
        radioExisting.setEnabled(false);

        //Se carga en el comboBox todos los planos
        //excepto el último, puesto que éste último es
        //la foto que acabamos de tomar
        if (PassingData.E_plane_project.planeList.size() > 1) {
            thereAreAnyPlane = true;
            comboPlane.setEnabled(true);
            radioExisting.setEnabled(true);
            existingPlanList = new ArrayList<>();
            int size = (PassingData.E_plane_project.planeList.size() - 1);
            for (int n = 0; n < size; n++) {
                Plane plane = PassingData.E_plane_project.planeList.get(n);
                ExistingPlaneRow epr = new ExistingPlaneRow(plane.get().Path, plane.Name, plane);
                existingPlanList.add(epr);
            }

            existingPlanAdapter = new ExistingPlanAdapter(this, existingPlanList);
            comboPlane.setAdapter(existingPlanAdapter);
            comboPlane.setOnItemSelectedListener(onItemSelectedListener);
        } else {
            thereAreAnyPlane = false;
            comboPlane.setEnabled(false);
            radioExisting.setEnabled(false);
        }
        //Carga el cuadro de texto de "nombre nuevo"
        editPlaneName = findViewById(R.id.activity_add_file_2_editText_newFile);
        String newPlaneName;
        E_Plane_Project.RETURN_VALUE return_value;
        //Primero, prueba a obtener el nombre del plano desde el nombre del archivo de imagen
        String oldPlaneName = E_Plane_Project.nameFromPath(PassingData.from_activity_plane_file_path);
        newPlaneName= checkAndCreatePlaneName(oldPlaneName);
        if(newPlaneName.equals("")) {
            //Si no puede obtener el nombre del archivo, prueba con el nombre por defecto en el xml de la acivity
            if (oldPlaneName.equals("")) oldPlaneName = editPlaneName.getText().toString();
            newPlaneName= checkAndCreatePlaneName(oldPlaneName);
        }
        editPlaneName.setText(newPlaneName);

    }

    /**
     * Comprueba si el nombre de archivo está en el listado de PassingData.E_plane_project
     * Crea un nombre de plano o archivo añadiendole un número al final de oldPlaneName
     * o sumandole una unididad si ya tiene numero al final
     * @param oldPlaneName Nombre de plano o archivo que se sua como base para crear uno nuevo
     * @return Nombre de archivo con un sufijo numerico
     */
    private String checkAndCreatePlaneName(String oldPlaneName) {

        String newPlaneName=oldPlaneName;
        E_Plane_Project.RETURN_VALUE return_value;
        do {
            return_value = PassingData.E_plane_project.checkPlaneName(oldPlaneName);
            if (return_value == E_Plane_Project.RETURN_VALUE.INVALID_CARACTERES)
                editPlaneName.setText("");
            else if (return_value == E_Plane_Project.RETURN_VALUE.ALREADY_EXISTS) {
                if (oldPlaneName.length() >= 2) {
                    int iNumber = 0;
                    String number = oldPlaneName.substring(oldPlaneName.length() - 2);
                    String nameWithoutnumber = oldPlaneName.substring(0, oldPlaneName.length() - 2);
                    try {
                        iNumber = Integer.parseInt(number);
                        iNumber++;
                    } catch (NumberFormatException e) {
                        nameWithoutnumber = oldPlaneName;
                        iNumber = 1;
                    }
                    if (iNumber < 10) number = "0" + iNumber;
                    else number = "" + iNumber;
                    newPlaneName = nameWithoutnumber + number;
                }
                else{
                    newPlaneName="";
                }
            }
        } while ((return_value != E_Plane_Project.RETURN_VALUE.OK)&(return_value != E_Plane_Project.RETURN_VALUE.IS_THE_LAST));

        return newPlaneName;
    }


    public void onClickRadioExist(View view) {
        ((RadioButton)view).setChecked(true);
        RadioButton New=findViewById(R.id.radio_new_add_file_2);
        btnFinish=findViewById(R.id.activity_add_file_2_btn_Finish);
        btnNext=findViewById(R.id.activity_add_file_2_btn_Next);

        New.setChecked(false);
        checked=CHECKED.EXIST;


        comboPlane.setEnabled(true);
        editPlaneName.setEnabled(false);
        btnFinish.setEnabled(true);
        btnNext.setEnabled(true);
    }
    public void onClickRadioNew(View view) {
        ((RadioButton)view).setChecked(true);
        RadioButton New=findViewById(R.id.radio_exist_add_file_2);
        New.setChecked(false);
        checked=CHECKED.NEW;

        updateUIaccordingToNewPlaneName();
        comboPlane.setEnabled(false);
        editPlaneName.setEnabled(true);
    }

    protected void newPlane (){

        //Crea la ruta de archivo al archivo nuevo
        String newName=editPlaneName.getText().toString();
        String newPath=FileHandling.createPngFilePath(newName);
        //Cambia el nombre del archivo temporal al nombre definitivo
        File file=new File(PassingData.from_activity_plane_file_path);
        File fileNewName=new File(newPath);
        if(file.exists())
        {
            if(file.renameTo(fileNewName))
            {
                //El archivo ha cambiado de nombre
                PassingData.from_activity_plane_name=newName;
                PassingData.from_activity_plane_file_path=newPath;
                PassingData.from_activity_plane.Name=newName;
                PassingData.from_activity_plane.get(0).Name=newName;
                PassingData.from_activity_plane.get(0).Path=newPath;
                try {
                    PassingData.E_plane_project.Save_To_File();
                } catch (IOException e) {
                    Toast.makeText(this,getResources().getString(R.string.error_al_guardar_archivo),Toast.LENGTH_SHORT).show();

                }
            }
            else
            {
                //el archivo no ha cambiado de nombre
            }
        }
    }
    protected void existingPlane (){
        //Guarda la ruta de archivo de la ultima foto tomada
        // en el array de PlaneVersion del plano seleccionado
        //y borra el último Plane de la lista, ya que este es la última foto tomada

        //Recupera el plano seleccionado del comboBox
        ExistingPlaneRow epr=(ExistingPlaneRow) comboPlane.getSelectedItem();
        Plane selectedPlane=epr.getPlane();
        PassingData.from_activity_plane=selectedPlane;
        //Crea una nueva version para añadirla al listado de versiones del plano seleccionado
        PlaneVersion planeVersion=new PlaneVersion(PassingData.from_activity_plane_file_path);
        selectedPlane.add(planeVersion);
        PassingData.E_plane_project.planeList.remove(PassingData.E_plane_project.planeList.size()-1);
        try {
            PassingData.E_plane_project.Save_To_File();
        } catch (IOException e) {
            Toast.makeText(this,getResources().getString(R.string.error_al_guardar_archivo),Toast.LENGTH_SHORT).show();

        }
    }
    public void onClickSiguiente(View view) {
        Intent intent;
        //Guarda la foto como un plano nuevo
        if(checked==CHECKED.NEW) {
            newPlane();
        }
        else{
            existingPlane();
        }
        //Pasa a la siguiente activity
        intent = new Intent(this, Activity_Add_File_3.class);
        PassingData.from_activity= PassingData.FROM_ACTIVITY.ADD_FILE_2_end;
        startActivity(intent);
    }
    public void onClickFinalizar(View view) {
        Intent intent;
        //Guarda la foto como un plano nuevo
        if(checked==CHECKED.NEW) {
            newPlane();
        }
        else{
            existingPlane();
        }
        intent = new Intent(this, MainActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PassingData.from_activity= PassingData.FROM_ACTIVITY.ADD_FILE_2_end;
        startActivity(intent);
    }
    public void onClickAtras(View view) {
        PassingData.from_activity= PassingData.FROM_ACTIVITY.ADD_FILE_2_end;
        finish();
    }

}
