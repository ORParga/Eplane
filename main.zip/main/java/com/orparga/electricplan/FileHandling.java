package com.orparga.electricplan;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.support.v4.content.ContextCompat;
import android.widget.LinearLayout;
import android.widget.Toast;
import android.support.v7.app.AppCompatActivity;
import android.os.Environment;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.channels.FileChannel;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.TimeZone;

import static com.orparga.electricplan.PassingData.GENERAL_FOLDER_NAME;
import static com.orparga.electricplan.PassingData.jsonConfig;

public class FileHandling {




    private static String CONFIG_FILE="config.json";    public static String getConfigFile() {
        return CONFIG_FILE;
    }



    public enum RETURN_VALUE {OK, FAILURE, CALLBACK_INVOKED, IOEXCEPTION, JSON_FORMAT,FILE_EXISTS,INVALID_CARACTERES,FILE_DOESNT_EXIST}
    public static RETURN_VALUE lastError=RETURN_VALUE.OK;

    public static final int WRITE_EXTERNAL_STORAGE_PERMISSION_CODE_FOR_INICIATE_DEFAULTS = 991;
    public static final int WRITE_EXTERNAL_STORAGE_PERMISSION_CODE_FOR_INICIATE_DEFAULTS_WITH_TAGS = 992;
    public static final int WRITE_EXTERNAL_STORAGE_PERMISSION_CODE_FOR_CREATE_FOLDER = 993;
    public static final int WRITE_EXTERNAL_STORAGE_PERMISSION_CODE_FOR_LOAD_PROJECT = 994;
    public static final int WRITE_EXTERNAL_STORAGE_PERMISSION_CODE_FOR_LOAD_CONFIG = 995;
    public static String RP_CALLBACK_VARIABLE_LOAD_PROJECT_FULL_PATH;

    public static boolean IHaveWritePermision = false;
    String PathForNewFolder = "";
    String TittleForNewFolder = "";

    public FileHandling() {

    }

    public RETURN_VALUE RP_FillTreeWithDefaultFolder(AppCompatActivity act,FolderItemManager folderItemManager) {
        SharedPreferences SP;
        if (ContextCompat.checkSelfPermission(act,
                Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
            if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                act.requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, WRITE_EXTERNAL_STORAGE_PERMISSION_CODE_FOR_INICIATE_DEFAULTS);

                return RETURN_VALUE.CALLBACK_INVOKED;
            } else {
                //No tenemos permiso de lectura del sistema de archivosContext
                CharSequence text = act.getResources().getString(R.string.sin_acceso_a_archivos);
                ;
                int duration = Toast.LENGTH_SHORT;
                IHaveWritePermision = false;

                Toast toast = Toast.makeText(act, text, duration);
                toast.show();
                return RETURN_VALUE.FAILURE;
            }
        } else {
            IHaveWritePermision = true;

            SP = act.getPreferences(AppCompatActivity.MODE_PRIVATE);
            GENERAL_FOLDER_NAME = SP.getString("GENERAL_FOLDER_NAME", GENERAL_FOLDER_NAME);

            PassingData.IniciateDefaultsWithDirectory(act, GENERAL_FOLDER_NAME,folderItemManager);
            LinearLayout linearLayout = act.findViewById(R.id.FolderContainer);
            PassingData.MainMenu.CreateMenuView(act, linearLayout);
            return RETURN_VALUE.OK;
        }
    }

    /**
     * Crea el View de archivos con la información guardada en listedTags
     * Si "listedTags" es null, rellena el View con Todos los planos del proyecto
     *
     * @param act
     * @param listedTags
     * @return
     */
    public RETURN_VALUE RP_FillTreeWithListedTags(MainActivity act, ArrayList<Tag.ListedTag> listedTags, boolean all,FolderItemManager folderItemManager) {
        if (ContextCompat.checkSelfPermission(act,
                Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
            if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                act.requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, WRITE_EXTERNAL_STORAGE_PERMISSION_CODE_FOR_INICIATE_DEFAULTS_WITH_TAGS);

                return RETURN_VALUE.CALLBACK_INVOKED;
            } else {
                //No tenemos permiso de lectura del sistema de archivosContext
                CharSequence text = act.getResources().getString(R.string.sin_acceso_a_archivos);
                int duration = Toast.LENGTH_SHORT;
                IHaveWritePermision = false;

                Toast toast = Toast.makeText(act, text, duration);
                toast.show();
                return RETURN_VALUE.FAILURE;
            }
        } else {
            IHaveWritePermision = true;

            PERM_GRAN_Iniciate_Defaults_with_listedTags(act, listedTags, all,folderItemManager);
            return RETURN_VALUE.OK;
        }
    }

    //Comprueba se la Activity tiene permiso de escritura y crea un
    //directorio en caso afirmativo
    public void RP_CreateFolder(AppCompatActivity act, String Path, String Tittle) {

        if (ContextCompat.checkSelfPermission(act,
                Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
            if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                // Do something for marshmallow (android 23) and above versions
                PathForNewFolder = Path;
                TittleForNewFolder = Tittle;
                act.requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, WRITE_EXTERNAL_STORAGE_PERMISSION_CODE_FOR_CREATE_FOLDER);
            } else {
                // do something for phones running an SDK before marshmallow (android 23)
                //No tenemos permiso de lectura del sistema de archivosContext
                CharSequence text = "E-Plane no puede funcionar sin acceso al sistema de archivos!";
                int duration = Toast.LENGTH_SHORT;
                IHaveWritePermision = false;

                Toast toast = Toast.makeText(act, text, duration);
                toast.show();

            }
        } else {
            IHaveWritePermision = true;
            CreateNewFolder(act, Path, Tittle);
        }
    }

    //Crea un directorio en la ruta especificada
    //Asume que la Activity tiene permiso de escritura.
    //No es recomendable llamar a esta funcion directamente...
    //..usar RequestPermission_and_CreateFolder en su lugar
    private void CreateNewFolder(AppCompatActivity act, String Path, String Tittle) {

        String fullPath = Environment.getExternalStorageDirectory().toString() + "/" +
                Path + "/" +
                Tittle;
        File directory = new File(fullPath);
        boolean exists = directory.exists();
        if (exists) {
            Toast.makeText(act, Tittle + " already exists.", Toast.LENGTH_SHORT).show();
        } else {
            if (!directory.mkdir()) {
                Toast.makeText(act, Tittle + " can't be created.", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(act, Tittle + " created.", Toast.LENGTH_SHORT).show();
            }
        }
    }

    public void Write_External_Storage_Permision_Callback_For_Iniciate_Defaults(AppCompatActivity act, int[] grantResults,FolderItemManager folderItemManager) {
        // If request is cancelled, the result arrays are empty.
        if (grantResults.length > 0
                && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

            // permission was granted, yay! Do the
            // contacts-related task you need to do.
            IHaveWritePermision = true;

            SharedPreferences SP = act.getPreferences(AppCompatActivity.MODE_PRIVATE);
            GENERAL_FOLDER_NAME = SP.getString("GENERAL_FOLDER_NAME", GENERAL_FOLDER_NAME);

            PassingData.IniciateDefaultsWithDirectory(act, GENERAL_FOLDER_NAME,folderItemManager);
            LinearLayout linearLayout = act.findViewById(R.id.FolderContainer);
            PassingData.MainMenu.CreateMenuView(act, linearLayout);//check for permission

        } else {

            // permission denied, boo! Disable the
            // functionality that depends on this permission.
            IHaveWritePermision = false;
            CharSequence text = act.getResources().getString(R.string.sin_acceso_a_archivos);
            int duration = Toast.LENGTH_SHORT;

            Toast toast = Toast.makeText(act, text, duration);
            toast.show();

        }
    }

    protected void PERM_GRAN_Iniciate_Defaults_with_listedTags(AppCompatActivity act, ArrayList<Tag.ListedTag> listedTags, boolean PlaneTagSelected,FolderItemManager folderItemManager) {

        SharedPreferences SP = act.getPreferences(AppCompatActivity.MODE_PRIVATE);
        GENERAL_FOLDER_NAME = SP.getString("GENERAL_FOLDER_NAME", GENERAL_FOLDER_NAME);

        PassingData.IniciateDefaultsWithListedTags(listedTags, PlaneTagSelected,folderItemManager);
        LinearLayout linearLayout = act.findViewById(R.id.FolderContainer);
        linearLayout.removeAllViews();
        PassingData.MainMenu.CreateMenuView(act, linearLayout);//check for permission

    }

    public void Write_External_Storage_Permision_Callback_For_Iniciate_Defaults_with_listedTags(AppCompatActivity act, int[] grantResults, ArrayList<Tag.ListedTag> listedTags, boolean PlaneTagSelected,FolderItemManager folderItemManager) {
        // If request is cancelled, the result arrays are empty.
        if (grantResults.length > 0
                && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

            // permission was granted, yay! Do the
            // contacts-related task you need to do.
            IHaveWritePermision = true;
            PERM_GRAN_Iniciate_Defaults_with_listedTags(act, listedTags, PlaneTagSelected,folderItemManager);

        } else {

            // permission denied, boo! Disable the
            // functionality that depends on this permission.
            IHaveWritePermision = false;
            CharSequence text = act.getResources().getString(R.string.sin_acceso_a_archivos);
            int duration = Toast.LENGTH_SHORT;

            Toast toast = Toast.makeText(act, text, duration);
            toast.show();

        }
    }

    public void Write_External_Storage_Permision_Callback_For_Create_Folder(AppCompatActivity act, int[] grantResults) {

        if (grantResults.length > 0
                && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            IHaveWritePermision = true;
            CreateNewFolder(act, PathForNewFolder, TittleForNewFolder);
        } else {

            // permission denied, boo! Disable the
            // functionality that depends on this permission.
            IHaveWritePermision = false;
            CharSequence text = "E-Plane no puede funcionar sin acceso al sistema de archivos!";
            int duration = Toast.LENGTH_SHORT;

            Toast toast = Toast.makeText(act, text, duration);
            toast.show();

        }
    }


    public RETURN_VALUE RP_LoadConfigFile(AppCompatActivity act, int PERMISION_CODE, String FullPath) {
        SharedPreferences SP;
        if (ContextCompat.checkSelfPermission(act,
                Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
            if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                act.requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, PERMISION_CODE);
                //ask for permission
                return RETURN_VALUE.CALLBACK_INVOKED;
            } else {
                //No tenemos permiso de lectura del sistema de archivosContext
                return RETURN_VALUE.FAILURE;
            }
        } else {
            //Tenemos acceso de lectura al sistema de archivos
            return LoadConfigFile(act, FullPath);
        }
    }

    public void Write_External_Storage_Permision_Callback_For_Load_Config(AppCompatActivity act, int[] grantResults, String FullPath) {

        if (grantResults.length > 0
                && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            IHaveWritePermision = true;
            LoadConfigFile(act, FullPath);
        } else {

            // permission denied, boo! Disable the
            // functionality that depends on this permission.
            IHaveWritePermision = false;
            CharSequence text = "E-Plane no puede funcionar sin acceso al sistema de archivos!";
            int duration = Toast.LENGTH_SHORT;

            Toast toast = Toast.makeText(act, text, duration);
            toast.show();

        }
    }

    public RETURN_VALUE LoadConfigFile(Activity act, String FullPath) {
        String json = null;
        try {
            File file = new File(FullPath);
            if (file.exists()) {
                //Si existe un archivo json, lo lee
                FileReader fileReader = new FileReader(file);
                int size = (int) file.length();
                char[] buffer = new char[size];
                fileReader.read(buffer);

                json = new String(buffer);
                jsonConfig = new JSONObject(json);
                return RETURN_VALUE.OK;
            } else {
                //Si el archivo no existe, lo crea
                CreateNewFileAndSaveConfig(FullPath);
                return RETURN_VALUE.OK;
            }

        } catch (IOException ex) {
            ex.printStackTrace();
            return RETURN_VALUE.IOEXCEPTION;
        } catch (JSONException e) {
            e.printStackTrace();
            //Si el archivo está dañado, crea uno nuevo
            try {
                CreateNewFileAndSaveConfig(FullPath);
                return RETURN_VALUE.OK;
            } catch (IOException e1) {
                e1.printStackTrace();
                return RETURN_VALUE.IOEXCEPTION;
            }
        }

    }

    protected void CreateNewFileAndSaveConfig(String FullPath) throws IOException {
        int index = FullPath.lastIndexOf('/');
        String FolderPath = FullPath.substring(0, index);
        File folder = new File(FolderPath);
        folder.mkdirs();
        File file = new File(FullPath);
        file.createNewFile();
        CreateDefaultConfigJson();
        SaveConfigFile();
    }

    public void CreateDefaultConfigJson() {
        PassingData.jsonConfig = new JSONObject();

        try {
            jsonConfig.put("Version", "0");
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    public void SaveConfigFile() {
        String FullPath = Environment.getExternalStorageDirectory().toString() + "/" + PassingData.GENERAL_FOLDER_NAME + "/" + getConfigFile();

        BufferedWriter writer = null;
        String string_Config = PassingData.jsonConfig.toString();
        try {
            File file = new File(FullPath);
            FileWriter fileWriter = new FileWriter(file);
            writer = new BufferedWriter(fileWriter);
            writer.write(string_Config);

        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                if (writer != null)
                    writer.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public ArrayList getProjectsList() {
        ArrayList<String> projectsList = new ArrayList<String>();
        String[] FileList;

        String GeneralFolderPath = Environment.getExternalStorageDirectory() + "/" + GENERAL_FOLDER_NAME;
        File GeneralFolder = new File(GeneralFolderPath);
        if (GeneralFolder != null) if (GeneralFolder.exists()) {
            FileList = GeneralFolder.list();
            for (String file : FileList) {
                File subDir = new File(GeneralFolderPath + "/" + file);
                if (subDir.isDirectory()) {
                    String projectFilePath = GeneralFolderPath + "/" + file + "/" + file + ".json";
                    File projectFile = new File(projectFilePath);
                    if (projectFile != null) if (projectFile.exists())
                        projectsList.add(file);
                }
            }
        }

        return projectsList;
    }

    public static String constructFilePath(String projectName,String FileNameWithExtension) {

        return Environment.getExternalStorageDirectory() + "/" + GENERAL_FOLDER_NAME + "/" + projectName + "/" +FileNameWithExtension;
    }
    public static String constructProjectFilePath(String projectName) {

        return Environment.getExternalStorageDirectory() + "/" + GENERAL_FOLDER_NAME + "/" + projectName + "/" + projectName + ".json";
    }

    public static String constructProjectFolderPath(String projectName) {

        return Environment.getExternalStorageDirectory() + "/" + GENERAL_FOLDER_NAME + "/" + projectName;
    }

    public static String getFolder_from_Path (String fullPath){
        int index=fullPath.lastIndexOf("/");
        if(index!=-1)
        {
            if(index!=fullPath.length()-1)
            {
                return fullPath.substring(0,index);
            }
        }
        return "";
    }
    public static String getFileNameWithoutExtension_from_Path (String fullPath){
        int index=fullPath.lastIndexOf("/");
        int indexDot=fullPath.indexOf(".");
        if(index!=-1) {
            if (index != fullPath.length() - 1) {
                if(indexDot!=-1){
                    return fullPath.substring(index+1,indexDot);
                }
            }
        }

        return "";
    }

    /**
     * Devuleve la extension de un archivo, sin el punto
     * @param fullPath
     * @return
     */
    public static String getExtension_from_Path (String fullPath) {
        int indexDot = fullPath.indexOf(".");
        if (indexDot != -1) {
            if (indexDot != fullPath.length() - 1) {
                return fullPath.substring(indexDot+1);
            }
        }

        return "";
    }
    // Copy an InputStream to a File.
//
    public static void copyInputStreamToFile(InputStream in, File file) {
        OutputStream out = null;

        try {
            out = new FileOutputStream(file);
            byte[] buf = new byte[1024];
            int len;
            while ((len = in.read(buf)) > 0) {
                out.write(buf, 0, len);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            // Ensure that the InputStreams are closed even if there's an exception.
            try {
                if (out != null) {
                    out.close();
                }

                // If you want to close the "in" InputStream yourself then remove this
                // from here but ensure that you close it yourself eventually.
                in.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public static String createTempFilePath() {
        // Create an image file name
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd_HHmmss");
        sdf.setTimeZone(TimeZone.getTimeZone("GMT+2"));
        String timeStamp = sdf.format(new Date());
        String FileName = Environment.getExternalStorageDirectory() + "/" +
                PassingData.GENERAL_FOLDER_NAME + "/" +
                PassingData.getBasicProjectName() + "/" +
                "Plane_" + timeStamp + ".png";

        return FileName;
    }

    public static String createPngFilePath(String fileName) {
        String FileName = Environment.getExternalStorageDirectory() + "/" +
                PassingData.GENERAL_FOLDER_NAME + "/" +
                PassingData.getBasicProjectName() + "/" + fileName + ".png";

        return FileName;
    }
    public static String createPngFilePath(String projectName, String fileName) {
        String FileName = Environment.getExternalStorageDirectory() + "/" +
                PassingData.GENERAL_FOLDER_NAME + "/" +
                projectName+ "/" + fileName + ".png";

        return FileName;
    }

    /**
     * Crea un nombre de archivo provisional con la fecha y la hora para guardar el
     * bitmap en la carpeta del proyecto actual
     *
     * @param context La activity llamante (necesaria para presentar un Toast en caso de error
     *                Si es null... no presenta toast
     * @param bitmap  El bitmap para  ser guardado
     * @return la ruta completa al archivo creado
     */
    protected static String SavePhotoTemporaly(Context context, Bitmap bitmap) {
        FileOutputStream fos = null;
        //Guarda la foto en "ROM" de forma temporal
        String FilePath = FileHandling.createTempFilePath();
        try {
            fos = new FileOutputStream(FilePath);
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, fos);
        } catch (IOException e) {
            e.printStackTrace();
            if (context != null)
                Toast.makeText(context, context.getResources().getText(R.string.error_al_guardar_archivo), Toast.LENGTH_SHORT).show();
            FilePath = "";

        } catch (Exception e) {
            e.printStackTrace();
            if (context != null)
                Toast.makeText(context, context.getResources().getText(R.string.error_al_guardar_archivo), Toast.LENGTH_SHORT).show();
            FilePath = "";
        } finally {
            try {
                if (fos != null) {
                    fos.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
                FilePath = "";
            }
        }
        return FilePath;
    }

    /**
     * Crea un nombre de archivo con la ruta recibida para guardar el bitmap
     *
     * @param context         La activity llamante (necesaria para presentar un Toast en caso de error
     *                        Si es null... no presenta toast
     * @param SourcePath      Ruta completa al archivo que se va a copiar
     * @param DestinationPath Ruta completa donde se hubicará la copia.
     * @return la ruta completa al archivo creado. devuelve "" en caso de error
     */
    protected static boolean CopyFile(Context context, String SourcePath, String DestinationPath) {
        File sourceFile1 = new File(SourcePath);
        File desFile = new File(DestinationPath);
        if (!sourceFile1.exists()) return false;
        FileChannel sourceChannel = null,sourceChannel2 = null, destChannel = null;
        try {
            sourceChannel = new FileInputStream(sourceFile1).getChannel();
            destChannel = new FileOutputStream(desFile).getChannel();
            destChannel.transferFrom(sourceChannel, 0, sourceChannel.size());
            destChannel.transferFrom(sourceChannel, 0, sourceChannel.size());
        } catch (FileNotFoundException e) {
            if (context != null)
                Toast.makeText(context, context.getResources().getText(R.string.error_al_guardar_archivo), Toast.LENGTH_SHORT).show();
            e.printStackTrace();
            return false;
        } catch (IOException e) {
            if (context != null)
                Toast.makeText(context, context.getResources().getText(R.string.error_al_guardar_archivo), Toast.LENGTH_SHORT).show();
            e.printStackTrace();
            return false;
        } finally {
            try {
                sourceChannel.close();
                destChannel.close();
            } catch (IOException e) {
                if (context != null)
                    Toast.makeText(context, context.getResources().getText(R.string.error_al_guardar_archivo), Toast.LENGTH_SHORT).show();
                e.printStackTrace();
                return false;
            }
        }
        return true;
    }

    /**
     * Copia un archivo png desde una uri en un archivo dentro de la carpeta del proyecto actual.
     * Si ya existe un archivo con el mismo nombre en el destino, busca un nombre de archivo valido
     * @param context
     * @param SourceUri
     * @param destinationFileNameWithoutExtension
     * @return the used Path. Updates the "lastError" global static variable.
     */
    protected static String CopyPngFile(Context context, Uri SourceUri, String destinationFileNameWithoutExtension)
    {
        String targetPath= createPngFilePath(destinationFileNameWithoutExtension);
        try {
            InputStream sourceStream = context.getContentResolver().openInputStream(SourceUri);
            byte[] buffer = new byte[sourceStream.available()];
            sourceStream.read(buffer);

            File targetFile = new File(targetPath);
            if(targetFile.exists()){
                targetPath=createAvaliableFilePath(PassingData.getBasicProjectName(),destinationFileNameWithoutExtension,"png");
                if(targetPath.equals("")){lastError=RETURN_VALUE.FILE_EXISTS;return "";}
                targetFile = new File(targetPath);
            }
            OutputStream outStream = new FileOutputStream(targetFile);
            outStream.write(buffer);
        }
        catch (FileNotFoundException e){
            e.printStackTrace();
            lastError=RETURN_VALUE.IOEXCEPTION;
            return "";
        }
        catch (IOException e){
            e.printStackTrace();
            lastError=RETURN_VALUE.IOEXCEPTION;
            return "";
        }
        lastError=RETURN_VALUE.OK;
        return targetPath;
    }

    /**
     * Crea una ruta de archivo uniendo el nombre del proyecto, el nombre del archivo y la extension.
     * Comprueva si el archivo ya existe, y si es así, añade un numero de tres cifras al final del nombre de archivo.
     * En caso de que el archivo ya exista y además el nombre ya contenga un numero de tres cifras al final, se añade una
     * unidad a dicho numero. Por ejemplo, si recibe un nombre de archivo "archivo_034" y dicho archivo existe, se crea
     * una ruta de de archivo acabada en archivo_035, comprueva si existe, y en caso crea un archivo_036. Así sucesivamente
     * En caso de llegar a archivo_999 y existir, devuelve ""
     * @param ProjectName
     * @param InitialFileNameWithoutExtension
     * @param Extension
     * @return
     */
    protected static String createAvaliableFilePath(String ProjectName,String InitialFileNameWithoutExtension,String Extension) {

        String newPath;
        String returnValue;
        String path=constructFilePath(ProjectName,InitialFileNameWithoutExtension+"."+Extension);
        String fileNameWithNumber;
        String sIndex="";
        //Primero, comprueva si se puede guardar el archivo sin tener que añadirle un numerito al final
        File file =new File(path);
        if(!file.exists())return path;

        //Si el nombre ya existe le añade un numero al final si no lo tiene
        int index = getNumberOfFile(InitialFileNameWithoutExtension);
        if(index==-1) {index = 0;}
        else{
            //Si el nombre ya tiene un número de tres cifras al final... lo quita del nombre y empieza el cuenteo en dicho númro
            InitialFileNameWithoutExtension=InitialFileNameWithoutExtension.substring(0,InitialFileNameWithoutExtension.length()-3);
        }

            while (index < 1000) {
                if (index < 10) {
                    sIndex = "_00" + index;
                } else if (index < 100) sIndex = "_0" + index;
                else {sIndex = "_" + index;}
                fileNameWithNumber = InitialFileNameWithoutExtension + sIndex;
                path = constructFilePath(ProjectName, fileNameWithNumber +"."+ Extension);
                file = new File(path);
                if (!file.exists()) return path;
                index++;

            }

        return "";
    }

    /**
     * Devuelve el numerito al final del nombre del archivo si existe.
     * El numerito deve tener tres digitos:
     * archivo001 devolvería 1
     * fotito_102 devolveria 102
     * plano2003 decolveria 3
     * archivo.txt devolvería -1
     * archivo devolvería -1
     * @param FileNameWithoutExtension Nombre de archivo sin la extension
     * @return devuelve el numerito, si existe, sino, devuelve -1
     */
    protected static int getNumberOfFile(String FileNameWithoutExtension){

        String NumberInName;
        int iNumberInName;
        try {
            //Si el archivo acaba en numero: lo devuelve
            NumberInName=FileNameWithoutExtension.substring(FileNameWithoutExtension.length()-3);
            iNumberInName=Integer.parseInt(NumberInName);
        } catch (NumberFormatException|IndexOutOfBoundsException e) {
            //si el archivo no acaba en número, devuelve -1
            NumberInName="";
            iNumberInName=-1;
        }
        return iNumberInName;
    }
    /**
     * Carga el proyecto con el nombre recibido en "projectName" y lo devuelve en un objeto
     * E_Plane_Project
     * @param projectName el nombre del proyecto a cargar
     * @return debuelve un objeto E_Plane_Project si tiene exito, null en caso contrario
     */
    public static E_Plane_Project getProject (String projectName) {
        E_Plane_Project temp=null;
        String projectFolderPath = FileHandling.constructProjectFolderPath(projectName);
        String projectFilePath = projectFolderPath + "/" + projectName + ".json";
        File projectFile = new File(projectFilePath);
        if (projectFile.exists()) {
            temp = new E_Plane_Project();
            E_Plane_Project.RETURN_VALUE return_value =
                    temp.Load_From_File(null, projectFilePath, false);
            if(return_value!= E_Plane_Project.RETURN_VALUE.OK)temp=null;
        }
        return temp;
    }

    /**
     * Devuelve el listado de nombres de planos en el .json del projecto especificado
     * @param projectName Nombre del proyecto de donde se van a sacar los planos
     * @return listado de nombres de planos
     */
    public static ArrayList<String> getPlaneNamesList(String projectName) {
        ArrayList<String> planeNameList = new ArrayList<String>();

        //Comprueba si existe un proyecto con el nombre "selectedProject"
        int nPlane;

        E_Plane_Project temp = getProject(projectName);
        if (temp != null) {
            //Si se ha cargado el proyecto con éxito,
            //Se cargan los nombres de los archivos
            for (nPlane = 0; nPlane < temp.planeList.size(); nPlane++)
                planeNameList.add(temp.planeList.get(nPlane).Name);
        }
        return planeNameList;
    }
    /**
     * Devuelve el listado de nombres de planos en el objeto E_Plane_Project recibido
     * @param E_plane_project proyecto de donde se van a sacar los planos
     * @return listado de nombres de planos
     */
    public static ArrayList<String> getPlaneNamesList(E_Plane_Project E_plane_project) {
        ArrayList<String> planeNameList = new ArrayList<String>();

        //Comprueba si existe un proyecto con el nombre "selectedProject"
        int nPlane;

        if (E_plane_project != null) {
            //Si se ha cargado el proyecto con éxito,
            //Se cargan los nombres de los archivos
            for (nPlane = 0; nPlane < E_plane_project.planeList.size(); nPlane++)
                planeNameList.add(E_plane_project.planeList.get(nPlane).Name);
        }
        return planeNameList;
    }
    /**
     * Devuelve el listado de planos en el objeto E_Plane_Project recibido
     * @param projectName proyecto de donde se van a sacar los planos
     * @return listado de nombres de planos
     */
    public static ArrayList<Plane> getPlaneList(String projectName) {

        ArrayList<Plane> planeList = new ArrayList<Plane>();

        //Comprueba si existe un proyecto con el nombre "selectedProject"
        int nPlane;

        E_Plane_Project temp = getProject(projectName);
        if (temp != null) {
            //Si se ha cargado el proyecto con éxito,
            //Se cargan los nombres de los archivos
            for (nPlane = 0; nPlane < temp.planeList.size(); nPlane++)
                planeList.add(temp.planeList.get(nPlane));
        }
        return planeList;
    }
    /**
     * devuelve el listado de projectos actualmente cargados en el directorio de la App
     * del dispositivo añadiendo la secuencia "proyecto nuevo" al primer elemento del array
     * @param GeneralFolderName el nombre de la carpeta de la app
     * @return listado de proyectos
     */
    public static ArrayList<String> getProjectList(Context context,String GeneralFolderName) {
        ArrayList<String> projectList=new ArrayList<String>();
        projectList.add(context.getResources().getString(R.string.row_imported_plane_nuevo_proyecto));

        //Busca en la carpeta de la App, todas las carpetas y comprueba si son
        //carpetas de proyecto
        String projectName;String projectPath;File ProjectFile;
        File GeneralFolderPath =new File (Environment.getExternalStorageDirectory().getPath()+
                "/"+GeneralFolderName);
        if (GeneralFolderPath.exists())
        {
            File[] files = GeneralFolderPath.listFiles();
            for (int i = 0; i < files.length; i++) {

                if (files[i].isDirectory()) {
                    projectName=files[i].getName();
                    projectPath=constructProjectFilePath(projectName);
                    ProjectFile= new File (projectPath);
                    if (ProjectFile.exists())
                    {
                        projectList.add(projectName);
                    }
                }
                if (files[i].isFile()) {
                }
            }
        }
        return projectList;
    }
    /**
     * No debuelve las rutas completas, solo parciales desde el directorio del proyecto
     * Devuelve un listado de los subdirectorios dentro del directorio del proyecto recibido
     * añadiendo la secuencia "directorio nuevo" al primer elemento del array y el directorio
     * del proyecto recibido como segundo elemento del array.A partir del tercer elemento,
     * todos son subdirectorios del proyecto recibido, si existe
     * @return
     */
    public static  ArrayList<String> getFolderList(Context context,String projectName) {
        ArrayList<String> folderList=new ArrayList<>();
        folderList.add(context.getResources().getString(R.string.row_imported_plane_nuevo_directorio));
        folderList.add(projectName);
        String projectPath=FileHandling.constructProjectFolderPath(projectName);
        //los nombres de las rutas empiezan en la carpeta del proyecto
        int startName=projectPath.length()-projectName.length();
        File file=new File(projectPath);
        //Comprobacion de seguridad anti-errores
        if(file.exists())
        {
            //Comprobacion de seguridad anti-errores
            if(file.isDirectory())
            {

                File[] listFiles=file.listFiles();
                for(File subFile:listFiles) {
                    if(subFile.isDirectory()) {
                        folderList.add(subFile.getPath().substring(startName));
                        getsubFolders(folderList,subFile,startName,true);
                    }
                }
            }
        }
        return folderList;
    }
    public static void getsubFolders(ArrayList<String> listFolders,File folder,int startName,boolean includeTree)
    {
        if(folder.isDirectory()){
            File[] listFiles=folder.listFiles();
            for(File subFile:listFiles)
            {
                if(subFile.isDirectory()){
                    listFolders.add(subFile.getPath().substring(startName));
                    if(includeTree) getsubFolders(listFolders,subFile,startName,true);
                }
            }
        }
    }
    public static void renameFile(String originalPath, String newName) {
        File oldFile=new File(originalPath);
        if(oldFile.exists()){
            String path=FileHandling.getFolder_from_Path((originalPath));
            String ext=FileHandling.getExtension_from_Path(originalPath);
            String newPath=path+"/"+newName+"."+ext;
            File newFile=new File(newPath);
            oldFile.renameTo(newFile);
        }
    }
}

