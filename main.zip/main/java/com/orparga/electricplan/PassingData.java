package com.orparga.electricplan;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.AssetManager;
import android.os.Build;
import android.os.Environment;
import android.support.v7.app.AppCompatActivity;
import android.widget.RelativeLayout;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

public class PassingData {

    public static FileHandling fileHandling;
    public static FolderItem for_activity_plane_edit_SelectedFolder;

    public enum FROM_ACTIVITY {STARTING_APP,
        UNKNOW, MAIN_ACTIVITY,
        NEW_PROJECT_1_start,NEW_PROJECT_1_end,
        NEW_PROJECT_2_start,NEW_PROJECT_2_end,
        HELP_TAGS_start,HELP_TAGS_end,
        ADD_FILE_1_start,ADD_FILE_1_end,
        ADD_FILE_2_start,ADD_FILE_2_end,
        ADD_FILE_3_start,ADD_FILE_3_end,
        Intent_receive_plane_start,Intent_receive_plane_end;
    }
    public static FROM_ACTIVITY from_activity=FROM_ACTIVITY.STARTING_APP;
    public static String from_activity_project_name="";
    public static String from_activity_plane_name="";
    public static String from_activity_plane_file_path="";
    public static Plane from_activity_plane;

    public static String GENERAL_FOLDER_NAME_DEFAULT;

    public static String getGeneralFolderName(AppCompatActivity act) {
        if (GENERAL_FOLDER_NAME==null)
        {
            SharedPreferences settings = act.getSharedPreferences("config", Context.MODE_PRIVATE);
            GENERAL_FOLDER_NAME = settings.getString("GENERAL_FOLDER_NAME", GENERAL_FOLDER_NAME);
        }
        if(GENERAL_FOLDER_NAME.equals(""))
        {
            SharedPreferences settings = act.getSharedPreferences("config", Context.MODE_PRIVATE);
            GENERAL_FOLDER_NAME = settings.getString("GENERAL_FOLDER_NAME", GENERAL_FOLDER_NAME);

        }
        return GENERAL_FOLDER_NAME;
    }

    public static String GENERAL_FOLDER_NAME;
    public static String THEME_FILE_DEFAULT ;
    public static String THEME_FILE ;
    public static RelativeLayout ViewWorkArea;


    public enum ORIENTATION {LANDSCAPE, PORTRAIT}

    ;
    public static FolderItem MainMenu;
    public static ORIENTATION Orientation = ORIENTATION.PORTRAIT;
    public static boolean FolderContainerIsShowing = true;
    private static FolderItem WorkingItem;
    public static void setWorkingItem(FolderItem folderItem){
        WorkingItem=folderItem;
    }
    public static FolderItem getWorkingItem(){
        return WorkingItem;
    }

    public static String CurrentSelected = "";

    //*****************************configuracion*************************************************
    public static ArrayList<Theme> themeList;
    public static String user_default;
    protected static String user;public static String getUser(){return user;}
    public static String current_project_folder_default;
    public static String project_name_default;

    public static String getBasicProjectName() {
        return project_name;}

    public static void setBasicProjectName(Context context,String project_folder) {
        PassingData.project_name = project_folder;
        SharedPreferences preferences = context.getSharedPreferences("config", Context.MODE_PRIVATE);

        SharedPreferences.Editor editor = preferences.edit();
        editor.putString("project_name",project_folder);
        editor.apply();
    }
    public static String getBasicProjectPath(){
        return  Environment.getExternalStorageDirectory().toString() + "/" +
                PassingData.GENERAL_FOLDER_NAME + "/" +
                project_name + "/" +
                project_name + ".json";
    }
    public static String createBasicProjectPath(String Project_Name){
        return  Environment.getExternalStorageDirectory().toString() + "/" +
                PassingData.GENERAL_FOLDER_NAME + "/" +
                Project_Name + "/" +
                Project_Name + ".json";
    }
    public static String getBasicProjectFolderPath(){
        return  Environment.getExternalStorageDirectory().toString() + "/" +
                PassingData.GENERAL_FOLDER_NAME;
    }
    private static String project_name;
    public static String current_theme_Name = "";
    public static String current_theme_Name_default;
    public static int current_text_color_default = R.color.color_app_text;
    public static int current_text_color;
    public static int current_background_color_default = R.color.color_app_background;
    public static int current_background_color;
    public static int getCurrent_background_color(){
        return current_background_color;
    }
    public static int current_border_color_default = R.color.color_app_border;


    public static int current_border_color;
    public static int getCurrent_border_color() {
        return current_border_color;
    }

    public static int setup_aspect_PointerOfThemeSelectedInComboBox;
    public static int setup_aspect_sample_text_color;
    public static int setup_aspect_sample_back_color;
    public static int setup_aspect_sample_border_color;
    public static boolean setup_aspect_apply_button_enabled=false;
    public static boolean setup_aspect_save_button_enabled=false;
    public static boolean setup_aspect_restore_button_enabled=false;

    //******************************* project ************************************************
    public static E_Plane_Project E_plane_project;
    public static JSONObject jsonConfig;

    public static void IniciateDefaultsWithDirectory(AppCompatActivity act, String folder,FolderItemManager folderItemManager) {


        String FullPath = Environment.getExternalStorageDirectory().toString() + "/" + folder;
        String folderName,fileName;
        File directory = new File(FullPath);
        boolean exists = directory.exists();
        if (!exists) {
            if (!directory.mkdir()) {
                Toast.makeText(act, folder + " can't be created.", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(act, folder + " created.", Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(act, folder + " already exists.", Toast.LENGTH_SHORT).show();
        }
        MainMenu = new FolderItem(null,folder, FolderItem.TYPE.Folder, FullPath,folderItemManager);
        File[] files = directory.listFiles();
        for (int i = 0; i < files.length; i++) {

            if (files[i].isDirectory()) {
                folderName=files[i].getName();
                MainMenu.add(null,folderName, FolderItem.TYPE.Folder, files[i].getPath(),folderItemManager);
                FolderItem.fillFolder(files[i], MainMenu.get(MainMenu.Menu.size() - 1),folderItemManager);
            }
            if (files[i].isFile()) {
                fileName=files[i].getName();
                MainMenu.add(null,fileName, FolderItem.TYPE.Item, files[i].getPath(),folderItemManager);
            }
        }
    }

    /**
     * Busca dentro de la variable global E_plane_project los planos con alguno de
     * los TAGS seleccionados en la lista selectedTags y crea el arbol de objetos
     * FolderItem para que posteriormente pueda ser visualizada posteriormente
     * en el LinearLayout guardado en la variable MainMeu.
     * Realiza una conversion a minusculas tanto en los tags delos planos como en
     * los tags listados
     *
     * Si listedTags es null, rellena el arbol de objetos con todos los planos
     * del proyecto antes de la comparación
     * @param listTags
     * @param planeTagSelected
     */
    public static void IniciateDefaultsWithListedTags(
            ArrayList<Tag.ListedTag> listTags, boolean planeTagSelected,FolderItemManager folderItemManager) {

        //Crea un arbol de archivos con la informacion de E_Plane_project
        MainMenu = new FolderItem(null,E_plane_project.ProjectName, FolderItem.TYPE.Folder,folderItemManager);
        ArrayList<Plane> planeList=E_plane_project.planeList;
        ArrayList<Tag> tagList;
        Tag.ListedTag currentTag;
        String nameTag;
        boolean isChosenOne=false;
        int size=planeList.size();
        int n,nTag;
        //Si el tag plane está seleccionado, carga todos los planos en el FolderItem
        if(planeTagSelected)
        {
            for(n=0;n<size;n++) {
                MainMenu.add(planeList.get(n),planeList.get(n).Name, FolderItem.TYPE.Tagged,planeList.get(n).last().Path,folderItemManager);
            }
            return;
        }
        //si el tag plane está de-seleccionado, carga FolderItem con los planos
        // cuyos Tags coincidan con los Tags activos en la lista "listTags"

        //repasa todos los planos del proyecto, uno por uno
        //BUCLE MAYOR
        for(Plane plane:planeList) {
            tagList=plane.tagList;
            //Busca todos los tags seleccionados
            for (Tag.ListedTag listedTag : listTags) {
                //bUCLE MEDIO
                if (listedTag.Selected) {
                    isChosenOne=false;
                    //Compara los tags seleccionados con los tags del plano
                    for (Tag planeTag : tagList) {
                        //BUCLE MENOR
                        if(planeTag.Name.toLowerCase().equals(listedTag.name.toLowerCase())){
                            //Si el plano incorpora el tag_listado seleccionado es candidato a
                            //ser un plano elegido.... Pero el plano debe tener TODOS los
                            //tag_listado seleccionados, así que continúa el bucle MEDIO
                            isChosenOne=true;
                            break;
                        }
                    }
                    //Si uno de los Tags_listados no está en el plano,
                    // este plano no es uno de los planos elegidos
                    if(isChosenOne==false)break;
                }
            }
            if(isChosenOne==true){
                //Si el bucle ha finalizado y el plano sigue siendo "ChosenOne"
                //es porque ha superado la criba
                MainMenu.add(plane,plane.Name, FolderItem.TYPE.Tagged,plane.last().Path,folderItemManager);

            }
        }
    }
    public static boolean isTagSelected (String name, ArrayList<Tag.ListedTag> listTags)
    {
        int nTag=0;

        for (nTag=0;nTag<listTags.size();nTag++)
        {
            if(name.equals(listTags.get(nTag).name))
            {
                if(listTags.get(nTag).Selected)
                    return true;
            }
        }

        return false;
    }
    public static String getCurrentProjectNameFromSharedPreferences(Context context)
    {
        LoadDefaultsFromRessources(context);

        SharedPreferences preferences = context.getSharedPreferences("config", Context.MODE_PRIVATE);

        project_name =preferences.getString("project_name", project_name_default);

        return project_name;
    }
    public static void LoadConfiguration(Context context) {
        LoadDefaultsFromRessources(context);

        SharedPreferences preferences = context.getSharedPreferences("config", Context.MODE_PRIVATE);

        user = preferences.getString("user", user_default);
        GENERAL_FOLDER_NAME =preferences.getString("GENERAL_FOLDER_NAME", "va a ser que no");
        GENERAL_FOLDER_NAME =preferences.getString("GENERAL_FOLDER_NAME", GENERAL_FOLDER_NAME_DEFAULT);
        THEME_FILE=preferences.getString("THEME_FILE",THEME_FILE_DEFAULT);
        project_name =preferences.getString("project_name", project_name_default);
        current_theme_Name = preferences.getString("current_theme_Name", current_theme_Name_default);
        current_text_color = preferences.getInt("current_text_color", current_text_color_default);
        current_background_color = preferences.getInt("current_background_color", current_background_color_default);
        current_border_color = preferences.getInt("current_border_color", current_border_color_default);

        iniThemeList(context);
        int themeInConfigFile=Theme.getThemePointerFromName(PassingData.themeList,current_theme_Name);
        if(themeInConfigFile!=-1)
        {
            if(PassingData.themeList.size()<themeInConfigFile)
            {
                Theme currentTheme=PassingData.themeList.get(themeInConfigFile);
                if( currentTheme!=null)
                {
                    current_border_color=currentTheme.getColor_border();
                    current_text_color=currentTheme.getColor_text();
                    current_background_color=currentTheme.getColor_background();

                    setup_aspect_PointerOfThemeSelectedInComboBox=themeInConfigFile;
                    setup_aspect_sample_text_color=current_text_color;
                    setup_aspect_sample_back_color=current_background_color;
                    setup_aspect_sample_border_color=current_border_color;
                }
            }
        }

    }
    public static void LoadDefaultsFromRessources(Context context) {
        user_default = context.getResources().getString(R.string.activity_setup_perform_user_default);
        GENERAL_FOLDER_NAME_DEFAULT =context.getResources().getString(R.string.activity_setup_perform_general_folder_default);
        project_name_default =context.getResources().getString(R.string.activity_setup_perform_project_folder_default);
        THEME_FILE_DEFAULT=context.getResources().getString(R.string.themes_file_name_default);
        current_theme_Name_default = context.getResources().getString(R.string.activity_setup_apareance_themeLight_Name);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            current_text_color_default=(context.getResources().getColor(R.color.activity_setup_apareance_themeLight_text, context.getTheme()));
            current_background_color_default=(context.getResources().getColor(R.color.activity_setup_apareance_themeLight_background, context.getTheme()));
            current_border_color_default=(context.getResources().getColor(R.color.activity_setup_apareance_themeLight_border, context.getTheme()));
        }else {
            current_text_color_default=(context.getResources().getColor(R.color.activity_setup_apareance_themeLight_text));
            current_background_color_default=(context.getResources().getColor(R.color.activity_setup_apareance_themeLight_background));
            current_border_color_default=(context.getResources().getColor(R.color.activity_setup_apareance_themeLight_border));
        }
    }

    public static void iniThemeList(Context context) {
        themeList = new ArrayList<Theme>();

        Theme theme = new Theme();
        theme.setName(context.getResources().getString(R.string.activity_setup_apareance_themeNew_Name));
        theme.setColor_background(context.getResources().getColor(R.color.activity_setup_apareance_themeNew_background));
        theme.setColor_text(context.getResources().getColor(R.color.activity_setup_apareance_themeNew_text));
        theme.setColor_border(context.getResources().getColor(R.color.activity_setup_apareance_themeNew_border));
        themeList.add(theme);

        theme = new Theme();
        theme.setName(context.getResources().getString(R.string.activity_setup_apareance_themeLight_Name));
        theme.setColor_background(context.getResources().getColor(R.color.activity_setup_apareance_themeLight_background));
        theme.setColor_text(context.getResources().getColor(R.color.activity_setup_apareance_themeLight_text));
        theme.setColor_border(context.getResources().getColor(R.color.activity_setup_apareance_themeLight_border));
        themeList.add(theme);

        theme = new Theme();
        theme.setName(context.getResources().getString(R.string.activity_setup_apareance_themeDark_Name));
        theme.setColor_background(context.getResources().getColor( R.color.activity_setup_apareance_themeDark_background));
        theme.setColor_text(context.getResources().getColor(R.color.activity_setup_apareance_themeDark_text));
        theme.setColor_border(context.getResources().getColor(R.color.activity_setup_apareance_themeDark_border));
        themeList.add(theme);


        String jsonArray=readThemesFile(context);
        Theme.loadAllThemesFromJSonArray(jsonArray,themeList);

    }

    public static JSONArray themeList_To_JSonArray(ArrayList<Theme> themeArrayList,int startAt_Index) {

        int n;

        JSONObject jsonObject;

        JSONArray jsonArray=new JSONArray();

        for(n=startAt_Index;n<themeArrayList.size();n++)
        {
            jsonObject=new JSONObject();
            try {
                jsonObject.put("Name",themeArrayList.get(n).getName());
                jsonObject.put("Color_background",themeArrayList.get(n).getColor_background());
                jsonObject.put("Color_text",themeArrayList.get(n).getColor_text());
                jsonObject.put("Color_border",themeArrayList.get(n).getColor_border());

                jsonArray.put(jsonObject);
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

        jsonArray.toString();

        return jsonArray;
    }

    public static void JSonArray_To_File (JSONArray jsonArray){
        String jsonText=jsonArray.toString();
        BufferedWriter writer = null;
        try
        {
            String path = Environment.getExternalStorageDirectory().toString() + "/" + PassingData.GENERAL_FOLDER_NAME +"/"+ PassingData.THEME_FILE;
            //String filePath = context.getFilesDir().getPath().toString() + "/fileName_without_extension.txt";
            //File f = new File(filePath);
            File file=new File(path);
            FileWriter fileWriter=new FileWriter(file);
            writer = new BufferedWriter(fileWriter );
            writer.write( jsonText);

        }
        catch ( IOException e)
        {
            e.printStackTrace();
        }
        finally
        {
            try
            {
                if ( writer != null)
                    writer.close( );
            }
            catch ( IOException e)
            {
                e.printStackTrace();
            }
        }
    }

    public static String readThemesFile(Context context) {
        AssetManager asset;
        String json = null;
        try {
            //asset = context.getAssets();
            //List<String> mapList = Arrays.asList(asset.list(""));
            //if ( mapList.contains(context.getResources().getString(R.string.themes_file_name))) {InputStream is = asset.open(path);
            //                if (is == null) return "";
            //                int size = is.available();
            //                byte[] buffer = new byte[size];
            //                is.read(buffer);
            //                is.close();

                //Si existe un archivo json, lo lee
            String path = Environment.getExternalStorageDirectory().toString() + "/" + PassingData.GENERAL_FOLDER_NAME +"/"+ PassingData.THEME_FILE;

            File file=new File(path);
            FileReader fileReader=new FileReader(file);
            int size=(int)file.length();
            char[] buffer = new char[size];
            fileReader.read(buffer);

                json = new String(buffer);

        } catch (IOException ex) {
            ex.printStackTrace();
            return "";
        }
        return json;
    }

    public static int findThemeName(ArrayList<Theme> themeList,String themeName)    {

        for(int n=0;n<themeList.size();n++)
        {
            Theme currentTheme=themeList.get(n);
            String currentThemeName=currentTheme.getName();
            if(currentThemeName.equals(themeName))
            {
                return n;
            }
        }

        return -1;
    }
}