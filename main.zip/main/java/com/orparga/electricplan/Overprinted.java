package com.orparga.electricplan;

import org.json.JSONException;
import org.json.JSONObject;

public class Overprinted {

    public Overprinted() {
    }
    public Overprinted(JSONObject jsonOverprinted){}

    public JSONObject To_JSONObject() {
            return new JSONObject();
    }
}
