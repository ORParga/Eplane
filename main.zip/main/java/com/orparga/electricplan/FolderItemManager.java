package com.orparga.electricplan;

public interface FolderItemManager {
    abstract public void singleClick (FolderItem folderItem);
    abstract public void doubleClick (FolderItem folderItem);
    abstract public void longClick (FolderItem folderItem);

}
