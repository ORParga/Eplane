package com.orparga.electricplan;

import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.support.v7.app.AppCompatActivity;
import android.widget.LinearLayout;
import android.widget.Toast;

import java.io.File;

public class Activity_Test extends AppCompatActivity implements Row_Import_Plane_Manager {
    Row_Import_Plane row_import_plane;
//    Eraser eraser;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_test);

        LinearLayout ll =  findViewById(R.id.activity_test_ll);
        String fname=new File(Environment.getExternalStorageDirectory(), "macaca.png").getAbsolutePath();

        File file=new File(fname);
        if(file.exists()) {
            row_import_plane=new Row_Import_Plane(this, Uri.fromFile(file),this);
            ll.addView(row_import_plane);
        }
    }

    @Override
    public void row_erase(Row_Import_Plane row_import_plane) {

        LinearLayout ll =  findViewById(R.id.activity_test_ll);
        ll.removeView(row_import_plane);
    }

    @Override
    public void row_plane_accepted(Row_Import_Plane row_import_plane) {
        //Si el usuario ha elegido que el plano se guarde en un subdirectorio.
        //este se añade al nombre de archivo que se para a "copyFile"
        String subFoldersString=row_import_plane.getSubFoldersString();
        if(!subFoldersString.equals(""))
        {
            subFoldersString+="/";
        }
        String destPath=FileHandling.createPngFilePath(subFoldersString+row_import_plane.getFileName_without_extension());
        //String destPath= Environment.getExternalStorageDirectory()+PassingData.getBasicProjectName()+row_import_plane.getSubFoldersString()+row_import_plane.getFileName_without_extension();
        if(FileHandling.CopyFile(this,row_import_plane.getFileName_from_intentSend(),destPath)){
            //Si no ha habido error al copiar el archivo, continuamos añadiendolo al .json del proyecto
            String strTempProjectPath=FileHandling.constructProjectFilePath(row_import_plane.getProjectName());
            E_Plane_Project temp_E_plane_project=new E_Plane_Project();
            temp_E_plane_project.Load_From_File(this,strTempProjectPath,false);
            if(row_import_plane.getbNewVersion()){
                //Si el plano recibido es una nueva version de un plano existente,
                //buscamos el "planelist" correspondiente donde añadirlo
                for(Plane plane:temp_E_plane_project.planeList){
                    if(plane.getName().equals(row_import_plane.getPlaneName())){
                        PlaneVersion planeVersion=new PlaneVersion(destPath);
                        planeVersion.Date=E_Plane_Project.getCurrentTime();
                        planeVersion.Operario=PassingData.getUser();
                        plane.add(planeVersion);
                    }
                }
            }
            else{
                //Si el plano recibido es un plano nuevo, lo añadimos.
                PlaneVersion planeVersion=new PlaneVersion(destPath);
                planeVersion.Date=E_Plane_Project.getCurrentTime();
                planeVersion.Operario=PassingData.getUser();

                Plane plane=new Plane(row_import_plane.planeName);
                plane.add(planeVersion);
                plane.tagList=E_Plane_Project.getTagList_from_StringList( row_import_plane.getTagsCreated());
                temp_E_plane_project.planeList.add(plane);
            }
            try {
                temp_E_plane_project.Save_To_File();
            }
            catch (Exception e){
                Toast.makeText(this,getResources().getString(R.string.error_al_guardar_archivo),Toast.LENGTH_SHORT).show();
            }
        }
        LinearLayout ll =  findViewById(R.id.activity_test_ll);
        ll.removeView(row_import_plane);
        this.finish();

    }

    @Override
    public void row_plane_declined(Row_Import_Plane row_import_plane) {
        LinearLayout ll =  findViewById(R.id.activity_test_ll);
        ll.removeView(row_import_plane);

    }

    @Override
    public void row_new_project_requested(Row_Import_Plane row_import_plane) {

    }


//    class Eraser implements Runnable{
//
//        @Override
//        public void run() {
//            while(true)
//            {
//                if(row_import_plane.Im_ready_to_quit())break;
//                try {
//                    Thread.sleep(100);
//                } catch (InterruptedException e) {
//                }
//            }
//            LinearLayout ll =  findViewById(R.id.activity_test_ll);
//            ll.removeView(row_import_plane);
//            Log.d("Activity_Test","Row removed");
//        }
//    }
}
