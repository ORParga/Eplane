package com.orparga.electricplan;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class ExistinProjectAdapter extends ArrayAdapter<ExistingProjectRow> {
    public ExistinProjectAdapter(Context context, ArrayList<ExistingProjectRow> existingProjectRows) {
        super(context, 0, existingProjectRows);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        return initView(position,convertView,parent);
    }

    @Override
    public View getDropDownView(int position, View convertView, ViewGroup parent) {
        return initView(position,convertView,parent);
    }

    private View initView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(
                    getContext()).inflate(R.layout.row_existing_project,
                    parent, false);
        }
        TextView textViewProjectName = convertView.findViewById(R.id.text_row_existing_project);
        ExistingProjectRow existingProjectRow = getItem(position);
        if (null != existingProjectRow) {
            textViewProjectName.setText(existingProjectRow.getsProjectName());
        }
        return convertView;
    }
}
