package com.orparga.electricplan;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class Theme {
    private String Name = "";
    private int Color_background = 0xFFFFFF;
    private int Color_text = 0;
    private int Color_border = 0;

    enum TAG {NONE ,BACK,TEXT,BORDER,LABEL;
        public static TAG fromInteger(int x) {
            switch(x) {
                case 0:
                    return NONE;
                case 1:
                    return BACK;
                case 2:
                    return TEXT;
                case 3:
                    return BORDER;
                case 4:
                    return LABEL;
            }
            return null;
    }};
    static String[] sTAG={"","back","text","border","label"};

    public Theme (){}
    public Theme (String Name,int Color_background,int Color_text,int Color_border)
    {
        this.setName(Name);
        this.setColor_background(Color_background);
        this.setColor_text(Color_text);
        this.setColor_border(Color_border);
    }
    public Theme (JSONObject objetoJSON) {
        try {
            Name = objetoJSON.getString("Name");
            Color_background = objetoJSON.getInt("Color_background");
            Color_text = objetoJSON.getInt("Color_text");
            Color_border = objetoJSON.getInt("Color_border");
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    public int getColor_border() {
        return Color_border;
    }

    public void setColor_border(int color_border) {
        Color_border = color_border;
    }

    public int getColor_background() {
        return Color_background;
    }

    public void setColor_background(int color_background) {
        Color_background = color_background;
    }

    public int getColor_text() {
        return Color_text;
    }

    public void setColor_text(int color_text) {
        Color_text = color_text;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public void loadThemeFromJSonObject(String OBJETO_JSON) {

        try {
            JSONObject object = new JSONObject(OBJETO_JSON);
            Name = object.getString("Name");
            Color_background = object.getInt("Color_background");
            Color_text = object.getInt("Color_text");
            Color_border = object.getInt("Color_border");
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    public void loadThemeFromJSonObject(JSONObject OBJETO_JSON) {

        try {
            Name = OBJETO_JSON.getString("Name");
            Color_background = OBJETO_JSON.getInt("Color_background");
            Color_text = OBJETO_JSON.getInt("Color_text");
            Color_border = OBJETO_JSON.getInt("Color_border");
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    //Lee un archivo json en el directorio Assets de la App...
    // si el achivo no existe, el método no hace nada
    public static void loadAllThemesFromJSonArray(String ARREGLO_JSON,ArrayList<Theme> theme_Array) {
        //inicializamos la lista donde almacenaremos los objetos Theme
        if(theme_Array==null) {
            theme_Array = new ArrayList<>();
        }
        //Creamos un objeto JSON a partir de la cadena
        try {
            JSONArray jsonArray_from_sourceString = new JSONArray(ARREGLO_JSON);

            for (int i = 0; i < jsonArray_from_sourceString.length(); i++) {
                //creamos un objeto Theme y lo insertamos en la lista
                theme_Array.add(new Theme(jsonArray_from_sourceString.getJSONObject(i)));
            }
        }
        catch (JSONException e) {
            e.printStackTrace();
        }
    }

    public static TAG tag_From_String(String tag)
    {
        if(tag==null)return TAG.NONE;
        for(int n=0;n<sTAG.length;n++)
        {
            if(sTAG[n].equals(tag))return TAG.fromInteger(n) ;
        }
        return TAG.NONE;
    }
    public static int getThemePointerFromName (ArrayList<Theme> themeList,String themeName)
    {
        int n=0;
        String themeCurrent;

        for(;n<themeList.size();n++)
        {
            themeCurrent=themeList.get(n).Name;
            if(themeCurrent!=null)
                if(themeCurrent.equals(themeName))
                {
                    return n;
                }
        }

        return -1;
    }
}