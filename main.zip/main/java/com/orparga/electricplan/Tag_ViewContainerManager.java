package com.orparga.electricplan;

public interface Tag_ViewContainerManager {
    abstract public void TagList_Modified();
}
