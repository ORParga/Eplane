package com.orparga.electricplan;

public class Vect {
    public float x;
    public float y;

    public Vect()
    {
        Ini (0,0);
    }
    public Vect(float x, float y)
    {
        Ini (x,y);
    }
    private void Ini (float x, float y)
    {
        this.x=x;
        this.y=y;
    }
    public void set (float x,float y)
    {
        this.x=x;
        this.y=y;
    }
    public void set (Vect vect)
    {
        this.x=vect.x;
        this.y=vect.y;
    }
    public Vect add (Vect vect)
    {
        return new Vect(vect.x+this.x,vect.y+this.y);
    }
    public Vect sub (Vect vect)
    {
        return new Vect(this.x-vect.x,this.y-vect.y);
    }
    public Vect center (Vect vect) {

        float x,y;
        x=(( this.x-vect.x)/2 )+vect.x;
        y=((this.y -vect.y)/2 )+vect.y;
        return new Vect ( x,y);
    }
}
