package com.orparga.electricplan;

import android.animation.ObjectAnimator;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Point;
import android.os.Build;
import android.os.Environment;
import android.support.constraint.ConstraintLayout;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.DialogFragment;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.util.ArrayList;

import static com.orparga.electricplan.PassingData.GENERAL_FOLDER_NAME;
import static com.orparga.electricplan.PassingData.fileHandling;
import static com.orparga.electricplan.PassingData.getBasicProjectPath;

public class MainActivity extends AppCompatActivity
        implements
        FolderItemManager,
        dialog_delete_plane_confirm.NoticeDialogListener{


    public enum MAINFOLDERCONTAINERMODE {DISK,TAGS}
    MAINFOLDERCONTAINERMODE MainFolderContainerMode=MAINFOLDERCONTAINERMODE.TAGS;

    int FolderContinerDestination, WorkAreaDestination;
    Point size = new Point();
    Toolbar toolbar;
    static int height, width;
    static int WorkAreaDesviation;
    LinearLayout MainFolderContainer;
    RelativeLayout WorkArea;
    FloatingActionButton floatingActionButton;
    Display display;
    String  pathConfig;

    /**
     * listedTags -
     * Listado de los Tags de búsqueda rápida de planos.
     * cada uno de los elementos de este array contiene
     * un String con el nombre del tag que ve el usuario
     * un "boolean" que indica si el Tag está seleccionado
     * o deseleccionado y un puntero al textView con el que
     * se relacciona
     */
    ArrayList<Tag.ListedTag> listedTags;
    boolean IsPlaneTagSelected =true;
    protected DoubleClickListener onClickTagListener=new DoubleClickListener() {
        public void onSingleClick(View v) {
            Tag.ListedTag listedTag = Tag.getTagfromView(listedTags, v);
            if (listedTag.Selected) {
                listedTag.textView.setBackground(getResources().getDrawable(R.drawable.rounded_corner_unselected));
                listedTag.Selected = false;
            } else {
                listedTag.textView.setBackground(getResources().getDrawable(R.drawable.rounded_corner));
                listedTag.Selected = true;
            }
            //listedTag.textView.postInvalidate();
            //if (MainFolderContainerMode == MAINFOLDERCONTAINERMODE.TAGS)
                reloadViewOfPlanes();
        }


        public void onDoubleClick(View v) {
            //primero deselecciona el tag "Plane"
            TextView planeTag=findViewById(R.id.Text_row_fixedTAG);
            planeTag.setBackground(getResources().getDrawable(R.drawable.rounded_corner_unselected));
            IsPlaneTagSelected = false;
            //segundo, deselecciona todos los tags
            for(Tag.ListedTag currentListedTag:listedTags){
                currentListedTag.Selected=false;
            }
            //despues seleciona solo el Tag que ha recibido el doubleClick
            Tag.ListedTag listedTag = Tag.getTagfromView(listedTags, v);
            listedTag.Selected=true;
            //if (MainFolderContainerMode == MAINFOLDERCONTAINERMODE.TAGS)
                reloadViewOfPlanes();

        }
    };
    private void reloadViewOfPlanes() {

        switch (MainFolderContainerMode) {
            case DISK:
                //Inicializa el el arbol de archivos
                //if (PassingData.MainMenu == null) {
                fileHandling.RP_FillTreeWithDefaultFolder(this,this);
                //} else {
                LinearLayout linearLayout = findViewById(R.id.FolderContainer);

                linearLayout.removeAllViews();
                PassingData.MainMenu.CreateMenuView(this, linearLayout);
                //}
                break;
            case TAGS:
                fileHandling.RP_FillTreeWithListedTags(this, listedTags, IsPlaneTagSelected,this);
                break;
        }
        adjustUI_to_GlobalColors();
        adjustTAGS_to_selecteds(listedTags);
        Zoom6 workingItemView=WorkArea.findViewById(R.id.ImageWorkArea);
        MainFolderContainer.invalidate();
        WorkArea.invalidate();
    }

    private void adjustTAGS_to_selecteds(ArrayList<Tag.ListedTag> listedTags) {
        if(IsPlaneTagSelected){
            findViewById(R.id.Text_row_fixedTAG).setBackground(getResources().getDrawable(R.drawable.rounded_corner));
        }
        else
        {
            findViewById(R.id.Text_row_fixedTAG).setBackground(getResources().getDrawable(R.drawable.rounded_corner_unselected));

        }
        for (Tag.ListedTag tag : listedTags) {
            if (tag.Selected) {
                tag.textView.setBackground(getResources().getDrawable(R.drawable.rounded_corner));
            } else {
                tag.textView.setBackground(getResources().getDrawable(R.drawable.rounded_corner_unselected));
            }
        }
    }

    public void onClickTag_All (View v)
    {
        if (IsPlaneTagSelected)
        {
            v.setBackground(getResources().getDrawable(R.drawable.rounded_corner_unselected));
            IsPlaneTagSelected =false;
        }
        else
        {
            v.setBackground(getResources().getDrawable(R.drawable.rounded_corner));
            IsPlaneTagSelected =true;
        }
        v.postInvalidate();
        reloadViewOfPlanes();

    }
    @Override
    public void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        // Restore UI state from the savedInstanceState.
        // This bundle has also been passed to onCreate.

        long elapsedTime;
        elapsedTime = System.currentTimeMillis() - savedInstanceState.getLong("elapsedTime");
    }

    @Override
    public void onSaveInstanceState(Bundle savedInstanceState) {
        super.onSaveInstanceState(savedInstanceState);
        // Save UI state changes to the savedInstanceState.
        // This bundle will be passed to onCreate if the process is
        // killed and restarted.

        long elapsedTime = System.currentTimeMillis();
        savedInstanceState.putLong("elapsedTime", elapsedTime);

        // etc.
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //Carga la configuracion
        PassingData.LoadConfiguration(this);
        fileHandling = new FileHandling();
        pathConfig = Environment.getExternalStorageDirectory().toString() + "/" +
                PassingData.GENERAL_FOLDER_NAME + "/" +
                FileHandling.getConfigFile();
        fileHandling.RP_LoadConfigFile(
                this, FileHandling.WRITE_EXTERNAL_STORAGE_PERMISSION_CODE_FOR_LOAD_CONFIG, pathConfig);

        // No olvidemos que tras onCreate(), el interprete de Java llama a onResume()
    }

    @Override
    protected void onResume() {
        super.onResume();
        //Inicializa el layout
        setContentView(R.layout.activity_main);

        //Inicializa las variables globales;
        MainFolderContainer = findViewById(R.id.MainFolderContainer);
        WorkArea = findViewById(R.id.workArea);
        floatingActionButton = findViewById(R.id.fab);
        PassingData.ViewWorkArea = WorkArea;


        switch (PassingData.from_activity) {
            case STARTING_APP:
            case Intent_receive_plane_end:
            case Intent_receive_plane_start:
                iniProject();
                break;
            case UNKNOW:
            case MAIN_ACTIVITY:
            default:
                //La App ha inicializado, carga el proyecto por defecto
            case NEW_PROJECT_1_start:
                //El usuario ha cancelado la seleccion de proyecto
            {
                break;
            }
            case NEW_PROJECT_1_end://El usuario ha seleccionado un proyecto existente
            {
                break;
            }
            case NEW_PROJECT_2_start:
                //El usuario ha seleccionado un proyecto nuevo pero
                //no ha introducido un nombre de proyecto
            {
                break;
            }
            case NEW_PROJECT_2_end:
                //El usuario ha seleccionado un proyecto nuevo y ha
                //introducido un nombre de proyecto
            {
                break;
            }
            case ADD_FILE_1_start:
            case ADD_FILE_1_end:
            case ADD_FILE_2_start:
            case ADD_FILE_2_end:
            case ADD_FILE_3_start:
            case ADD_FILE_3_end: {
                break;
            }
        }
        PassingData.from_activity = PassingData.FROM_ACTIVITY.MAIN_ACTIVITY;
        Update_toolBar();


        listedTags = new ArrayList<>();
        fillListOfTags_With_E_Plane(listedTags);
        IsPlaneTagSelected=true;
        iniTagBar();
        switch (MainFolderContainerMode) {
            case DISK:
                //Inicializa el el arbol de archivos
                //if (PassingData.MainMenu == null) {
                fileHandling.RP_FillTreeWithDefaultFolder(this,this);
                //} else {
                LinearLayout linearLayout = findViewById(R.id.FolderContainer);

                linearLayout.removeAllViews();
                PassingData.MainMenu.CreateMenuView(this, linearLayout);
                //}
                break;
            case TAGS:
                fileHandling.RP_FillTreeWithListedTags(this, listedTags, IsPlaneTagSelected,this);
                break;
        }
        //Inicializa las partes de la interfaz de usuario
        //Inicialize UI ... ajusta al 50% el area de listado de planos y el area de trabajo
        InicializeUI();
        //adjustUI_to_Globals ... Muestra o esconde la ventana "FolderItemVew" y cambia el icono del floatingActionButton
        adjustUI_to_Globals();
        //... ajusta los colores
        adjustUI_to_GlobalColors();

        MainFolderContainer.invalidate();
        WorkArea.invalidate();

//        El ImageView que hace funcion de botón para conmutar el modo de visualizacion
//        TAGS/DIRECTORIOS necesita ser cargado en tiempo de ejecucion

        //Selecciona la imagen del icono en funcion del valor de la variable global que controla
        int ico;
        if (MainFolderContainerMode == MAINFOLDERCONTAINERMODE.DISK) ico = R.drawable.file_tree;
        else ico = R.drawable.tags;
        ImageButton imageView = findViewById(R.id.activity_main_btn_folder_container_mode);
        if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            imageView.setBackground(getDrawable(ico));
        } else {
            imageView.setBackground(getResources().getDrawable(ico));
        }
        imageView.postInvalidate();


    }

    private void iniTagBar() {
        if (listedTags == null) return;
        LayoutInflater inflater;
        inflater = (LayoutInflater) getBaseContext().getSystemService(LAYOUT_INFLATER_SERVICE);

        LinearLayout TagBar = findViewById(R.id.activity_main_LabelList);
        TextView fixedTag;
        View fixedtagXML;

        try {
            for (int n = 0; n < listedTags.size(); n++) {
                fixedtagXML = inflater.inflate(R.layout.row_listed_tag, null);
                fixedTag = fixedtagXML.findViewById(R.id.Text_row_fixedTAG);


                ((LinearLayout)(fixedTag.getParent())).removeView(fixedTag);
                fixedTag.setText(listedTags.get(n).name);
                listedTags.get(n).textView=fixedTag;
                listedTags.get(n).textView.setOnClickListener(onClickTagListener);
                TagBar.addView(fixedTag);
            }
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        TagBar.postInvalidate();
    }
    private void fillListOfTags_With_E_Plane(ArrayList<Tag.ListedTag> listedTags) {

        int nPlane,nE_Plane_Tag,nListedTag;
        String current_E_Plane_Tag="",currentListedTag;
        boolean foundEqual=false;
        ArrayList<Plane> planeList=PassingData.E_plane_project.planeList;
        Plane plane;
        for (nPlane=0;nPlane<planeList.size();nPlane++) {
            plane = planeList.get(nPlane);
            if (plane.tagList != null) {
                if(plane.tagList.size()==0)continue;
                foundEqual=false;
                for (nE_Plane_Tag = 0; nE_Plane_Tag < plane.tagList.size(); nE_Plane_Tag++) {
                    current_E_Plane_Tag = plane.tagList.get(nE_Plane_Tag).Name;
                    for (nListedTag = 0; nListedTag < listedTags.size(); nListedTag++) {
                        currentListedTag = listedTags.get(nListedTag).name;
                        if (current_E_Plane_Tag.equals(currentListedTag)) {
                            foundEqual = true;
                            break;
                        }
                    }
                    if(!foundEqual)
                        listedTags.add(new Tag.ListedTag(current_E_Plane_Tag, true, null));
                    foundEqual=false;
                }
            }
        }
    }

    private void InicializeUI() {

        //Calcular el tamañode los contenedores de listado y visualizacion
        MainFolderContainer.post(new Runnable() {
            @Override
            public void run() {
                height = MainFolderContainer.getHeight(); //height is ready in "post()"
                width = MainFolderContainer.getWidth(); //width is ready in "post()"
                if (height > width) {
                    PassingData.Orientation = PassingData.ORIENTATION.PORTRAIT;
                    MainFolderContainer.setLayoutParams(new ConstraintLayout.LayoutParams(width, height / 2));
                } else {
                    PassingData.Orientation = PassingData.ORIENTATION.LANDSCAPE;
                    MainFolderContainer.setLayoutParams(new ConstraintLayout.LayoutParams(width / 2, height));
                }

            }
        });
        WorkArea.post(new Runnable() {
            @Override
            public void run() {
                height = WorkArea.getHeight(); //height is ready
                width = WorkArea.getWidth(); //width is ready
                WorkAreaDesviation = (int) WorkArea.getY();
                if (height > width) {
                    PassingData.Orientation = PassingData.ORIENTATION.PORTRAIT;
                    //WorkArea.setLayoutParams(new ConstraintLayout.LayoutParams(width, height /2));
                    WorkAreaDesviation = height / 2;
                    WorkArea.setY((PassingData.FolderContainerIsShowing) ? WorkAreaDesviation : 0);
                } else {
                    PassingData.Orientation = PassingData.ORIENTATION.LANDSCAPE;
                    //WorkArea.setLayoutParams(new ConstraintLayout.LayoutParams(width , height/2));
                    WorkAreaDesviation = width / 2;
                    WorkArea.setX((PassingData.FolderContainerIsShowing) ? WorkAreaDesviation : 0);

                }

            }
        });
        final FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ObjectAnimator animation1;
                ObjectAnimator animation2;

                if (PassingData.FolderContainerIsShowing) {
                    FolderContinerDestination = -WorkAreaDesviation;
                    WorkAreaDestination = 0;
                    PassingData.FolderContainerIsShowing = false;
                } else {
                    FolderContinerDestination = 0;
                    WorkAreaDestination = WorkAreaDesviation;
                    PassingData.FolderContainerIsShowing = true;
                }

                if (PassingData.Orientation == PassingData.ORIENTATION.LANDSCAPE) {
                    animation1 = ObjectAnimator.ofFloat(MainFolderContainer, "translationX", FolderContinerDestination);
                    animation2 = ObjectAnimator.ofFloat(WorkArea, "translationX", WorkAreaDestination);
                    fab.setImageResource((PassingData.FolderContainerIsShowing) ? R.drawable.arrowleft32x32 : R.drawable.arrowright32x32);
                } else {
                    animation1 = ObjectAnimator.ofFloat(MainFolderContainer, "translationY", FolderContinerDestination);
                    animation2 = ObjectAnimator.ofFloat(WorkArea, "translationY", WorkAreaDestination);
                    fab.setImageResource((PassingData.FolderContainerIsShowing) ? R.drawable.arrowup32x32 : R.drawable.arrowdown32x32);
                }
                animation1.setDuration(250);
                animation1.start();

                animation2.setDuration(250);
                animation2.start();

            }
        });
    }

    //Muestra o esconde la ventana "FolderItemVew" y cambia el icono del floatingActionButton
    //dependiendo de si el menú está oculto de la orientacion de la pantalla
    //tambien carga la imagen que es estaba visualizando antes de la rotacion de pantalla
    protected void adjustUI_to_Globals() {
        int FolderContainerPos, WorkAreaPos;
        if (PassingData.FolderContainerIsShowing) {
            FolderContainerPos = 0;
            WorkAreaPos = WorkAreaDesviation;
        } else {
            FolderContainerPos = -WorkAreaDesviation;
            WorkAreaPos = 0;
        }


        display = getWindowManager().getDefaultDisplay();
        display.getSize(size);
        if (size.x > size.y) PassingData.Orientation = PassingData.ORIENTATION.LANDSCAPE;
        else PassingData.Orientation = PassingData.ORIENTATION.PORTRAIT;
        if (PassingData.Orientation == PassingData.ORIENTATION.LANDSCAPE) {
            MainFolderContainer.setX(FolderContainerPos);
            MainFolderContainer.setY(0);
            WorkArea.setX(WorkAreaPos);
            WorkArea.setY(0);
            floatingActionButton.setImageResource((PassingData.FolderContainerIsShowing) ? R.drawable.arrowleft32x32 : R.drawable.arrowright32x32);
        } else {
            MainFolderContainer.setX(0);
            MainFolderContainer.setY(FolderContainerPos);
            WorkArea.setX(0);
            WorkArea.setY(WorkAreaPos);
            floatingActionButton.setImageResource((PassingData.FolderContainerIsShowing) ? R.drawable.arrowup32x32 : R.drawable.arrowdown32x32);
        }


        if (PassingData.getWorkingItem() != null) {
            File imgFile = new File( PassingData.getWorkingItem().FullPath );

            if (imgFile.exists()) {
                Zoom6 myImage = PassingData.ViewWorkArea.findViewById(R.id.ImageWorkArea);

                String path1 = imgFile.getAbsolutePath();
                Bitmap bitmap = BitmapFactory.decodeFile(path1);
                myImage.setBitmap(bitmap);

            }
        }
        //Ajusta el botón "plane" al valor predefinido de la variable global
        TextView planeTag =findViewById(R.id.Text_row_fixedTAG);
        if(IsPlaneTagSelected)
        {
            planeTag.setBackground(getResources().getDrawable(R.drawable.rounded_corner));
        }
        else
        {
            planeTag.setBackground(getResources().getDrawable(R.drawable.rounded_corner_unselected));

        }
        planeTag.postInvalidate();
    }

    protected void adjustUI_to_GlobalColors() {
        ViewTree_appli_Theme(MainFolderContainer);
        //adjustView_to_GlobalColors(MainFolderContainer);
    }

    protected void adjustView_to_GlobalColors(View v) {

        ViewGroup vGroup;
        if (v instanceof View) {
                v.setBackgroundColor(PassingData.current_background_color);
            String t = (String) v.getTag();
            switch (Theme.tag_From_String(t)) {
                case BACK:
                    v.setBackgroundColor(PassingData.current_background_color);
                    break;
                case TEXT:
                    if (v instanceof TextView) {
                        ((TextView) v).setTextColor(PassingData.current_text_color);
                    }
                    v.setBackgroundColor(PassingData.current_background_color);
                    break;
                case BORDER:
                    v.setBackgroundColor(PassingData.current_border_color);
                    break;
                case LABEL:
                    if (v instanceof TextView) {
                        //v.setBackgroundColor(getResources().getColor(R.color.textTAG_Unselected));
                        //((TextView) v).setTextColor(this.getResources().getColor(R.color.textTAG_Selected));
                        ((TextView) v).setTextSize(this.getResources().getDimension(R.dimen.TagInListSize));
                    }
                    //v.setBackground(this.getResources().getDrawable(R.drawable.rounded_corner));
                    return;
                case NONE:
                default:
                    break;
            }
        }
    }
    void secondPart(View v,boolean useNewBackColor){
        ViewGroup vGroup;

        if (v instanceof TextView) {
            int color = PassingData.current_text_color | 0xFF000000;
            ((TextView) v).setTextColor(color);
            v.setBackgroundColor(PassingData.current_background_color);
        }
        if (v instanceof ImageView) {
            v.setBackgroundColor(PassingData.current_background_color);
        }
        if (v instanceof ViewGroup) {
            if (!(v instanceof Toolbar)) {
                vGroup = (ViewGroup) v;
                for (int i = 0; i < vGroup.getChildCount(); i++) {

                    View child = vGroup.getChildAt(i);
                    adjustView_to_GlobalColors(child);
                }
            }
        }
    }

    /**
     * Aplica el color de background a todos los Views hijos del View recibido(incluido)
     * y aplica el texto a todos los TextViews hijos del View recivido(incluido)
     * @param v View que contiene el TextView o el grupo de views al que se le aplicarán
     *          los cambios
     */
    protected void ViewTree_appli_Theme (View v)
    {
        Theme.TAG tGroup = Theme.tag_From_String((String) v.getTag());
        ViewTree_appli_Theme(v,tGroup);
    }
    protected void ViewTree_appli_Theme (View v,Theme.TAG parentTag) {

        //Colorea el View recibido dependiendo del tag que tenga, odependiendo
        //del tag del padre, si no tiene tag
        String t = (String) v.getTag();
        switch (Theme.tag_From_String(t)) {
            case LABEL:
                if (v instanceof TextView) {
                    v.setBackgroundColor(getResources().getColor(R.color.textTAG_Unselected));
                    ((TextView) v).setTextColor(this.getResources().getColor(R.color.textTAG_Selected));
                    ((TextView) v).setTextSize(this.getResources().getDimension(R.dimen.TagInListSize));
                }
                v.setBackground(this.getResources().getDrawable(R.drawable.rounded_corner));
                return;
            case NONE:
            default:{
                //Cambia los colores si es un textViev, imageButton o si es un linearLayout
                //pno los cambia en el restode los casos como: ToolBar
                if(v instanceof ImageView){
                    v.setBackgroundColor(PassingData.current_background_color);

                }
                if(v instanceof ImageButton){
                    adjustFolderContainerModeButton();

                }
                if (v instanceof TextView) {
                    v.setBackgroundColor(PassingData.current_background_color);
                    int color = PassingData.current_text_color | 0xFF000000;
                    ((TextView) v).setTextColor(color);
                }
                //Si tiene Views hijos, los colorea tambien(excepto si es un Toolbar)
                if (v instanceof ViewGroup) {
                    v.setBackgroundColor(PassingData.current_background_color);
                    if (!(v instanceof Toolbar)) {
                        ViewGroup vGroup = (ViewGroup) v;
                        for (int i = 0; i < vGroup.getChildCount(); i++) {

                            View child = vGroup.getChildAt(i);
                            Theme.TAG tGroup = Theme.tag_From_String((String) vGroup.getTag());

                            ViewTree_appli_Theme(child,tGroup);
                        }
                    }
                }
            }
        }
    }
    @Override
    protected void onStop() {
        super.onStop();



        SharedPreferences settings = this.getSharedPreferences("config", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = settings.edit();
        editor.putString("GENERAL_FOLDER_NAME", GENERAL_FOLDER_NAME);

        // Commit the edits!
        editor.commit();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        Intent intent;
        //noinspection SimplifiableIfStatement
        switch (id) {
            case R.id.action_Config:
                intent = new Intent(this, Activity_Setup.class);
                startActivity(intent);
                break;
            case R.id.action_folder:

                intent = new Intent(this, Activity_New_Project_1.class);
                startActivity(intent);
                break;
            case R.id.action_file:
                PassingData.from_activity_project_name=PassingData.getBasicProjectName();
                intent = new Intent(this, Activity_Add_File_1.class);
                startActivity(intent);
                break;
        }
        return super.onOptionsItemSelected(item);
    }


    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        switch (requestCode) {
            case FileHandling.WRITE_EXTERNAL_STORAGE_PERMISSION_CODE_FOR_INICIATE_DEFAULTS:
                fileHandling.Write_External_Storage_Permision_Callback_For_Iniciate_Defaults(this, grantResults,this);
                return;
            case FileHandling.WRITE_EXTERNAL_STORAGE_PERMISSION_CODE_FOR_INICIATE_DEFAULTS_WITH_TAGS:
                fileHandling.Write_External_Storage_Permision_Callback_For_Iniciate_Defaults_with_listedTags(this, grantResults,listedTags, IsPlaneTagSelected,this);
                return;
            case FileHandling.WRITE_EXTERNAL_STORAGE_PERMISSION_CODE_FOR_CREATE_FOLDER:
                fileHandling.Write_External_Storage_Permision_Callback_For_Create_Folder(this, grantResults);
                return;

            case FileHandling.WRITE_EXTERNAL_STORAGE_PERMISSION_CODE_FOR_LOAD_PROJECT:
                if(E_Plane_Project.RETURN_VALUE.OK==
                    PassingData.E_plane_project.Write_External_Storage_Permision_Callback_For_Load_Project(this, grantResults,FileHandling.RP_CALLBACK_VARIABLE_LOAD_PROJECT_FULL_PATH))

                    PassingData.setBasicProjectName(this,PassingData.E_plane_project.ProjectName);
                return;
            case FileHandling.WRITE_EXTERNAL_STORAGE_PERMISSION_CODE_FOR_LOAD_CONFIG:
                fileHandling.Write_External_Storage_Permision_Callback_For_Load_Config(this, grantResults, pathConfig);
                return;
        }

    }

    /**
     * iniProject - Crea el Objeto E_Plane_Project y lo guarda en la variable global
     * PassingData-E_Plane_project.
     * Después, la carga con la informacion del archivo json al que apunta la
     * ruta FullPath
     * Además presenta el nombre del proyecto en la barra de titulo
     * @param FullPath
     */
    public void iniProject(  String FullPath) {
        PassingData.E_plane_project=new E_Plane_Project();
        FileHandling.RP_CALLBACK_VARIABLE_LOAD_PROJECT_FULL_PATH =FullPath;
        E_Plane_Project.RETURN_VALUE ret= PassingData.E_plane_project.RP_Load_From_File(
                this,
                FileHandling.WRITE_EXTERNAL_STORAGE_PERMISSION_CODE_FOR_LOAD_PROJECT,
                FullPath);
        if(ret== E_Plane_Project.RETURN_VALUE.OK)
        {
            PassingData.setBasicProjectName(this,PassingData.E_plane_project.ProjectName);

        }

       Update_toolBar();
    }
    /**
     * Carga el objeto E_Plane _project el archivo correspondiente
     * a la variable global PassingData.project_name cuya "path" es obtenida
     * a traves de PassingData.getBasicProjectPath()
     */
    public void iniProject ()
    {
        PassingData.E_plane_project=new E_Plane_Project();
        FileHandling.RP_CALLBACK_VARIABLE_LOAD_PROJECT_FULL_PATH =getBasicProjectPath();
        E_Plane_Project.RETURN_VALUE ret= PassingData.E_plane_project.RP_Load_From_File(
                this,
                FileHandling.WRITE_EXTERNAL_STORAGE_PERMISSION_CODE_FOR_LOAD_PROJECT,
                getBasicProjectPath());
        if(ret== E_Plane_Project.RETURN_VALUE.OK)
        {
            PassingData.setBasicProjectName(this,PassingData.E_plane_project.ProjectName);

        }
        try {
            if (PassingData.E_plane_project.Update_Object_From_FileSystemIntegrity() != E_Plane_Project.RETURN_VALUE.OK)
                PassingData.E_plane_project.Save_To_File();
        }
        catch (Exception e){
            e.printStackTrace();
            Toast.makeText(this,getResources().getString(R.string.activity_main_error_updating_json),Toast.LENGTH_SHORT).show();
        }
    }

    public void Update_toolBar ()
    {
        //Muestra el titulo del projecto en la barra de titulo
        String title=getResources().getString(R.string.app_name);
        title=title+" - "+PassingData.getBasicProjectName();
        toolbar = (Toolbar) findViewById(R.id.tool_bar);
        toolbar.setTitle(title);
        toolbar.invalidate();


        setSupportActionBar(toolbar);
    }
    public void onClickFolderContainerMode(View view) {
        switch (MainFolderContainerMode) {
            case DISK:
                MainFolderContainerMode=MAINFOLDERCONTAINERMODE.TAGS;
            break;
            case TAGS:
                MainFolderContainerMode=MAINFOLDERCONTAINERMODE.DISK;
                break;
        }
        adjustFolderContainerModeButton();
        reloadViewOfPlanes();
        findViewById(R.id.activity_main_barra_accion_rapida).setVisibility(View.GONE);

    }
    public void onClickTest(View view) {
        Intent intent;
        intent = new Intent(this,Activity_Test.class);
        startActivity(intent);
    }
    public void onClick_plane_edit(View view){
        //recupera el listado de FolderItmes seleccionados

        ArrayList<FolderItem> selectedList=FolderItem.getSelectedItems(PassingData.MainMenu);
        ArrayList<FolderItem> notFolders=FolderItem.getNotFolders(selectedList);
        if(notFolders!=null) {
            PassingData.for_activity_plane_edit_SelectedFolder=notFolders.get(0);
            Intent intent;
            intent = new Intent(this, Activity_Plane_Edit.class);
            startActivity(intent);
        }
    }
    public void onClick_plane_share(View view){
        Intent intent;
        intent = new Intent(this, Activity_Plane_Share.class);
        startActivity(intent);
    }
    public void onClick_plane_delete(View view){
        // Create an instance of the dialog fragment and show it
        DialogFragment dialog = new dialog_delete_plane_confirm();
        dialog.show(getSupportFragmentManager(), "NoticeDialogFragment");
        }
    // The dialog fragment receives a reference to this Activity through the
    // Fragment.onAttach() callback, which it uses to call the following methods
    // defined by the NoticeDialogFragment.NoticeDialogListener interface
    @Override
    public void onDialogPositiveClick(DialogFragment dialog) {
        ArrayList<FolderItem> selectedList=FolderItem.getSelectedItems(PassingData.MainMenu);
        ArrayList<FolderItem> notFolders=FolderItem.getNotFolders(selectedList);
        if(notFolders!=null) {
            for (FolderItem item:notFolders){
                Plane plane=item.plane;
                PassingData.E_plane_project.deletePlane(plane,true);
                try {
                    PassingData.E_plane_project.Save_To_File(this, PassingData.E_plane_project.ProjectPathInfo.getFullPath());
                }
                catch (Exception e){
                    e.printStackTrace();
                    Toast.makeText(this,"E_Project.json not updated",Toast.LENGTH_SHORT).show();
                }
            }
        }

        reloadViewOfPlanes();
        findViewById(R.id.activity_main_barra_accion_rapida).setVisibility(View.GONE);
    }

    @Override
    public void onDialogNegativeClick(DialogFragment dialog) {

    }
    public String getMessage() {
        String returnValue;
        ArrayList<FolderItem> selectedList=FolderItem.getSelectedItems(PassingData.MainMenu);
        ArrayList<FolderItem> notFolders=FolderItem.getNotFolders(selectedList);
        if(notFolders!=null)
        {
            if(notFolders.size()==1){
                returnValue=getResources().getString(R.string.dialog_confirmar_borrado_un_plano)+
                        " "+selectedList.get(0).Tittle;
                return returnValue;
            }
            else if(notFolders.size()>1){
                returnValue=getResources().getString(R.string.dialog_confirmar_borrado_multiples_planos)+
                        " "+notFolders.size()+
                " "+getResources().getString(R.string.dialog_confirmar_borrado_multiples_planos_2);
                return returnValue;
            }
        }
        return getResources().getString(R.string.dialog_confirmar_borrado_ninguno_seleccionado);

    }
    protected void adjustFolderContainerModeButton ()
    {
        ImageButton imageView=findViewById(R.id.activity_main_btn_folder_container_mode);
        switch (MainFolderContainerMode) {
            case TAGS:
                if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    imageView.setBackground(getDrawable(R.drawable.tags));
                }
                else
                {
                    imageView.setBackground(getResources().getDrawable(R.drawable.tags));
                }
                break;
            case DISK:
                if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    imageView.setBackground(getDrawable(R.drawable.file_tree));
                }
                else
                {
                    imageView.setBackground(getResources().getDrawable(R.drawable.file_tree));
                }
                break;
        }
        imageView.postInvalidate();
    }

    //singleClick:De la interfas FolderItemManager
    @Override
    public void singleClick(FolderItem folderItem) {
        ArrayList<FolderItem> folderItems;
        File imgFile;
        if(FolderItem.isAnySelected(PassingData.MainMenu)){
            folderItems=FolderItem.getSelectedItems(PassingData.MainMenu);
            if(folderItems!=null){
                if(folderItems.contains(folderItem)){
                    //Si el usuario ha hecho click sobre un icono seleccionado
                    //su intencion es deseleccionarlo
                    folderItem.setSelected(false);
                    if(folderItems.size()==1){
                        //Si solo quedaba un Itme seleccionado, se esconde la barra de botones
                        LinearLayout ll_accion_rapida=findViewById(R.id.activity_main_barra_accion_rapida);
                        ll_accion_rapida.setVisibility(View.GONE);
                    }
                }
                else{
                    //Si ul usuario ha hecho click sobre un icono deseleccionado
                    //mientras hay otro seleccionado, su intencion es seleccionar
                    //este también
                    folderItem.setSelected(true);
                }

            }
        }
        else{
            //Si no hay ningun icono seleccionado
            //la intencion del usuario al clickear sobre un icono
            //es visualizar el contenido del archivo
            switch (folderItem.type) {
                //Si pulsamos sobre una carpeta, simplemente se expande o se colapsa
                case Folder:
                    if(folderItem.MenuItemLayout!=null) {
                        LinearLayout LL_Inner = folderItem.MenuItemLayout.findViewById(R.id.FolderContainer);
                        ImageView plus = folderItem.MenuItemLayout.findViewById(R.id.plus);
                        if (folderItem.status == FolderItem.STATUS.Colapsed) {
                            folderItem.status = FolderItem.STATUS.Expanded;
                            plus.setImageResource(R.drawable.ic_minus);
                            LL_Inner.setVisibility(View.VISIBLE);

                        } else {
                            folderItem.status = FolderItem.STATUS.Colapsed;
                            LL_Inner.setVisibility(View.GONE);
                            plus.setImageResource(R.drawable.ic_plus);

                        }
                    }
                    break;
                //Si pulsamos sobre un archivo de imagen,
                // la presentamos en el area de trabajo
                case Item:
                    imgFile = new File(folderItem.FullPath );

                    if (imgFile.exists()) {

                        //Bitmap myBitmap = BitmapFactory.decodeFile(imgFile.getAbsolutePath());

                        Zoom6 myImage = PassingData.ViewWorkArea.findViewById(R.id.ImageWorkArea);

                        String path1 = imgFile.getAbsolutePath();
                        Bitmap bitmap = BitmapFactory.decodeFile(path1);
                        myImage.setBitmap(bitmap);
                        PassingData.setWorkingItem(folderItem);

                    }
                    break;
                case Tagged:
                    imgFile = new File(folderItem.FullPath );

                    if (imgFile.exists()) {

                        //Bitmap myBitmap = BitmapFactory.decodeFile(imgFile.getAbsolutePath());

                        Zoom6 myImage = PassingData.ViewWorkArea.findViewById(R.id.ImageWorkArea);

                        String path1 = imgFile.getAbsolutePath();
                        Bitmap bitmap = BitmapFactory.decodeFile(path1);
                        myImage.setBitmap(bitmap);
                        PassingData.setWorkingItem(folderItem);
                    }
                    break;
            }

        }
    }

    //doubleClick:De la interfas FolderItemManager
    @Override
    public void doubleClick(FolderItem folderItem) {

    }

    //longClick:De la interfas FolderItemManager
    @Override
    public void longClick(FolderItem folderItem) {

        FolderItem.UnSelectThree(PassingData.MainMenu);
        folderItem.setSelected(!folderItem.selected);
        //Si no había nada seleccionado, se muestra la barra de botones de accion rápida
        LinearLayout ll_accion_rapida=findViewById(R.id.activity_main_barra_accion_rapida);
        if(ll_accion_rapida.getVisibility()==View.GONE) ll_accion_rapida.setVisibility(View.VISIBLE);
    }

}


