package com.orparga.electricplan;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.TextView;

public class Activity_Help_Tags extends AppCompatActivity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_help_tags);
        TextView tittle=findViewById(R.id.text_new_project_3_tittle);
        tittle.setText(PassingData.from_activity_project_name);
    }

    @Override
    protected void onResume() {
        super.onResume();
        PassingData.from_activity= PassingData.FROM_ACTIVITY.HELP_TAGS_start;
    }
    public void onClickSiguiente(View view) {
        //ir a la activity creadora de Tags
        Intent intent;
        intent = new Intent(this, Activity_Add_File_3.class);
        startActivity(intent);

    }
}
