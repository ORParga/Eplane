package com.orparga.electricplan;

import org.json.JSONException;
import org.json.JSONObject;

public class Coor {
    public point P;
    public rotation R;
    public float S;

    public JSONObject To_JSONObject() {
        JSONObject jsonCoor=new JSONObject();

        try {
            jsonCoor.put("P",P.To_JSONObject());
            jsonCoor.put("R",R.To_JSONObject());
            jsonCoor.put("S",S);
        } catch (JSONException e) {
            e.printStackTrace();
            return null;
        }

        return jsonCoor;
    }

    public class point {
        float x;float y;
        public point (float x, float y) {
        this.x=x;this.y=y;
        }
        public point (){};
        public point (JSONObject jsonPoint){
            try {
                x=(float)jsonPoint.getDouble("x");
                y=(float)jsonPoint.getDouble("y");
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

        public JSONObject To_JSONObject() {
            JSONObject jsonPoint=new JSONObject();

            try {
                jsonPoint.put("x",x);
                jsonPoint.put("y",y);
            } catch (JSONException e) {
                e.printStackTrace();
                return null;
            }
        return jsonPoint;
        }
    }
    public class rotation {
        float a;float x;float y;
        public rotation (){};
        public rotation (float a) {
            this.a=a;
        }
        public rotation (float a,float x, float y) {
            this.a=a;
            this.x=x;
            this.y=y;
        }
        public rotation (JSONObject jsonRotation){
            try {
                a=(float)jsonRotation.getDouble("a");
                x=(float)jsonRotation.getDouble("x");
                y=(float)jsonRotation.getDouble("y");
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

        public JSONObject To_JSONObject() {
            JSONObject jsonRotation=new JSONObject();

            try {
                jsonRotation.put("a",a);
                jsonRotation.put("x",x);
                jsonRotation.put("y",y);
            } catch (JSONException e) {
                e.printStackTrace();
                return null;
            }
            return jsonRotation;
        }
    }

    public Coor (){P=new point();R=new rotation();S=1f;}
    public Coor (point P){
        if(P!=null)
            this.P=new point(P.x,P.y);
        else
            this.P=new point();
    }
    public Coor (point P,float Scale){
        this.S=Scale;
        if(P!=null)
            this.P=new point(P.x,P.y);
        else
            this.P=new point();
    }
    public Coor (point P,float Scale,rotation R){
        this.S=Scale;
        if(P!=null)
            this.P=new point(P.x,P.y);
        else
            this.P=new point();
        if(R!=null)
            this.R=new rotation(R.a,R.x,R.y);
        else
            this.R=new rotation();
    }
    public Coor (float Px,float Py){
        P=new point(Px,Py);
        S=1;
        R=new rotation();
    }
    public Coor (float Px,float Py,float Scale){
        P=new point(Px,Py);
        S=Scale;
        R=new rotation();
    }
    public Coor (float Px,float Py,float Scale,float angle,float Rx,float Ry){
        P=new point(Px,Py);
        S=Scale;
        R=new rotation(angle,Rx,Ry);
    }
    public Coor (Coor coor){
        if(coor!=null)
        {
            if(coor.P!=null)
            {
                this.P=new point(coor.P.x,coor.P.y);
            }
            else
            {
                this.P=new point();
            }
            if(coor.R!=null)
            {
                this.R=new rotation(coor.R.a,coor.R.x,coor.R.y);
            }
            this.S=coor.S;
        }
        else {
            this.P = new point();
            this.R=new rotation();
            this.S=1;
        }

    }
    public Coor (JSONObject jsonCoor){
        JSONObject jsonObjectSub;

        try {
            jsonObjectSub=jsonCoor.getJSONObject("P");
            P=new point(jsonObjectSub);
            jsonObjectSub=jsonCoor.getJSONObject("R");
            R=new rotation(jsonObjectSub);
            S=(float)jsonCoor.getDouble("S");
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }
}
