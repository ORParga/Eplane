package com.orparga.electricplan;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.os.Build;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

public class Zoom6 extends View {

    //int textPos;

    private final int MAX_COLORS_COUNT = 10;
    final Paint ovalPaint= new Paint(Paint.ANTI_ALIAS_FLAG);
    final Paint rectPaint= new Paint(0);
    private Paint paint[] = new Paint[MAX_COLORS_COUNT];
    float textHeight=0,mTextWidth=0;

    float xpad,ypad;
    float ww,hh;
    float diameter;


    private Bitmap currentBitmap;
    private Matrix matrixToFit;

    private enum MODE {
        NONE, TRANSLATING, SCALING
    }
    private MODE currentMode = MODE.NONE;

    private int pointerCount_Current = 0;
    private final int MAX_POINTERS_MANAGED = 2;
    private int Touch_ID[] = new int[MAX_POINTERS_MANAGED];
    private boolean Touch_Active[] = new boolean[MAX_POINTERS_MANAGED];
    private Vect Touch_New[] = new Vect[MAX_POINTERS_MANAGED];
    private Vect Touch_Last[] = new Vect[MAX_POINTERS_MANAGED];
    private Vect Touch_First[] = new Vect[MAX_POINTERS_MANAGED];


    Vect BC_First =new Vect();
    Vect BC_Virtual = new Vect();

    private Vect bitmapPos_New = new Vect();
    private Vect bitmapPos_Last = new Vect();
    private Vect bitmapPos_First = new Vect();
    private Vect pseudo_bitmapCorrected=new Vect();
    private float bitmapScale_New = 1;
    private float bitmapScale_First = 1;
    private float bitmapScale_Last = 1;;

    boolean DrawControlDots=true;

    public Zoom6(Context context, AttributeSet attrs) {
        super(context, attrs);
        TypedArray a = context.getTheme().obtainStyledAttributes(
                attrs,
                R.styleable.Zoom6,
                0, 0);

        try {
            //textPos = a.getInteger(R.styleable.Zoom6_labelPosition, 0);
            //bitmapFullPath_initial= a.getString(R.styleable.Zoom6_path);
        } finally {
            a.recycle();
        }
        initGlobals();
    }
    private void initGlobals() {

        ovalPaint.setStyle(Paint.Style.FILL);
        ovalPaint.setTextSize(textHeight);


        rectPaint.setColor(0xffff0000);
        rectPaint.setStyle(Paint.Style.STROKE);
        rectPaint.setStrokeWidth(1);

        iniResistorColors();
        if(currentBitmap==null) {
            currentBitmap = BitmapFactory.decodeResource(
                    getResources(),
                    R.drawable.instalfer_logo4
            );
        }
        matrixToFit = new Matrix();
        for (int n = 0; n < MAX_POINTERS_MANAGED; n++) {
            Touch_New[n] = new Vect();
            Touch_Last[n] = new Vect();
            Touch_First[n] = new Vect();
        }
    }
    private void iniResistorColors() {

        for (int n = 0; n < MAX_COLORS_COUNT; n++) {
            paint[n] = new Paint();
            paint[n].setStyle(Paint.Style.STROKE);
            paint[n].setStrokeWidth(5);
            switch (n) {
                case 0:
                    paint[n].setColor(Color.BLACK);
                    break;
                case 1:
                    paint[n].setColor(0xFFa83711);//Marron
                    break;
                case 2:
                    paint[n].setColor(Color.RED);
                    break;
                case 3:
                    paint[n].setColor(0xFFff6a00);//naranja
                    break;
                case 4:
                    paint[n].setColor(Color.YELLOW);
                    break;
                case 5:
                    paint[n].setColor(Color.GREEN);
                    break;
                case 6:
                    paint[n].setColor(Color.BLUE);
                    break;
                case 7:
                    paint[n].setColor(0xFFe100ff);//Violeta
                    break;
                case 8:
                    paint[n].setColor(Color.GRAY);
                    break;
                case 9:
                    paint[n].setColor(0xFF00ffe5);
                    break;
            }
        }
    }
    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        // Try for a width based on our minimum
        int minw = getPaddingLeft() + getPaddingRight() + getSuggestedMinimumWidth();
        int w = resolveSizeAndState(minw, widthMeasureSpec, 1);

        // Whatever the width ends up being, ask for a height that would let the pie
        // get as big as it can
        int minh = MeasureSpec.getSize(w) - (int)mTextWidth + getPaddingBottom() + getPaddingTop();
        int h = resolveSizeAndState(MeasureSpec.getSize(w) - (int)mTextWidth, heightMeasureSpec, 0);

        setMeasuredDimension(w, h);
    }
    @Override
    protected void onSizeChanged(int w,int h, int oldw,int oldh)
    {
        super.onSizeChanged(w,h,oldw,oldh);
        // Account for padding
        xpad = (float)(getPaddingLeft() + getPaddingRight());
        ypad = (float)(getPaddingTop() + getPaddingBottom());

        ww = (float)w;// - xpad;
        hh = (float)h;// - ypad;

    }
    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        Vect pseudo_BC_Virtual=new Vect();
        Vect pseudo_center_New;
        Vect pseudo_correction;

        // Draw the shadow
        if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            canvas.drawOval(100, 100, ww - 100, hh - 100, ovalPaint);
        }
        canvas.drawRect(1,1,ww,hh,rectPaint);


        matrixToFit=calculateMatrixToFit(canvas,currentBitmap);

        matrixToFit.postScale(bitmapScale_New, bitmapScale_New);
        if((currentMode== MODE.TRANSLATING)||(currentMode== MODE.NONE)) {
            matrixToFit.postTranslate(bitmapPos_New.x, bitmapPos_New.y);
        }


        if(currentMode== MODE.SCALING) {
            if (Touch_Active[0] && Touch_Active[1]) {
                pseudo_BC_Virtual = BC_Virtual.add(bitmapPos_New);

                pseudo_center_New = Touch_New[0].center(Touch_New[1]);
                pseudo_correction = pseudo_BC_Virtual.sub(pseudo_center_New);
                pseudo_bitmapCorrected = bitmapPos_New.sub(pseudo_correction);
                matrixToFit.postTranslate(pseudo_bitmapCorrected.x, pseudo_bitmapCorrected.y);

            }
        }


        canvas.drawBitmap(currentBitmap, matrixToFit, null);

        if(DrawControlDots) {
            if (Touch_Active[0])
                canvas.drawCircle(Touch_New[0].x, Touch_New[0].y, 100, paint[Touch_ID[0]]);
            if (Touch_Active[1])
                canvas.drawCircle(Touch_New[1].x, Touch_New[1].y, 100, paint[Touch_ID[1]]);
            if (Touch_New!=null)
            {
                if((Touch_New[0]!=null)&&(Touch_New[1]!=null))
                {
                    if(Touch_Active[0]&&Touch_Active[1]) {
                        Vect centerNew = Touch_New[0].center(Touch_New[1]);
                        canvas.drawCircle(bitmapPos_New.x, bitmapPos_New.y, 20, paint[5]);
                        canvas.drawCircle(centerNew.x, centerNew.y, 20, paint[6]);
                        canvas.drawCircle(pseudo_BC_Virtual.x, pseudo_BC_Virtual.y, 20, paint[2]);
                        canvas.drawCircle(pseudo_bitmapCorrected.x, pseudo_bitmapCorrected.y, 20, paint[7]);

                    }
                }
            }
        }
    }
    @Override
    public boolean onTouchEvent(MotionEvent motionEvent) {

        int[] indexCurrent = new int[2];
        Vect center_New = new Vect();
        Vect center_Last = new Vect();
        Vect dif_New = new Vect();
        Vect dif_Last = new Vect();

        final int action = motionEvent.getAction();
        final int pointerIndex = (action & MotionEvent.ACTION_POINTER_INDEX_MASK)
                >> MotionEvent.ACTION_POINTER_INDEX_SHIFT;
        final int pointerId = motionEvent.getPointerId(pointerIndex);

        switch (action & MotionEvent.ACTION_MASK) {
            case MotionEvent.ACTION_DOWN:
            case MotionEvent.ACTION_POINTER_DOWN: {

                if (pointerCount_Current == 2) {
                    //Si ya hay dos dedos en pantalla no se hace nada con el nuevo dedo
                    break;
                }

                if (pointerCount_Current == 1) {
                    //si ya había un dedo en pantalla se añaden los datos del segundo dedo al array Touch.
                    pointerCount_Current = 2;
                    Touch_ID[1] = pointerId;
                    Touch_Active[1] = true;
                    Touch_New[1].set(motionEvent.getX(pointerIndex), motionEvent.getY(pointerIndex));
                    Touch_Last[1].set(Touch_New[1]);
                    Touch_First[1].set(Touch_New[1]);
                    //Se deben reiniciar prácticamente todos los valores del primer dedo
                    //para que no se tengan en cuenta los valores "singleTouch" recogidos
                    //en los anteriroes ciclo "TouchEvent"
                    int pointerZero = motionEvent.findPointerIndex(Touch_ID[0]);
                    if (pointerId != -1) {
                        //Si el puntero devuelto es negativo, ha ocurrido un error puesto
                        //que hemos perdido la pista a el primer dedo
                        Touch_New[0].set(motionEvent.getX(pointerZero), motionEvent.getY(pointerZero));
                        Touch_Last[0].set(Touch_New[0]);
                        Touch_First[0].set(Touch_New[0]);
                    }

                    bitmapScale_First = bitmapScale_New;
                    bitmapScale_Last = bitmapScale_New;
                    bitmapPos_First.set(bitmapPos_New);
                    BC_First = (Touch_First[0].center(Touch_First[1])).sub(bitmapPos_First);
                    BC_Virtual.set(BC_First);
                    currentMode = MODE.SCALING;
                    this.invalidate();
                    break;
                }

                if (pointerCount_Current == 0) {
                    //Si no hay ningún dedo en pantalla se añaden los datos al Touch[0]
                    pointerCount_Current = 1;
                    Touch_ID[0] = pointerId;
                    Touch_Active[0] = true;
                    Touch_New[0].set(motionEvent.getX(pointerIndex), motionEvent.getY(pointerIndex));
                    Touch_Last[0].set(Touch_New[0]);
                    Touch_First[0].set(Touch_New[0]);
                    bitmapPos_First.set(bitmapPos_New);
                    currentMode = MODE.TRANSLATING;
                    this.invalidate();
                    break;
                }
                break;
            }

            case MotionEvent.ACTION_MOVE: {
                switch (pointerCount_Current) {
                    case 0: {
                        //Error
                        break;
                    }
                    case 1: {
                        //Esto debería ocurrir solo durante un evento TRANSLATING
                        //El punto activo debería ser el Touch_Active[0]
                        indexCurrent[0] = motionEvent.findPointerIndex(Touch_ID[0]);
                        if (indexCurrent[0] == -1) {
                            //Algo ha fallado
                            break;
                        }
                        Touch_Last[0].set(Touch_New[0]);
                        Touch_New[0].set(motionEvent.getX(indexCurrent[0]), motionEvent.getY(indexCurrent[0]));
                        bitmapPos_New = bitmapPos_New.add(Touch_New[0].sub(Touch_Last[0]));
                        this.invalidate();
                        break;
                    }
                    case 2: {
                        //Esta parte solo debería ocurrir durante un evento SCALING
                        //Los dos únicos puntos activos deberían ser
                        //Touch_Active[0] y Touch_Active[1]
                        indexCurrent[0] = motionEvent.findPointerIndex(Touch_ID[0]);
                        if (indexCurrent[0] == -1) {
                            //Algo ha fallado
                            break;
                        }
                        indexCurrent[1] = motionEvent.findPointerIndex(Touch_ID[1]);
                        if (indexCurrent[1] == -1) {
                            //Algo ha fallado
                            break;
                        }

                        //Translating
                        Touch_Last[0].set(Touch_New[0]);
                        Touch_Last[1].set(Touch_New[1]);
                        Touch_New[0].set(motionEvent.getX(indexCurrent[0]), motionEvent.getY(indexCurrent[0]));
                        Touch_New[1].set(motionEvent.getX(indexCurrent[1]), motionEvent.getY(indexCurrent[1]));
                        center_New = Touch_New[0].center(Touch_New[1]);
                        center_Last = Touch_Last[0].center(Touch_Last[1]);
                        bitmapPos_Last.set(bitmapPos_New);
                        bitmapPos_New = bitmapPos_New.add(center_New.sub(center_Last));

                        //Scaling
                        dif_New=Touch_New[0].sub(Touch_New[1]);
                        dif_Last=Touch_Last[0].sub(Touch_Last[1]);
                        bitmapScale_Last=bitmapScale_New;
                        bitmapScale_New=bitmapScale_Last/(dif_Last.x)*(dif_New.x);


                        BC_Virtual.set((BC_First.x/bitmapScale_First)*bitmapScale_New,(BC_First.y/bitmapScale_First)*bitmapScale_New);
                        this.invalidate();
                        break;
                    }
                }
                break;
            }
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_POINTER_UP: {
                //Es necesario usar una variable própia para contar los dedos(pointerCount_Current)
                //para desmarcarse de la posibilidad de que el usuario use tres o más dedos
                if (pointerCount_Current == 2) {//Comprobamos si el dedo levantado es alguno de los que se está manejando.
                    //sino... se trata de un tecer dedo y será descartado
                    if (Touch_ID[1] == pointerId) {
                        //Se comprueba primero el segundo miembro del array para
                        //evitar errores al sobrescribir los datos del primer miembro.

                        // el dedo dos deja de estar activo
                        Touch_Active[1] = false;
                        // solo hay un dedo activo
                        pointerCount_Current = 1;
                        //la nueva posicion de translacion es la última posicion de escalado
                        bitmapPos_New.set(pseudo_bitmapCorrected);
                        //el modo actual ya no es escalado, es translacion
                        currentMode = MODE.TRANSLATING;
                        this.invalidate();
                        break;
                    }
                    if (Touch_ID[0] == pointerId) {
                        //Si el dedo levantado es el primer miembro del array,
                        //en necesario sobreescribir todos los datoe del segundo
                        //dedo sobre las variables del dedo levantado
                        Touch_ID[0] = Touch_ID[1];
                        Touch_Active[0] = Touch_Active[1];
                        Touch_New[0].set(Touch_New[1]);
                        Touch_Last[0].set(Touch_Last[1]);
                        Touch_First[0].set(Touch_First[1]);
                        Touch_Active[1] = false;
                        pointerCount_Current = 1;
                        //la nueva posicion de translacion es la última posicion de escalado
                        bitmapPos_New.set(pseudo_bitmapCorrected);
                        currentMode= MODE.TRANSLATING;
                        this.invalidate();
                        break;
                    }
                    break;
                }

                if (pointerCount_Current <= 1) {
                    Touch_Active[1] = false;
                    Touch_Active[0] = false;
                    pointerCount_Current = 0;
                    currentMode = MODE.NONE;
                    this.invalidate();
                    break;
                }
                break;
            }
            case MotionEvent.ACTION_CANCEL: {
                Touch_Active[1] = false;
                Touch_Active[0] = false;
                pointerCount_Current = 0;
                currentMode = MODE.NONE;
                this.invalidate();
                break;
            }
        }
        return true;
    }


    private Matrix calculateMatrixToFit(Canvas canvas, Bitmap bitmapToFit) {
        Matrix returnValue=new Matrix();
        float scaleToFit = (float) canvas.getWidth() / (float) bitmapToFit.getWidth();
        returnValue.postScale(scaleToFit, scaleToFit);

        return returnValue;
    }

    public void setBitmap (Bitmap bitmap)
    {
        if(bitmap!=null) {
            currentBitmap = bitmap;
            this.invalidate();
        }
    }
}
