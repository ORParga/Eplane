package com.orparga.partedehoras03;

import android.content.Context;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;

/**
 * Created by OSCAR on 01/04/2018.
 */
public class FileHandling {
    static String FileName;
    static String Day;
    static String Month;
    static String Year;

    public FileHandling() {

    }

    static public String getDatefromFileName (String fileName)
    {
        Calendar cal= Calendar.getInstance();

        String[] array=fileName.split("_");
        if(array==null)return"";
        if(array.length<3)return "";


        return(array[0]+"/"+array[1]+"/"+array[2]);
    }
    static public String getFileName_fromDateString (String dateString)
    {
        String[] array=dateString.split("/");
        if(array==null)return "";
        if(array.length<3)return "";

        return array[0]+"_"+array[1]+"_"+array[2];
    }
    static public String getFileName(Calendar fileDay) {

        Day = ""+fileDay.get(Calendar.DAY_OF_MONTH);
        Month = ""+(fileDay.get(Calendar.MONTH)+1);
        Year = ""+fileDay.get(Calendar.YEAR);
        FileName= Day+"_"+Month+"_"+Year;
        return FileName;

    }
    static public String getFileName(ParteDeHoras pdh)
    {
        String returnValue=null;

        //Para obtener el nombre del archivo a partir de la clase "ParteDeHoras"
        //primero hay que especificar el formato de la fecha
        SimpleDateFormat sdf=new SimpleDateFormat("dd/MM/yy");
        //Despues, hay que crear un objeto calendario
        Calendar myCalendar= Calendar.getInstance();

        //Despues, hay que cargar la fecha del ParteDeHoras en el
        //objeto Calendario creado
        try {
            myCalendar.setTime(sdf.parse(pdh.Fecha));
        } catch (ParseException e) {
            e.printStackTrace();
            returnValue="";
        }
        if (returnValue!=null) return returnValue;

        //Finalmente, obtenemos el nombre del archivo a partir de este objeto Calendario
        FileName = getFileName(myCalendar);
        return FileName;
    }
    static public String getFileName(int DayNumber, int monthNumber, int yearNumber)
    {
        Calendar cal= Calendar.getInstance();
        cal.set(yearNumber,monthNumber,DayNumber);
        FileName=FileHandling.getFileName(cal);

        return FileName;
    }
    static public boolean exist(Calendar fileDay, Context context) {
        boolean returnValue = true;
        FileName = getFileName(fileDay);
        FileInputStream file;

        try {
            file = context.openFileInput(FileName);
            file.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            returnValue = false;
        } catch (IOException e) {
            returnValue = false;
            e.printStackTrace();
        }
        return returnValue;

    }
    static public boolean exist(String fileName, Context context) {
        boolean returnValue = true;
        FileName = fileName;
        FileInputStream file;

        try {
            file = context.openFileInput(FileName);
            file.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            returnValue = false;
        } catch (IOException e) {
            returnValue = false;
            e.printStackTrace();
        }
        return returnValue;

    }
    public boolean EraseFile (ParteDeHoras l_pdh,Context context)
    {
        File dir,file;
        boolean returnValue=false;
        String filename=getFileName(l_pdh);

        if(exist(filename,context)) {
            dir = context.getFilesDir();
            file = new File(dir,filename);

            if (file != null)
                returnValue=file.delete();
            else
                return false;
        }
        return returnValue;
    }
    public static boolean EraseFile (String fileName,Context context)
    {
        File dir,file;
        boolean returnValue=false;

        if(exist(fileName,context)) {
            dir = context.getFilesDir();
            file = new File(dir,fileName);

            if (file != null)
                returnValue=file.delete();
            else
                return false;
        }
        return returnValue;
    }
    public boolean LoadParteFromFileToClass(Calendar fileDay, Context context, ParteDeHoras pdh)
    {
                String FileName = getFileName(fileDay);

                return LoadParteFromFileToClass(FileName,context,pdh);
    }
    public boolean LoadParteFromFileToClass(String FileName, Context context, ParteDeHoras pdh) {
        return pdh.LoadFromFile(FileName,context);
    }
    static public boolean decodeString (String line, ParteDeHoras l_pdh)
    {
        return ParteDeHoras.decodeStringFromFileToClass(line,l_pdh);
    }
    public boolean SaveParteFromClassToFile(Context context, ParteDeHoras pdh)
    {
        String FileName;
        boolean returnValue = true;

        //obtenemos el nombre del archivo a partir de este objeto pdh
        FileName = getFileName(pdh);

        try {
            //Abrimos el archivo y grabamos todos los datos relevantes
            FileOutputStream fileOutputStream= context.openFileOutput(FileName, Context.MODE_PRIVATE);
            //outputStream= context.openFileOutput("hola",Context.MODE_PRIVATE);
            OutputStreamWriter file =new OutputStreamWriter(fileOutputStream);
            {
                pdh.SaveToFile(file);
            }
            file.close();

            //Verificación via Debugger
//            InputStream file2 = context.openFileInput(FileName);
//            InputStreamReader inputStreamReader = new InputStreamReader(file2);
//            BufferedReader br2= new BufferedReader(inputStreamReader);
//            String line=br2.readLine();
//            int i=br2.read();


            returnValue=true;
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            returnValue = false;
        } catch (IOException e) {
            e.printStackTrace();
            returnValue=false;
        }

        return returnValue;
    }
}
