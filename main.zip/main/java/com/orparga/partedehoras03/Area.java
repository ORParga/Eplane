package com.orparga.partedehoras03;

import org.json.JSONObject;

import java.util.List;

public class Area {
    public String name;
    public double top;
    public double bottom;
    public double left;
    public double right;
    public Area(JSONObject objetoJSON)
    {

        try {
            name = objetoJSON.getString("name");
            top = objetoJSON.getDouble("top");
            left = objetoJSON.getDouble("left");
            bottom = objetoJSON.getDouble("bottom");
            right = objetoJSON.getDouble("right");
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
    }
    static public int SearchForName (List<Area> Area_list, String name)
    {
        int i=0;
        do {
            if(Area_list.get(i).name.equals(name))return i;
            i++;
        }while (i<=Area_list.size());
        return -1;
    }
}
