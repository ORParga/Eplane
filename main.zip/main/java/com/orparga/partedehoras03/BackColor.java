package com.orparga.partedehoras03;

import org.json.JSONObject;

public class BackColor {
    int red=0;
    int green=0;
    int blue=0;
    public BackColor(JSONObject objetoJSON)
    {
        try {
            red = objetoJSON.getInt("red");
        } catch (Exception e) {
            e.printStackTrace();
        }
        try {
            green = objetoJSON.getInt("green");
        } catch (Exception e) {
            e.printStackTrace();
        }
        try {
            blue = objetoJSON.getInt("blue");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
