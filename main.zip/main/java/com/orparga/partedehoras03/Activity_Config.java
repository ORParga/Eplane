package com.orparga.partedehoras03;

import android.graphics.Color;
import android.graphics.PorterDuff;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.TabLayout;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;

public class Activity_Config extends AppCompatActivity {
    private TabLayout tabLayout;
    private int[] tabicons={R.mipmap.ic_printer,R.mipmap.ic_instalfer,R.mipmap.ic_share,R.mipmap.ic_pen};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_config);
        ViewPager viewPager=(ViewPager)findViewById(R.id.viewpager);
        loadViewPager(viewPager);
        tabLayout=(TabLayout)findViewById(R.id.tabs);
        tabLayout.setupWithViewPager(viewPager);
        int childCount=viewPager.getChildCount();
        int tabCount=tabLayout.getTabCount();
        tabIcons();
        iconColor(tabLayout.getTabAt(tabLayout.getSelectedTabPosition()),"#3b5998");
        tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                iconColor(tab,"#3b5998");
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {
                iconColor(tab,"#FFFFFF");

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });

    }
    private void iconColor(TabLayout.Tab tab,String color){
        tab.getIcon().setColorFilter(Color.parseColor(color), PorterDuff.Mode.DST_OVER);
    }
    private void loadViewPager(ViewPager viewPager){
        ViewPageAdapter adapter=new ViewPageAdapter((getSupportFragmentManager()));
        adapter.addFragment(new Fragment_Config_Printer());
        adapter.addFragment(new Fragment_Config_Instalfer());
        adapter.addFragment(new Fragment_Config_Share());
        adapter.addFragment(new Fragment_Config_Autofill());
        viewPager.setAdapter(adapter);
        int childCount=viewPager.getChildCount();

    }

    private void tabIcons(){
        for (int i=0;i<4;i++){
            tabLayout.getTabAt(i).setIcon(tabicons[i]);
        }
    }
    private OneFragment newInstance(String title){
        Bundle bundle=new Bundle();
        bundle.putString("title",title);
        OneFragment fragment=new OneFragment();
        fragment.setArguments(bundle);

        return fragment;
    }
}
