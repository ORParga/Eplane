package com.orparga.partedehoras03;

import android.content.Context;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;

public class SummaryDay {
    enum Failure {NO_ERROR,NO_START_TIME};

    public Integer Day;
    public String HI;
    public String HF;
    public String Observaciones;
    public String TotalHoras;
    public Failure LastFailure;

    protected String FileName="";
    protected FileHandling FH;
    protected ParteDeHoras PDH;
    public SummaryDay()
    {
        Day=0;
        HI="";
        HF="";
        Observaciones="";
        TotalHoras="";

        FH=new FileHandling();
        PDH=new ParteDeHoras();
        LastFailure=Failure.NO_ERROR;
    }


    public static String getTotalHorasNormales(ParteDeHoras l_PDH) {
        String returnValue="",str_differ;
        long differ = 0, differ2 = 0, total = 0;
        for (int index = 0; index < 8; index++) {

            //autocorregirHora(l_PDH.HI_Norm[index], l_PDH.HF_Norm[index]);
            differ = MiFecha.getDifferBetweenCeldsStatic(l_PDH.HI_Norm[index], l_PDH.HF_Norm[index]);
            total += differ;
        }

        str_differ = MiFecha.millisecondsToShortTime(total);


        if(total==0)returnValue="";
        else returnValue=str_differ;

        return returnValue;
    }
    public boolean LoadSummaryDayFromFile (String fileName,Context context)
    {
        if(FH.LoadParteFromFileToClass(fileName,context,PDH)==false)return false;
        if(LoadSummaryDayFromParteDeHoras(PDH,context)==false)return false;

        return true;
    }
    public boolean LoadSummaryDayFromFile (int DayNumber,int monthNumber,int yearNumber,Context context)
    {
        FileName=FileHandling.getFileName(DayNumber, monthNumber, yearNumber);
        if(LoadSummaryDayFromFile(FileName,context)==false)return false;

        return true;
    }

    public boolean LoadSummaryDayFromParteDeHoras (ParteDeHoras PDH,Context context)
    {
        long totalHoras;
        Day=GetDayFromFecha(PDH.Fecha);

        HI=SummaryDay.GetHoraDeEntradaFromParteDeHoras(PDH);
        if(HI.equals(""))LastFailure=Failure.NO_START_TIME;

        HF=SummaryDay.GetHoraDeSalidaFromParteDeHoras(PDH);
        Observaciones=SummaryDay.GetClienteMasSignificativo(PDH);
        if(Observaciones.equals("")||Observaciones.equals(" "))Observaciones=SummaryDay.GetObservacionesMasSignificativas(PDH);
        totalHoras= SummaryDay.GetTotalHorasFromParteDeHoras(PDH);
        if(totalHoras<0)
        {
            TotalHoras="";
        }
        else
        {
            TotalHoras=ParteDeHoras.GetStringFromMillisHour(totalHoras);
        }
        return true;
    }

    public static String GetObservacionesMasSignificativas (ParteDeHoras l_pdh)
    {

        String returnValue="";

        for (int i=0;i<l_pdh.Observaciones_Norm.length;i++) {
            if ((!l_pdh.Observaciones_Norm[i].equals("")) && (!l_pdh.Observaciones_Norm[i].equals(" "))) {
                //Si hay algo que merezca la pena ser guardado
                if (!l_pdh.Observaciones_Norm[i].equals(returnValue)) {
                    //Si lo que hay en la celda es diferente a lo que la funcion va a devolver
                    if ((!returnValue.toLowerCase().equals("taller")) && (!returnValue.equals("")) && (!returnValue.equals(" "))) {
                        //Hay mas de un cliente en esta jornada
                        returnValue = "Varios";
                    }
                    if (returnValue.toLowerCase().equals("taller")) {
                        //lafuncion pretendía devolver "taller" como cliente principal
                        //pero lo encontrado en la celda es mas interesante
                        returnValue = l_pdh.Observaciones_Norm[i];
                    }
                    //returnValue no tiene nada interesante, se sobreescribe con la nueva informacion
                    returnValue = l_pdh.Observaciones_Norm[i];
                }
            }
        }

        for (int i=0;i<l_pdh.Observaciones_Extra.length;i++) {
            if ((!l_pdh.Observaciones_Extra[i].equals("")) && (!l_pdh.Observaciones_Extra[i].equals(" "))) {
                //Si hay algo que merezca la pena ser guardado
                if (!l_pdh.Observaciones_Extra[i].equals(returnValue)) {
                    //Si lo que hay en la celda es diferente a lo que la funcion va a devolver
                    if ((!returnValue.toLowerCase().equals("taller")) && (!returnValue.equals("")) && (!returnValue.equals(" "))) {
                        //Hay mas de un cliente en esta jornada
                        returnValue = "Varios";
                    }
                    if (returnValue.toLowerCase().equals("taller")) {
                        //lafuncion pretendía devolver "taller" como cliente principal
                        //pero lo encontrado en la celda es mas interesante
                        returnValue = l_pdh.Observaciones_Extra[i];
                    }
                    //returnValue no tiene nada interesante, se sobreescribe con la nueva informacion
                    returnValue = l_pdh.Observaciones_Extra[i];
                }
            }
        }

        return returnValue;
    }
    public static String GetClienteMasSignificativo (ParteDeHoras l_pdh)
    {
        String returnValue="";

        for (int i=0;i<l_pdh.Cliente_Norm.length;i++) {
            if ((!l_pdh.Cliente_Norm[i].equals("")) && (!l_pdh.Cliente_Norm[i].equals(" "))) {
                //Si hay algo que merezca la pena ser guardado
                if (!l_pdh.Cliente_Norm[i].equals(returnValue)) {
                    //Si lo que hay en la celda es diferente a lo que la funcion va a devolver
                    if ((!returnValue.toLowerCase().equals("taller")) && (!returnValue.equals("")) && (!returnValue.equals(" "))) {
                        //Hay mas de un cliente en esta jornada
                        returnValue = "Varios";
                    }
                    if (returnValue.toLowerCase().equals("taller")) {
                        //lafuncion pretendía devolver "taller" como cliente principal
                        //pero lo encontrado en la celda es mas interesante
                        returnValue = l_pdh.Cliente_Norm[i];
                    }
                    //returnValue no tiene nada interesante, se sobreescribe con la nueva informacion
                    returnValue = l_pdh.Cliente_Norm[i];
                }
            }
        }

        for (int i=0;i<l_pdh.Cliente_Extra.length;i++) {
            if ((!l_pdh.Cliente_Extra[i].equals("")) && (!l_pdh.Cliente_Extra[i].equals(" "))) {
                //Si hay algo que merezca la pena ser guardado
                if (!l_pdh.Cliente_Extra[i].equals(returnValue)) {
                    //Si lo que hay en la celda es diferente a lo que la funcion va a devolver
                    if ((!returnValue.toLowerCase().equals("taller")) && (!returnValue.equals("")) && (!returnValue.equals(" "))) {
                        //Hay mas de un cliente en esta jornada
                        returnValue = "Varios";
                    }
                    if (returnValue.toLowerCase().equals("taller")) {
                        //lafuncion pretendía devolver "taller" como cliente principal
                        //pero lo encontrado en la celda es mas interesante
                        returnValue = l_pdh.Cliente_Extra[i];
                    }
                    //returnValue no tiene nada interesante, se sobreescribe con la nueva informacion
                    returnValue = l_pdh.Cliente_Extra[i];
                }
            }
        }

        return returnValue;
    }
    public static long GetTotalHorasFromParteDeHoras (ParteDeHoras l_pdh)
    {
        long totalhoras=0;
        long HoraDeInicio;// guarda temporalmente la hora de inicio de la tarea inspeccionada en el bucle for
        long HoraDeSalida=0;//guarda el valor más tardío encontrado en el array de horas normales y extras
        long HoraDeFinalizacion;//guarda temporalmente la hora de finalizacion de la tarea inspeccionada en el bucle for
        long medianoche;

        medianoche=ParteDeHoras.GetMillisFromStringHour("24:00");

        for(int i=0;i<l_pdh.HF_Norm.length;i++)
        {
            HoraDeInicio=ParteDeHoras.GetMillisFromStringHour(l_pdh.HI_Norm[i]);
            HoraDeFinalizacion=ParteDeHoras.GetMillisFromStringHour(l_pdh.HF_Norm[i]);
            if(!((HoraDeInicio<0)||(HoraDeFinalizacion<0))) {
                if (HoraDeFinalizacion < HoraDeInicio) {
                    //si el final se muestra como anterior a la entrada,
                    //se presupone trabajo nocturno que cruza la medianoche
                    HoraDeFinalizacion += medianoche;
                }
                totalhoras += HoraDeFinalizacion - HoraDeInicio;
            }
        }

        for(int i=0;i<l_pdh.HF_Extra.length;i++)
        {
            HoraDeInicio=ParteDeHoras.GetMillisFromStringHour(l_pdh.HI_Extra[i]);
            HoraDeFinalizacion=ParteDeHoras.GetMillisFromStringHour(l_pdh.HF_Extra[i]);
            if(!((HoraDeInicio<0)||(HoraDeFinalizacion<0))) {
                if (HoraDeFinalizacion < HoraDeInicio) {
                    //si el final se muestra como anterior a la entrada,
                    //se presupone trabajo nocturno que cruza la medianoche
                    HoraDeFinalizacion += medianoche;
                }
            }
            totalhoras+=HoraDeFinalizacion-HoraDeInicio;
        }
        return totalhoras;
    }
    public static String GetHoraDeEntradaFromParteDeHoras (ParteDeHoras l_pdh)
    {
        return l_pdh.HI_Norm[0];
    }

    public static String GetHoraDeSalidaFromParteDeHoras (ParteDeHoras l_pdh)
    {
        long HoraDeSalida=0;//guarda el valor más tardío encontrado en el array de horas normales y extras
        long HoraDeInicio;// guarda temporalmente la hora de inicio de la tarea inspeccionada en el bucle for
        long HoraDeFinalizacion;//guarda temporalmente la hora de finalizacion de la tarea inspeccionada en el bucle for
        long medianoche;
        String returnValue=""; // el valor de retorno puede no coincidir con la HoraDeFinalizacion en el caso de trabajo nocturno.

        medianoche=ParteDeHoras.GetMillisFromStringHour("24:00");

        for(int i=0;i<l_pdh.HF_Norm.length;i++)
        {
            HoraDeInicio=ParteDeHoras.GetMillisFromStringHour(l_pdh.HI_Norm[i]);
            HoraDeFinalizacion=ParteDeHoras.GetMillisFromStringHour(l_pdh.HF_Norm[i]);
            if(HoraDeFinalizacion<HoraDeInicio)
            {
                //si el final se muestra como anterior a la entrada,
                //se presupone trabajo nocturno que cruza la medianoche
                HoraDeFinalizacion+=medianoche;
            }
            if(HoraDeFinalizacion>HoraDeSalida)
            {
                HoraDeSalida=HoraDeFinalizacion;
                returnValue=l_pdh.HF_Norm[i];
            }
        }
        for(int i=0;i<l_pdh.HF_Extra.length;i++)
        {
            HoraDeInicio=ParteDeHoras.GetMillisFromStringHour(l_pdh.HI_Extra[i]);
            HoraDeFinalizacion=ParteDeHoras.GetMillisFromStringHour(l_pdh.HF_Extra[i]);
            if(HoraDeFinalizacion<HoraDeInicio)
            {
                //si el final se muestra como anterior a la entrada,
                //se presupone trabajo nocturno que cruza la medianoche
                HoraDeFinalizacion+=medianoche;
            }
            if(HoraDeFinalizacion>HoraDeSalida)
            {
                HoraDeSalida=HoraDeFinalizacion;
                returnValue=l_pdh.HF_Extra[i];
            }
        }

        return returnValue;
    }
    public int GetDayFromFecha (String Fecha)
    {

        int returnValue=0;

        //Para obtener el numewro del dia a partir de un String con la Fecha
        //primero hay que especificar el formato de la fecha
        SimpleDateFormat sdf=new SimpleDateFormat("dd/MM/yy");
        //Despues, hay que crear un objeto calendario
        Calendar myCalendar=Calendar.getInstance();

        //Despues, hay que cargar la fecha en el
        //objeto Calendario creado
        try {
            myCalendar.setTime(sdf.parse(Fecha));
        } catch (ParseException e) {
            e.printStackTrace();
            returnValue=-1;
        }
        if (returnValue!=0) return returnValue;

        //finalmente obtenemos el numero del dia a partir de este objeto calendario

        returnValue=myCalendar.get(Calendar.DAY_OF_MONTH);

        return returnValue;

    }
}
