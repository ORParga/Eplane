package com.orparga.partedehoras03;

import android.os.Debug;
import android.support.v4.app.FragmentManager;
import android.content.Intent;
import android.graphics.Rect;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.DialogFragment;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;

import static android.util.TypedValue.COMPLEX_UNIT_PX;

public class Activity_Intent_CSV extends AppCompatActivity implements
        Activity_Intent_CSV_Dialog_HN_HX.NoticeDialogListener,
        Activity_Intent_CSV_Dialog_Cliente.NoticeDialogListener,
        Activity_Intent_CSV_Dialog_Trabajo.NoticeDialogListener,
        Activity_Intent_CSV_Dialog_Time.NoticeDialogListener
{


    //Activity's Layout****************************************************************************

    LinearLayout[] layout_entrada_Gleeo;
    int[] entrada_Gleeo_Id;

    LinearLayout[] layout_sugerencia_Gleeo;
    int[] sugerencia_Gleeo_Id;
    TextView txtHN_HX,txtHI_sugerencia_Gleeo, txtHF_sugerencia_Gleeo, txtCliente_sugerencia_Gleeo, txtTrabajo_sugerencia_Gleeo;


    //Day selection bar ********************************************************************************
    public enum Button_Type {
        PREV, NEXT, SHARE
    }

    //Text Resize variables ********************************************************************************
    public enum Text_Type {
        SUGGESTED, SOURCE
    }
    float sourceSize=0;
    float suggestedSize=0;

    private Calendar SelectedDate;


    //GleeoIntent Management****************************************************************************
    private SimpleDateFormat sdfDayOfWeek, sdfDayOfYear;
    ParteDeHoras[] pdh_array,comodin;
    int CurrentParte = -1;
    int n_entrada=0,n_sugerencia=0;

    //Entrada Management ********************************************************************************
    Entrada[] entradaArray=new Entrada[ParteDeHoras.Normal_lenght+ParteDeHoras.Extra_lenght];

    private void IniCalendarios() {
        SelectedDate = Calendar.getInstance();
        SelectedDate.setTimeZone(TimeZone.getTimeZone("GMT"));

        Locale Spain = new Locale("es", "ES");
        sdfDayOfWeek = new SimpleDateFormat("EEEE", Spain);
        sdfDayOfYear = new SimpleDateFormat("dd 'de' MMMM 'de' yyyy", Spain);
        sdfDayOfWeek.setTimeZone(TimeZone.getTimeZone("GMT+1"));
        sdfDayOfYear.setTimeZone(TimeZone.getTimeZone("GMT+1"));
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
//TODO: Remove me.  Debug only!
//        while (!Debug.isDebuggerConnected()) {
//            try {
//                Log.d("Activity_intent_CSV", "Waiting for debugger");
//                Thread.sleep(1000);
//            } catch (InterruptedException e) {
//                e.printStackTrace();
//            }
//        }
        setContentView(R.layout.activity_intent_csv_2);
        IniCalendarios();
        IniArrays();
        Uri ParcelableUri = (Uri) PassingDAta.gleeo_Intent.getParcelableExtra(Intent.EXTRA_STREAM);

        if (ParcelableUri == null) {
            Toast.makeText(this, getResources().getString(R.string.app_name) + "  no pudo obtener la ruta al csv!!!",
                    Toast.LENGTH_SHORT).show();
            finish();
        } else {
            List gleeoList = CSV_to_List(ParcelableUri);
            List sortByDayList = SortByDay(gleeoList);
            //seeList(sortByDayList);
            pdh_array = sortByDayList_To_PDHArray(sortByDayList);
            if (pdh_array.length == 0) {
                Toast.makeText(this, getResources().getString(R.string.app_name) + "  no pudo obtener leer el archivo csv!!!",
                        Toast.LENGTH_SHORT).show();
                finish();
            }
            CurrentParte = 0;
            AdjustEnviromentToCurrentParteIndex();

        }

    }
    public void IniArrays ()
    {

        layout_entrada_Gleeo = new LinearLayout[ParteDeHoras.Normal_lenght];
        entrada_Gleeo_Id = new int[ParteDeHoras.Normal_lenght];
        layout_sugerencia_Gleeo = new LinearLayout[ParteDeHoras.Normal_lenght];
        sugerencia_Gleeo_Id = new int[ParteDeHoras.Normal_lenght];
    }

    public List CSV_to_List(Uri ParcelableUri) {
        List resultList = new ArrayList();
        InputStream is = null;
        try {
            is = getContentResolver().openInputStream(ParcelableUri);
            BufferedReader reader = new BufferedReader(new InputStreamReader(is));
            String csvLine;
            while ((csvLine = reader.readLine()) != null) {
                String[] row = csvLine.split(",");
                if (row != null) {
                    Log.d("row", row.toString());
                } else {
                    Log.d("row null", "row null");
                }
                resultList.add(row);
            }
        } catch (IOException ex) {
            throw new RuntimeException("Error in reading CSV file: " + ex);
        } finally {
            try {
                if (is != null) is.close();
            } catch (IOException e) {
                throw new RuntimeException("Error while closing input stream: " + e);
            }
        }
        return resultList;
    }


    //Crea una "Array de Arrays de Arrays de Strings" para ordenar todas las entradas del archivo Gleeo
    //ordenados por dia: El resultado es parecido a esto:
    //List "GleeoList"
    //----List 1 "TimeEntries" ( todas las Strings[] correspondientes a un mismo dia )
    //--------String[] Time Entry 1 - "Date Inicio,""Date Final","Cliente","Trabajos",etc...
    //--------String[] Time Entry 2 - "Date Inicio,""Date Final","Cliente","Trabajos",etc...
    //--------String[] Time Entry 3 - "Date Inicio,""Date Final","Cliente","Trabajos",etc...
    //----List 2 "TimeEntries" ( todas las Strings[] correspondientes a un mismo dia )
    //--------String[] Time Entry 1 - "Date Inicio,""Date Final","Cliente","Trabajos",etc...
    //----List 3 "TimeEntries" ( todas las Strings[] correspondientes a un mismo dia )
    //--------String[] Time Entry 1 - "Date Inicio,""Date Final","Cliente","Trabajos",etc...
    //--------String[] Time Entry 2 - "Date Inicio,""Date Final","Cliente","Trabajos",etc...
    //--------String[] Time Entry 3 - "Date Inicio,""Date Final","Cliente","Trabajos",etc...
    //--------String[] Time Entry 4 - "Date Inicio,""Date Final","Cliente","Trabajos",etc...
    //
    //etc...
    private List SortByDay(List list) {
        String strCurrentGleeoEntryDate;
        List Days = new ArrayList();
        // revisa todas las entradas recibidas de GleeoTimeTracker de una en una
        for (int TimeEntryNumber = 1; TimeEntryNumber < list.size(); TimeEntryNumber++) {
            //obtiene la fecha guardada en "StartTime"
            String[] rowGleeo = (String[]) list.get(TimeEntryNumber);
            String strStarTimeGleeo = rowGleeo[GleeoData.START];
            strCurrentGleeoEntryDate = GetDate(strStarTimeGleeo);
            //compara el dia de la entrada Gleeo con el listado de Dias ya registrado
            boolean newDay = true;
            for (int DayNumber = 0; DayNumber < Days.size(); DayNumber++) {
                //Obtiene la fecha guardada en el String "StartTime" dentro del
                //primer elemento de la Sublista de "TimeEntries" de la lista "Days"
                List SubList = (List) Days.get(DayNumber);
                if (SubList != null) {
                    if (SubList.size() > 0) {
                        String[] row = (String[]) SubList.get(0);
                        String strStarTime = row[GleeoData.START];
                        String strDate = GetDate(strStarTime);
                        //Si encuentra una entrada en un Día ya registrado, la añade al sublistado
                        // dentro del Día
                        if (strDate.equals(strCurrentGleeoEntryDate)) {
                            newDay = false;
                            SubList.add(rowGleeo);
                            break;
                        }
                    }
                }
            }
            //Si no ha encontrado ninguna coincidencia,
            //agrega la "Entrada Gleeo" a un nuevo Dia
            if (newDay) {
                List TimeEntries = new ArrayList();
                TimeEntries.add(rowGleeo);
                Days.add(TimeEntries);
            }
        }
        return Days;
    }

    //Crea un array de partes de horas en el que cada parte guarda únicamente sus entradas
    ParteDeHoras[] sortByDayList_To_PDHArray(List SearchList) {
        ParteDeHoras[] pdh_array = new ParteDeHoras[SearchList.size()];

        for (int Day = 0; Day < SearchList.size(); Day++) {
            pdh_array[Day] = DayList_To_PDH((List) SearchList.get(Day));
        }

        return pdh_array;
    }

    //Recoge todas las
    ParteDeHoras DayList_To_PDH(List DayList) {
        ParteDeHoras pdh = new ParteDeHoras();

        pdh.Operario = PassingDAta.cnf_Nombre_operario;
        pdh.Fecha = GetDate(((String[]) DayList.get(0))[GleeoData.START]);
        for (int TimeEntry = 0; TimeEntry < DayList.size(); TimeEntry++) {
            if (TimeEntry > pdh.HI_Norm.length) {
                // si el numero de entradas es pañor que las lineas disponibles en el parte,
                // la app coloca un comentario en la última linea
                pdh.HF_Norm[pdh.HI_Norm.length - 1] = GetTime(((String[]) DayList.get(DayList.size() - 1))[GleeoData.END]);
                pdh.Observaciones_Norm[pdh.HI_Norm.length - 1] = "Demasiadas entradas";
                break;
            }
            pdh.HI_Norm[TimeEntry] = GetTime(((String[]) DayList.get(TimeEntry))[GleeoData.START]);
            pdh.HF_Norm[TimeEntry] = GetTime(((String[]) DayList.get(TimeEntry))[GleeoData.END]);
            pdh.Cliente_Norm[TimeEntry] = ((String[]) DayList.get(TimeEntry))[GleeoData.TASK];
            pdh.Observaciones_Norm[TimeEntry] = ((String[]) DayList.get(TimeEntry))[GleeoData.DETAILS];
        }
        return pdh;
    }

    //Evalua si hay una hora de la comida en el parte de horas recibido
    //y si no lo hay... sugiere uno
    ParteDeHoras NegociateLunch(ParteDeHoras pdh_local)
    {

        return pdh_local;
    }
//
//    //_Coge todas las horas normales y las separa en normales y extras.
//    //(utiliza la varieble PassingDAta.cnf_jornada_normal)
//    //(Borra cualquier entrada en "horas Extras")
//    ParteDeHoras NegociateExtras (ParteDeHoras local_pdh)
//    {
//        //Copiamos el parte pasado a la función
//        //para modificar lobremente "local_pdh" que es un
//        //puntero "estable"
//        ParteDeHoras original=new ParteDeHoras();
//        original=ParteDeHoras.CopyParte(local_pdh,original);
//        Calendar cal_jornada_duracion=Calendar.getInstance();
//        Calendar cal_comodin=Calendar.getInstance();
//        SimpleDateFormat sdf,sdf_date;
//        int i;
//        int current_extra=0;
//
//
//        if(original==null)return null;
//
//        long totalHorasTrabajadas = ParteDeHoras.GetTotalMillisInParte(original),
//                CurrentHorasTrabajadas,
//                milis_jornada_duracion;
//
//        sdf = new SimpleDateFormat("HH:mm");
//        sdf.setTimeZone(TimeZone.getTimeZone("GMT +0"));
//        try {
//            cal_jornada_duracion.setTime(sdf.parse(PassingDAta.cnf_jornada_normal));
//            milis_jornada_duracion=cal_jornada_duracion.getTimeInMillis();
//        }
//        catch (Exception e){return null; }
//
//        //Si no hay horas extras, devolvemos el parte sin modificarlo
//        if (totalHorasTrabajadas<=milis_jornada_duracion)return original;
//
//
//        if(original.HI_Norm!=null) {
//            if (original.HF_Norm != null) {
//
//                for (i = 0,totalHorasTrabajadas=0; (i < ParteDeHoras.Normal_lenght) || (i < ParteDeHoras.Normal_lenght); i++) {
//                    CurrentHorasTrabajadas=ParteDeHoras.GetMillisFrom_IntervaloEntreHoras(original.HI_Norm[i],original.HF_Norm[i]);
//                    if((totalHorasTrabajadas+CurrentHorasTrabajadas)>milis_jornada_duracion)
//                    {
//                        //Si las horas pasan a ser horas extras, se borran del array "normales" y se copian en el array "Extras"
//                        if(totalHorasTrabajadas<milis_jornada_duracion)
//                        {
//                            //Si las horas sumadas hasta el momento, no cuadran exactamente con las horas normales,
//                            //se divide la última entrada entre horas normales y horas extras
//                            long inicio_hora_normal,fin_hora_normal;
//                            long intervalo_hora_normal=milis_jornada_duracion-totalHorasTrabajadas;
//
//                            try {
//                                cal_comodin.setTime(sdf.parse(original.HI_Norm[i]));
//                                inicio_hora_normal=cal_jornada_duracion.getTimeInMillis();
//                                fin_hora_normal=inicio_hora_normal+intervalo_hora_normal;
//                                cal_comodin.setTimeInMillis(fin_hora_normal);
//                            }
//                            catch (Exception e){
//                                //Si encuentra una hora que no puede convertir,
//                                //se interpreta como el final de las horas normales
//                                return local_pdh; }
//                            local_pdh.HF_Norm[i]=sdf.format(cal_comodin.getTime());
//                            local_pdh.HI_Extra[0]=local_pdh.HF_Norm[i];
//                            local_pdh.HF_Extra[0]=original.HF_Norm[i];
//                            current_extra=1;
//                            i++;
//
//                        }
//                        //todas las horas posteriores al horario normal se añaden al array "horas extras"
//
//                        for (;i<original.HI_Norm.length;i++,current_extra++)
//                        {
//                            if(current_extra>=local_pdh.HI_Extra.length)
//                            {
//                                //Si no caben todas las entradas en "horas Extras"
//                                current_extra=local_pdh.HF_Extra.length-1;
//
//                                if(!local_pdh.Cliente_Extra[current_extra].equals(original.Cliente_Norm[i]))
//                                {
//                                    //Si todos los "Cliente" que no caben en el array "horas Extras"
//                                    //son el mismo cliente, no pasa nada, pero sino, se pone "Varios"
//                                    local_pdh.Cliente_Extra[current_extra]="Varios";
//                                }
//                                if(!local_pdh.Observaciones_Extra[current_extra].equals(original.Observaciones_Norm[i]))
//                                {
//                                    //Si todos los "Observaciones" que no caben en el array "horas Extras"
//                                    //son el mismo cliente, no pasa nada, pero sino, se pone "Varios"
//                                    local_pdh.Observaciones_Extra[current_extra]="Varios";
//                                }
//                            }
//                            else {
//                                //Si aún hay espacio en el array "Extra"
//                                local_pdh.HI_Extra[current_extra] = original.HF_Norm[i];
//                                local_pdh.HF_Extra[current_extra] = original.HF_Norm[i];
//                            }
//                        }
//                    }
//                    else
//                    {
//                        //Si las horas siguen entrando dentro de horas normales, se dejan tal cual en el
//                        //parte "local_pdh"
//                    }
//                }
//            }
//        }
//
//
//        return local_pdh;
//    }
    String GetDate(String GleeoDateString) {
        String returnValue = "";

        Date d = new Date();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm");
        try {
            d = sdf.parse(GleeoDateString);
        } catch (ParseException ex) {
            Log.v("Exception", ex.getLocalizedMessage());
        }
        sdf.applyPattern("dd/MM/yyyy");
        returnValue = sdf.format(d);

        return returnValue;
    }

    String GetTime(String GleeoDateString) {
        String returnValue = "";

        Date d = new Date();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm");
        try {
            d = sdf.parse(GleeoDateString);
        } catch (ParseException ex) {
            Log.v("Exception", ex.getLocalizedMessage());
        }
        sdf.applyPattern("HH:mm");
        returnValue = sdf.format(d);

        return returnValue;
    }
//
//    protected void CrearTablaEntradaGleeo() {
//        int newId;
//        int Last_day_in_month = 3;
//        layout_tabla = findViewById(R.id.tableSource);
//        layout_entrada_Gleeo = new LinearLayout[Last_day_in_month];
//        entrada_Gleeo_Id = new int[Last_day_in_month];
//
//        for (int i = 0; i < Last_day_in_month; i++) {
//            // create a new linearLayout
//
//            View v = LayoutInflater.from(this).inflate(R.layout.control_entrada_gleeo, null);
//
//
//            final LinearLayout layoutDay = (LinearLayout) v;
//            // add the line of day to the main linearlayout
//            layout_tabla.addView(v);
//            newId = layout_tabla.generateViewId();
//            layoutDay.setId(newId);
//            // save a reference to "the day" for later
//            layout_entrada_Gleeo[i] = layoutDay;
//            entrada_Gleeo_Id[i] = newId;
//            //Get acces to the inner TextViews
//            txtHI_entrada_Gleeo = layoutDay.findViewById(R.id.HI_entrada_gleeo);
//            txtHF_entrada_Gleeo = layoutDay.findViewById(R.id.HF_entrada_gleeo);
//            txtCliente_entrada_Gleeo = layoutDay.findViewById(R.id.Cliente_entrada_gleeo);
//            txtTrabajo_entrada_Gleeo = layoutDay.findViewById(R.id.Trabajo_entrada_gleeo);
//
//        }
//
//    }
//
//    protected void CrearTablaSugerenciaGleeo() {
//        int newId;
//        int Last_day_in_month = 3;
//        layout_tabla = findViewById(R.id.tableDestination);
//        layout_sugerencia_Gleeo = new LinearLayout[Last_day_in_month];
//        sugerencia_Gleeo_Id = new int[Last_day_in_month];
//
//        for (int i = 0; i < Last_day_in_month; i++) {
//            // create a new linearLayout
//
//            View v = LayoutInflater.from(this).inflate(R.layout.control_sugerencia_gleeo, null);
//
//
//            final LinearLayout layoutDay = (LinearLayout) v;
//            // add the line of day to the main linearlayout
//            layout_tabla.addView(v);
//            newId = layout_tabla.generateViewId();
//            layoutDay.setId(newId);
//            // save a reference to "the day" for later
//            layout_sugerencia_Gleeo[i] = layoutDay;
//            sugerencia_Gleeo_Id[i] = newId;
//            //Get acces to the inner TextViews
//            txtHN_HX=layoutDay.findViewById(R.id.HI_HF_sugerencia_gleeo);
//            txtHI_sugerencia_Gleeo = layoutDay.findViewById(R.id.HI_sugerencia_gleeo);
//            txtHF_sugerencia_Gleeo = layoutDay.findViewById(R.id.HF_sugerencia_gleeo);
//            txtCliente_sugerencia_Gleeo = layoutDay.findViewById(R.id.Cliente_sugerencia_gleeo);
//            txtTrabajo_sugerencia_Gleeo = layoutDay.findViewById(R.id.Trabajo_sugerencia_gleeo);
//
//        }
//
//    }

    void DisableAll ()
    {
        SetButton(Button_Type.NEXT, false);
        SetButton(Button_Type.PREV, false);
        SetButton(Button_Type.SHARE, false);
        LinearLayout Table= findViewById(R.id.tableSource);
        Table.removeAllViews();
        Table= findViewById(R.id.tableDestination);
        Table.removeAllViews();
        Button b= findViewById(R.id.btn_Save);
        b.setTextColor(getResources().getColor(R.color.colorButtonTextDisabled));
        b.setClickable(false);
        b= findViewById(R.id.btn_Discard);
        b.setTextColor(getResources().getColor(R.color.colorButtonTextDisabled));
        b.setClickable(false);
    }
    void AdjustEnviromentToCurrentParteIndex() {

        //Antes de empezar nos quitamos de encima, el caso en
        //el que no hay partes en el array
        if (pdh_array == null) DisableAll();
        else if(pdh_array.length==0)DisableAll();
        else  SetButton(Button_Type.SHARE, true);

        //Nos ocupamos del Botton NEXT
        if (CurrentParte >= pdh_array.length) CurrentParte = pdh_array.length - 1;
        if (CurrentParte == (pdh_array.length - 1)) {
            SetButton(Button_Type.NEXT, false);
        } else {
            SetButton(Button_Type.NEXT, true);
        }

        //Nos ocupamos del Botton PREV
        if (CurrentParte < 0) CurrentParte = 0;
        if (CurrentParte == 0) {
            SetButton(Button_Type.PREV, false);
        } else {
            SetButton(Button_Type.PREV, true);
        }

        //Nos ocupamos de mostrar la fecha correspondiente a "CurrentParte"
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy", Locale.ENGLISH);
        sdf.setTimeZone(TimeZone.getTimeZone("GMT+1"));
        try {
            SelectedDate.setTime(sdf.parse(pdh_array[CurrentParte].Fecha));// all done
        } catch (Exception e) {
            e.printStackTrace();
            DisableDateBox();
            return;
        }
        SetDateInTittle();

        //Rellenamos las tablas con los datos de "CurrentParte"
        Show_Parte_In_Source_table(pdh_array[CurrentParte]);
        ParteDeHoras pdhSuggested = new ParteDeHoras();
        if (CreateSuggestedParte(pdh_array[CurrentParte], pdhSuggested))
        {
            Show_Parte_In_Suggested_table(pdhSuggested);
        }
    }

    //Crea un Parte de horas a partir de un parte de horas con irregularidades
    //Por ejemplo, redondea la hora a la media mas cercana ...
    //añade la hora de la comida...
    //separa horas normales de horas extras.
    boolean CreateSuggestedParte(ParteDeHoras pdhSource,ParteDeHoras pdhSuggested)
    {
        if(pdhSource==null)return false;
        if(pdhSuggested==null)pdhSuggested=new ParteDeHoras();
        if(pdhSource.HI_Norm==null)return false;
        if(pdhSource.HF_Norm==null)return false;

        //Copia la informacion básica del parte, fecha y nombre
        pdhSuggested.Fecha=pdhSource.Fecha;
        pdhSuggested.Operario=pdhSource.Operario;
        pdhSuggested.Total_Extra=pdhSource.Total_Extra;
        pdhSuggested.Total_Normales=pdhSource.Total_Normales;
        //Primero redondea las hora ******************************************************
        for (int i=0;i<ParteDeHoras.Normal_lenght;i++)
        {
            if(pdhSource.HI_Norm[i]!=null) {
                if (!pdhSource.HI_Norm[i].equals("")) {
                    pdhSuggested.HI_Norm[i] = RedondearHora(pdhSource.HI_Norm[i]);
                }
            }

            if(pdhSource.HF_Norm[i]!=null) {
                if (!pdhSource.HF_Norm[i].equals("")) {
                    pdhSuggested.HF_Norm[i] = RedondearHora(pdhSource.HF_Norm[i]);
                }
            }
            if(pdhSource.Cliente_Norm[i]!=null) {
                if (!pdhSource.Cliente_Norm[i].equals("")) {
                    pdhSuggested.Cliente_Norm[i] = pdhSource.Cliente_Norm[i];
                }
            }
            if(pdhSource.Observaciones_Norm[i]!=null) {
                if (!pdhSource.Observaciones_Norm[i].equals("")) {
                    pdhSuggested.Observaciones_Norm[i] =pdhSource.Observaciones_Norm[i];
                }
            }
        }
        //Segundo, busca si se ha introducido hora de la comida
        //Si hay un vacío de media hora o mas entre una entrada y la siguiente en torno al mediodiá
        //se interpreta como hora de la comida
        int NEntradas=pdhSuggested.getEntradaArray(entradaArray);
        for(int n=0;n<NEntradas;n++)
        {
            if((n+1)<NEntradas)
            {
                long intervalo=ParteDeHoras.GetMillisFrom_IntervaloEntreHoras(entradaArray[n].HF,entradaArray[n+1].HI);
                if(intervalo>getResources().getInteger(R.integer.comida_minima_milis))
                {
                    //se ha encontrado la hora de la comida
                    break;
                }
            }
            else
            {
                //No hay hora de la comida
                //Por defecto... solo se inserta la hora de la comida si hay una
                //entrada que engloba la hora de inicio y la hora final de
                // la comida
                long HI_comida_milis=ParteDeHoras.GetMillisFromStringHour(PassingDAta.cnf_HI_comida);
                long HF_comida_milis=ParteDeHoras.GetMillisFromStringHour(PassingDAta.cnf_HF_comida);
                for(int m=0;m<NEntradas;m++)
                {
                    long hi_entrada_milis=ParteDeHoras.GetMillisFromStringHour(entradaArray[m].HI);
                    if(hi_entrada_milis<HI_comida_milis)
                    {
                        long hf_salida_milis=ParteDeHoras.GetMillisFromStringHour(entradaArray[m].HF);
                        if(hf_salida_milis>HF_comida_milis)
                        {
                            //Se ha encontrado un lugar donde se puede insertar la hora de la comida
                            //desplaza el array a partir de este punto para dejar espacio para la
                            //nueva entrada
                            for(int p=(NEntradas-1);p>=m;p--)
                            {
                                if((p+1)>entradaArray.length)
                                {
                                    //Si se supera el límite del array
                                    //no es posible ofrecer una sugerencia
                                    //el usuario deberá editar el Parte de Horas manualmente
                                    return false;
                                }
                                entradaArray[p+1]=new Entrada(entradaArray[p].HI,entradaArray[p].HF,entradaArray[p].Cliente,entradaArray[p].Observaciones,entradaArray[p].tipoDeHora);

                            }
                            //una vez se ha conseguido sitio, se copia la hora de la comida
                            //El inicio de la comida sobreescribe la "hora final" de la entrada editada
                            entradaArray[m].HF=PassingDAta.cnf_HI_comida;
                            //El final de la comida sobreescribe la "hora de inicio" de la nueva entrada
                            entradaArray[m+1].HI=PassingDAta.cnf_HF_comida;
                            NEntradas++;//ahora hay una entrada más
                            m=NEntradas;//Salida del bucle principal
                            break;
                        }
                    }
                }
            }
        }

        //Tercero, Calcula las horas extras
        long TotalHoras_Milis = ParteDeHoras.GetTotalMillisInParte(entradaArray,NEntradas);
        long JornadaNormal_Milis=ParteDeHoras.GetMillisFromStringHour(PassingDAta.cnf_jornada_normal);
        long HorasExtras_Milis=TotalHoras_Milis-JornadaNormal_Milis;

        if(HorasExtras_Milis>0) {
            long jornadaHastaEntradaActual_Milis = 0;
            //Calcula en qué punto del parte, empiezan las horas extras
            for (int entradaActual = 0; entradaActual < NEntradas; entradaActual++) {
                jornadaHastaEntradaActual_Milis += ParteDeHoras.GetMillisFrom_IntervaloEntreHoras(entradaArray[entradaActual].HI, entradaArray[entradaActual].HF);
                if (jornadaHastaEntradaActual_Milis > JornadaNormal_Milis) {
                    //Aquí empiezan las horas extras
                    //es necesario dividir esta entrada en dos, una parte es normal y otra es extra
                    // desplaza el array a partir de este punto para dejar espacio para la
                    //nueva entrada
                    for(int p=(NEntradas-1);p>=entradaActual;p--)
                    {
                        if((p+1)>entradaArray.length)
                        {
                            //Si se supera el límite del array
                            //no es posible ofrecer una sugerencia
                            //el usuario deberá editar el Parte de Horas manualmente
                            return false;
                        }
                        entradaArray[p+1]=new Entrada(entradaArray[p].HI,entradaArray[p].HF,entradaArray[p].Cliente,entradaArray[p].Observaciones,Entrada.TipoDeHora.EXTRA);

                    }
                    //Es necesario calcular la hora en la que las horas normales se convierten en Extras
                    long jornadaHastaEntradaAnterior=jornadaHastaEntradaActual_Milis-ParteDeHoras.GetMillisFrom_IntervaloEntreHoras(entradaArray[entradaActual].HI,entradaArray[entradaActual].HF);
                    long porcionNormal=JornadaNormal_Milis-jornadaHastaEntradaAnterior;
                    long horaRuptura=ParteDeHoras.GetMillisFromStringHour(entradaArray[entradaActual].HI)+porcionNormal;
                    String horaRuptura_str=ParteDeHoras.GetStringFromMillisHour((horaRuptura));

                    //una vez se ha conseguido sitio, se copia la hora de la comida
                    //El inicio de las extras sobreescribe la "hora final" de la entrada editada
                    entradaArray[entradaActual].HF=horaRuptura_str;
                    //El inicio de las extras sobreescribe la "hora de inicio" de la nueva entrada
                    entradaArray[entradaActual+1].HI=horaRuptura_str;
                    entradaArray[entradaActual+1].tipoDeHora= Entrada.TipoDeHora.EXTRA;
                    NEntradas++;//ahora hay una entrada más
                    break;//Mision cumplida.Salimos del bucle.
                }
                else
                {
                    if (jornadaHastaEntradaActual_Milis == JornadaNormal_Milis) {
                        //a partir de aquí las siguientes entradas son horas extras,
                        //pero esta sigue siendo normal
                        entradaArray[entradaActual].tipoDeHora = Entrada.TipoDeHora.NORMAL;

                    }
                    else
                    {
                        //Si no se cumple ninguna de las premisas anteriores, la hora es del tipo "Normal"
                        entradaArray[entradaActual].tipoDeHora = Entrada.TipoDeHora.NORMAL;
                    }
                }

            }
        }

        //Cuarto, Guarda todas las entradas calculadas en un ParteDeHoras
        if(pdhSuggested.LoadFromEntradaArray(entradaArray,NEntradas)==false)
            return false;//Si se supera el límite de entradas, no se puede ofrecer sugerencia

        return true;
    }
    String RedondearHora (String hora) {
        String returnValue = "";
        Date h;

        SimpleDateFormat sdf = new SimpleDateFormat("HH:mm", Locale.ENGLISH);
        sdf.setTimeZone(TimeZone.getTimeZone("GMT+1"));

        try {
            h = sdf.parse(hora);
        } catch (Exception e) {
            e.printStackTrace();
            return "";
        }
        Calendar c = Calendar.getInstance();
        c.setTime(h);

        int minute = c.get(Calendar.MINUTE);
        if (minute <= 15) minute = 0;
        if ((minute > 15) && (minute <= 45)) minute = 30;
        if (minute > 45) {
            minute=0;
            c.add(Calendar.HOUR,1);
        }
        c.set(Calendar.MINUTE,minute);
        h=c.getTime();
        return sdf.format(h);
    }
    void SetButton(Button_Type button, boolean enabled) {
        switch (button) {
            case PREV:
                if (enabled)
                    ((ImageButton) findViewById(R.id.imageButton2)).setImageResource(R.drawable.ic_prev2);
                else
                    ((ImageButton) findViewById(R.id.imageButton2)).setImageResource(R.drawable.ic_prev2_disabled);
                break;
            case NEXT:
                if (enabled)
                    ((ImageButton) findViewById(R.id.imageButton3)).setImageResource(R.drawable.ic_next2);
                else
                    ((ImageButton) findViewById(R.id.imageButton3)).setImageResource(R.drawable.ic_next2_disabled);
                break;
        }
    }

    protected void SetDateInTittle() {
        Date date = SelectedDate.getTime();
        String strDateWeek = sdfDayOfWeek.format(date);
        strDateWeek = strDateWeek.substring(0, 1).toUpperCase() + strDateWeek.substring(1);
        String strDateYear = sdfDayOfYear.format(date);

        TextView dayOfTheWeek = (TextView) findViewById(R.id.lblDayWeek);
        TextView dayOfTheYear = (TextView) findViewById(R.id.lblDayOfTheYear);
        dayOfTheWeek.setText(strDateWeek);
        dayOfTheYear.setText(strDateYear);
        dayOfTheWeek.refreshDrawableState();
        dayOfTheYear.refreshDrawableState();
    }

    void DisableDateBox() {
        ((TextView) findViewById(R.id.lblDayOfTheYear)).setText("00/00/0000");
        ((TextView) findViewById(R.id.lblDayWeek)).setText("--");
    }

    public void onClick_Prev_CSV(View v) {

        CurrentParte--;
        AdjustEnviromentToCurrentParteIndex();
    }

    public void onClick_Next_CSV(View v) {

        CurrentParte++;
        AdjustEnviromentToCurrentParteIndex();
    }

    public void onClick_SelectDate_CSV(View v) {

    }
    // The dialog fragment receives a reference to this Activity through the
    // Fragment.onAttach() callback, which it uses to call the following methods
    // defined by the NoticeDialogFragment.NoticeDialogListener interface
    @Override
    public void onTipoDeHoraSeleccionada(DialogFragment dialog) {
        // User touched the dialog's positive button
        switch (PassingDAta.CSV_Dialog_HX_HN)
        {
            case HN:
                ((TextView)PassingDAta.CSV_View_Clicked).setText("N");
                break;
            case HX:
                ((TextView)PassingDAta.CSV_View_Clicked).setText("X");
                break;
        }
        ((TextView)PassingDAta.CSV_View_Clicked).setBackgroundResource(R.color.colorBackcolor);

    }
    @Override
    public void onClienteSeleccionado(DialogFragment dialog) {
        // User touched the dialog's positive button
        ((TextView)PassingDAta.CSV_View_Clicked).setText(PassingDAta.CSV_Dialog_Cliente);
        ((TextView)PassingDAta.CSV_View_Clicked).setBackgroundResource(R.color.colorBackcolor);
    }
    @Override
    public void onClientePositiveClick(DialogFragment dialog) {
        // User touched the dialog's positive button
        ((TextView)PassingDAta.CSV_View_Clicked).setText(PassingDAta.CSV_Dialog_Cliente);
        ((TextView)PassingDAta.CSV_View_Clicked).setBackgroundResource(R.color.colorBackcolor);
    }
    @Override
    public void onClienteNegativeClick(DialogFragment dialog) {
        // User touched the dialog's negative button
        ((TextView)PassingDAta.CSV_View_Clicked).setBackgroundResource(R.color.colorBackcolor);
    }
    @Override
    public void onTrabajoSeleccionado(DialogFragment dialog) {
        // User touched the dialog's positive button
        ((TextView)PassingDAta.CSV_View_Clicked).setText(PassingDAta.CSV_Dialog_Trabajo);
        ((TextView)PassingDAta.CSV_View_Clicked).setBackgroundResource(R.color.colorBackcolor);
    }
    @Override
    public void onTrabajoPositiveClick(DialogFragment dialog) {
        // User touched the dialog's positive button
        ((TextView)PassingDAta.CSV_View_Clicked).setText(PassingDAta.CSV_Dialog_Trabajo);
        ((TextView)PassingDAta.CSV_View_Clicked).setBackgroundResource(R.color.colorBackcolor);
    }
    @Override
    public void onTimeSeleccionado() {
        // User selected Time
        String timeString=MiFecha.HoraMinuteToString(PassingDAta.CSV_Dialog_hour,PassingDAta.CSV_Dialog_minute);
        ((TextView)PassingDAta.CSV_View_Clicked).setText(timeString);
        ((TextView)PassingDAta.CSV_View_Clicked).setBackgroundResource(R.color.colorBackcolor);
    }
    @Override
    public void onTrabajoNegativeClick(DialogFragment dialog) {
        // User touched the dialog's negative button
        ((TextView)PassingDAta.CSV_View_Clicked).setBackgroundResource(R.color.colorBackcolor);
    }
    public void onClick_control_sugerencia_HN_HX_CSV (View v){
        FragmentManager manager = getSupportFragmentManager();

        PassingDAta.CSV_View_Clicked=v;
        Activity_Intent_CSV_Dialog_HN_HX AICD=new Activity_Intent_CSV_Dialog_HN_HX();
        AICD.show(manager,"HN_HX_Dialog");
        v.setBackgroundResource(R.color.colorTextViewSelected);
    }
    public void onClick_control_sugerencia_HI_CSV (View v){
        PassingDAta.CSV_View_Clicked=v;
        DialogFragment newFragment = new Activity_Intent_CSV_Dialog_Time();
        newFragment.show(getSupportFragmentManager(), "timePicker");
        v.setBackgroundResource(R.color.colorTextViewSelected);

    }
    public void onClick_control_sugerencia_HF_CSV (View v){
        PassingDAta.CSV_View_Clicked=v;
        DialogFragment newFragment = new Activity_Intent_CSV_Dialog_Time();
        newFragment.show(getSupportFragmentManager(), "timePicker");
        v.setBackgroundResource(R.color.colorTextViewSelected);

    }
    public void onClick_control_sugerencia_Cliente_CSV (View v){
        FragmentManager manager = getSupportFragmentManager();

        PassingDAta.CSV_View_Clicked=v;
        PassingDAta.CSV_Dialog_Cliente=((TextView)v).getText().toString();
        Activity_Intent_CSV_Dialog_Cliente AICD=new Activity_Intent_CSV_Dialog_Cliente();
        AICD.show(manager,"Cliente_Dialog");
        v.setBackgroundResource(R.color.colorTextViewSelected);

    }
    public void onClick_control_sugerencia_Trabajo_CSV (View v){
        FragmentManager manager = getSupportFragmentManager();

        PassingDAta.CSV_View_Clicked=v;
        PassingDAta.CSV_Dialog_Trabajo=((TextView)v).getText().toString();
        Activity_Intent_CSV_Dialog_Trabajo AICD=new Activity_Intent_CSV_Dialog_Trabajo();
        AICD.show(manager,"Trabajo_Dialog");
        v.setBackgroundResource(R.color.colorTextViewSelected);
    }
    private void Show_Parte_In_Source_table (ParteDeHoras pdh)
    {
        LinearLayout SourceTable= findViewById(R.id.tableSource);
        SourceTable.removeAllViews();
        n_entrada=0;
        for(int i=0;i<pdh.HI_Norm.length;i++) {
            if(pdh.HI_Norm[i]!=null) {
                if (!pdh.HI_Norm[i].equals("")) {
                    Add_Line_In_PDH_To_Source_Table(pdh, i);
                }
            }
        }
    }

    private void Show_Parte_In_Suggested_table (ParteDeHoras pdh)
    {
        LinearLayout SourceTable= findViewById(R.id.tableDestination);
        SourceTable.removeAllViews();
        n_sugerencia=0;
        for(int i=0;i<pdh.HI_Norm.length;i++) {
            if(pdh.HI_Norm[i]!=null) {
                if (!pdh.HI_Norm[i].equals("")) {
                    Add_Line_In_PDH_To_Suggested_Table(pdh, i);
                }
            }
        }
        for(int i=0;i<pdh.HI_Extra.length;i++) {
            if(pdh.HI_Extra[i]!=null) {
                if (!pdh.HI_Extra[i].equals("")) {
                    Add_Extra_Line_In_PDH_To_Suggested_Table(pdh, i);
                }
            }
        }
    }
    private void Add_Line_In_PDH_To_Source_Table(ParteDeHoras pdh,int i)
    {
        TextView txtHI_entrada_Gleeo, txtHF_entrada_Gleeo, txtCliente_entrada_Gleeo, txtTrabajo_entrada_Gleeo;
        LinearLayout SourceTable= findViewById(R.id.tableSource);

        View v = LayoutInflater.from(this).inflate(R.layout.control_entrada_gleeo, null);


        final LinearLayout layoutDay = (LinearLayout) v;
        // add the line of day to the main linearlayout
        SourceTable.addView(v);
        int newId = SourceTable.generateViewId();
        layoutDay.setId(newId);
        // save a reference to "the day" for later
        layout_entrada_Gleeo[n_entrada] = layoutDay;
        entrada_Gleeo_Id[n_entrada] = newId;
        n_entrada++;
        //Get acces to the inner TextViews
        txtHI_entrada_Gleeo = layoutDay.findViewById(R.id.HI_entrada_gleeo);
        txtHF_entrada_Gleeo = layoutDay.findViewById(R.id.HF_entrada_gleeo);
        txtCliente_entrada_Gleeo = layoutDay.findViewById(R.id.Cliente_entrada_gleeo);
        txtTrabajo_entrada_Gleeo = layoutDay.findViewById(R.id.Trabajo_entrada_gleeo);

        txtHI_entrada_Gleeo.setText(pdh.HI_Norm[i]);
        ResizeTextToFit(txtHI_entrada_Gleeo,Text_Type.SOURCE);
        txtHF_entrada_Gleeo.setText(pdh.HF_Norm[i]);
        ResizeTextToFit(txtHF_entrada_Gleeo,Text_Type.SOURCE);
        txtCliente_entrada_Gleeo.setText(pdh.Cliente_Norm[i]);
        ResizeTextToFit(txtCliente_entrada_Gleeo,Text_Type.SOURCE);
        txtTrabajo_entrada_Gleeo.setText(pdh.Observaciones_Norm[i]);
        ResizeTextToFit(txtTrabajo_entrada_Gleeo,Text_Type.SOURCE);
    }
    private void Add_Line_In_PDH_To_Suggested_Table(ParteDeHoras pdh,int i)
    {
        TextView txtHN_HX,txtHI_Suggested_Gleeo, txtHF_Suggested_Gleeo, txtCliente_Suggested_Gleeo, txtTrabajo_Suggested_Gleeo;
        LinearLayout DestinationTable= findViewById(R.id.tableDestination);

        View v = LayoutInflater.from(this).inflate(R.layout.control_sugerencia_gleeo, null);


        final LinearLayout layoutDay = (LinearLayout) v;
        // add the line of day to the main linearlayout
        DestinationTable.addView(v);
        int newId = DestinationTable.generateViewId();
        layoutDay.setId(newId);
        // save a reference to "the day" for later
        layout_sugerencia_Gleeo[n_sugerencia] = layoutDay;
        sugerencia_Gleeo_Id[n_sugerencia] = newId;
        n_sugerencia++;
        //Get acces to the inner TextViews
        txtHN_HX = layoutDay.findViewById(R.id.HN_HX_sugerencia_gleeo);
        txtHI_Suggested_Gleeo = layoutDay.findViewById(R.id.HI_sugerencia_gleeo);
        txtHF_Suggested_Gleeo = layoutDay.findViewById(R.id.HF_sugerencia_gleeo);
        txtCliente_Suggested_Gleeo = layoutDay.findViewById(R.id.Cliente_sugerencia_gleeo);
        txtTrabajo_Suggested_Gleeo = layoutDay.findViewById(R.id.Trabajo_sugerencia_gleeo);

        txtHN_HX.setText("N");
        ResizeTextToFit(txtHN_HX,Text_Type.SUGGESTED);
        txtHI_Suggested_Gleeo.setText(pdh.HI_Norm[i]);
        ResizeTextToFit(txtHI_Suggested_Gleeo,Text_Type.SUGGESTED);
        txtHF_Suggested_Gleeo.setText(pdh.HF_Norm[i]);
        ResizeTextToFit(txtHF_Suggested_Gleeo,Text_Type.SUGGESTED);
        txtCliente_Suggested_Gleeo.setText(pdh.Cliente_Norm[i]);
        ResizeTextToFit(txtCliente_Suggested_Gleeo,Text_Type.SUGGESTED);
        txtTrabajo_Suggested_Gleeo.setText(pdh.Observaciones_Norm[i]);
        ResizeTextToFit(txtTrabajo_Suggested_Gleeo,Text_Type.SUGGESTED);
    }
    private void Add_Extra_Line_In_PDH_To_Suggested_Table(ParteDeHoras pdh,int i)
    {
        TextView txtHN_HX,txtHI_Suggested_Gleeo, txtHF_Suggested_Gleeo, txtCliente_Suggested_Gleeo, txtTrabajo_Suggested_Gleeo;
        LinearLayout DestinationTable= findViewById(R.id.tableDestination);

        View v = LayoutInflater.from(this).inflate(R.layout.control_sugerencia_gleeo, null);


        final LinearLayout layoutDay = (LinearLayout) v;
        // add the line of day to the main linearlayout
        DestinationTable.addView(v);
        int newId = DestinationTable.generateViewId();
        layoutDay.setId(newId);
        // save a reference to "the day" for later
        layout_sugerencia_Gleeo[n_sugerencia] = layoutDay;
        sugerencia_Gleeo_Id[n_sugerencia] = newId;
        n_sugerencia++;
        //Get acces to the inner TextViews
        txtHN_HX = layoutDay.findViewById(R.id.HN_HX_sugerencia_gleeo);
        txtHI_Suggested_Gleeo = layoutDay.findViewById(R.id.HI_sugerencia_gleeo);
        txtHF_Suggested_Gleeo = layoutDay.findViewById(R.id.HF_sugerencia_gleeo);
        txtCliente_Suggested_Gleeo = layoutDay.findViewById(R.id.Cliente_sugerencia_gleeo);
        txtTrabajo_Suggested_Gleeo = layoutDay.findViewById(R.id.Trabajo_sugerencia_gleeo);

        txtHN_HX.setText("X");
        ResizeTextToFit(txtHN_HX,Text_Type.SUGGESTED);
        txtHI_Suggested_Gleeo.setText(pdh.HI_Extra[i]);
        ResizeTextToFit(txtHI_Suggested_Gleeo,Text_Type.SUGGESTED);
        txtHF_Suggested_Gleeo.setText(pdh.HF_Extra[i]);
        ResizeTextToFit(txtHF_Suggested_Gleeo,Text_Type.SUGGESTED);
        txtCliente_Suggested_Gleeo.setText(pdh.Cliente_Extra[i]);
        ResizeTextToFit(txtCliente_Suggested_Gleeo,Text_Type.SUGGESTED);
        txtTrabajo_Suggested_Gleeo.setText(pdh.Observaciones_Extra[i]);
        ResizeTextToFit(txtTrabajo_Suggested_Gleeo,Text_Type.SUGGESTED);
    }
    private void ResizeTextToFit(TextView tv,Text_Type tt)
    {
        if (tv==null)return;

        if(((tt==Text_Type.SOURCE)? sourceSize:suggestedSize)!=0)
        {
            tv.setTextSize(COMPLEX_UNIT_PX, (tt==Text_Type.SOURCE)? sourceSize:suggestedSize);
        }
        else
        {
            if(!tv.getText().equals("")) {
                int MinWidth = 5;
                Rect bounds = new Rect();
                int BoxHeight, BoxWidth, BoxHeight2, BoxWidth2, TextWidth;
                float TextSize = tv.getTextSize();
                tv.measure(0, 0);
                BoxHeight = tv.getMeasuredHeight();
                BoxWidth = tv.getMeasuredWidth();
                BoxHeight2 = tv.getHeight();
                BoxWidth2 = tv.getWidth();

                tv.getPaint().getTextBounds(tv.getText().toString(), 0, tv.getText().length(), bounds);
                TextWidth = bounds.right - bounds.left;
                while ((TextWidth > (BoxWidth - 10)) && (TextWidth > MinWidth)) {
                    tv.getPaint().getTextBounds(tv.getText().toString(), 0, tv.getText().length(), bounds);
                    TextWidth = bounds.right - bounds.left;
                    TextSize--;
                    tv.setTextSize(COMPLEX_UNIT_PX, TextSize);
                }
                switch (tt)
                {
                    case SOURCE:
                        if (sourceSize == 0)
                            sourceSize = tv.getTextSize();
                        break;
                    case SUGGESTED:
                        if (suggestedSize == 0)
                            suggestedSize = tv.getTextSize();
                        break;
                }
            }
        }
    }
    public void onClick_Save (View v)
    {
        Save_Suggested_Parte();

        if(EraseCurrentDayInGlobalArray()==false)
        {
            //No hay partes en la lista de sugeridos
        }
        AdjustEnviromentToCurrentParteIndex();
    }
    public void onClick_Discard (View v)
    {
        if(EraseCurrentDayInGlobalArray()==false)
        {
            //No hay partes en la lista de sugeridos
        }
        AdjustEnviromentToCurrentParteIndex();
    }
    public void Save_Suggested_Parte ()
    {
        TextView txtHN_HX,txtHI_Suggested_Gleeo, txtHF_Suggested_Gleeo, txtCliente_Suggested_Gleeo, txtTrabajo_Suggested_Gleeo;

        ParteDeHoras pdh_new=new  ParteDeHoras();
        pdh_new.Fecha=pdh_array[CurrentParte].Fecha;
        pdh_new.Operario=pdh_array[CurrentParte].Operario;
        int n_HI=0,n_HX=0;
        for(int i=0;i<n_sugerencia;i++) {

            //Get acces to the inner TextViews
            txtHN_HX = layout_sugerencia_Gleeo[i].findViewById(R.id.HN_HX_sugerencia_gleeo);
            txtHI_Suggested_Gleeo = layout_sugerencia_Gleeo[i].findViewById(R.id.HI_sugerencia_gleeo);
            txtHF_Suggested_Gleeo = layout_sugerencia_Gleeo[i].findViewById(R.id.HF_sugerencia_gleeo);
            txtCliente_Suggested_Gleeo = layout_sugerencia_Gleeo[i].findViewById(R.id.Cliente_sugerencia_gleeo);
            txtTrabajo_Suggested_Gleeo = layout_sugerencia_Gleeo[i].findViewById(R.id.Trabajo_sugerencia_gleeo);

            if (txtHN_HX.getText().toString().equals("N")) {
                if (n_HI >= ParteDeHoras.Normal_lenght) {
                    Toast.makeText(this, "Too much entries for a single day.",
                            Toast.LENGTH_SHORT).show();
                    i=n_sugerencia;//sale del bucle;
                } else {
                    pdh_new.HI_Norm[n_HI] = txtHI_Suggested_Gleeo.getText().toString();
                    pdh_new.HF_Norm[n_HI] = txtHF_Suggested_Gleeo.getText().toString();
                    pdh_new.Cliente_Norm[n_HI] = txtCliente_Suggested_Gleeo.getText().toString();
                    pdh_new.Observaciones_Norm[n_HI] = txtTrabajo_Suggested_Gleeo.getText().toString();
                }
                n_HI++;
            }
            if (txtHN_HX.getText().toString().equals("X")) {
                if (n_HX >= ParteDeHoras.Extra_lenght) {
                    Toast.makeText(this, "Too much entries for a single day.",
                            Toast.LENGTH_SHORT).show();
                    i=n_sugerencia;//sale del bucle;
                } else {
                    pdh_new.HI_Extra[n_HX] = txtHI_Suggested_Gleeo.getText().toString();
                    pdh_new.HF_Extra[n_HX] = txtHF_Suggested_Gleeo.getText().toString();
                    pdh_new.Cliente_Extra[n_HX] = txtCliente_Suggested_Gleeo.getText().toString();
                    pdh_new.Observaciones_Extra[n_HX] = txtTrabajo_Suggested_Gleeo.getText().toString();
                }
                n_HX++;
            }
        }
        pdh_new.ValidarTotalNormales();
        pdh_new.ValidarTotalExtras();
        FileHandling FH=new FileHandling();
        FH.SaveParteFromClassToFile(getApplication().getBaseContext(), pdh_new);
    }
    //Devuelve false si no hay partes que borrar
    private  boolean EraseCurrentDayInGlobalArray()
    {
        if(pdh_array.length==0)return false;

        comodin=new ParteDeHoras[pdh_array.length-1];

        for(int i=0;i<CurrentParte;i++)
        {
            comodin[i]=pdh_array[i];
        }
        for(int i=CurrentParte;i<comodin.length;i++)
        {
            comodin[i]=pdh_array[i+1];
        }
        pdh_array=comodin;

        CurrentParte--;
        if(CurrentParte<0)CurrentParte=0;
        return true;
    }
}
