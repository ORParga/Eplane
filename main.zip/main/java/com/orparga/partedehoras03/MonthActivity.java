package com.orparga.partedehoras03;

import android.content.Intent;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Calendar;

public class MonthActivity extends AppCompatActivity {

    LinearLayout layout_tabla;
    LinearLayout[] layoutDayArray;
    TextView txtFechaSeleccionada;
    TextView txtDayNumber,txtStartime,txtEndTime,txtClient,txtHorasExtras;
    Calendar selectedMonth;
    int Last_day_in_month;

    int[] DayLineId;
    String[] fileNameDay;
    //Menu contextual
    View gViewLongClicked;
    boolean anySelected=false;
    boolean[] daySelected;

    //Copy parte to clipboard
    FileHandling FH;

    final int N = 31; // total number of DayLines to add
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_month);
        ActionBar Parte_ActionBar = getSupportActionBar();
        Parte_ActionBar.setTitle(R.string.tittle_parte_de_horas);


        //Inicializamos los controles y los arrays
        layout_tabla = (LinearLayout) findViewById(R.id.layout_tabla);
        txtFechaSeleccionada = (TextView) findViewById(R.id.txtFechaSeleccionada);
        layoutDayArray = new LinearLayout[N];
        DayLineId = new int[N];
        fileNameDay = new String[N];
        daySelected=new boolean[N];
        //
        selectedMonth = Calendar.getInstance();
        selectedMonth.set(Calendar.DAY_OF_MONTH,1);
        txtFechaSeleccionada.setText(MiFecha.MonthYearToString(selectedMonth));
        PassingDAta.thereIsAnyDayClicked=false;

        fillMonthTable(selectedMonth);
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v,
                                    ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        MenuInflater inflater =getMenuInflater();
        int i=getLayoutIndex(v);
        if(daySelected[i])
        {
            inflater.inflate(R.menu.context_menu_month_long_click_in_day_selected, menu);
        }
        else {
            inflater.inflate(R.menu.context_menu_month_long_click_in_day, menu);
        }
        gViewLongClicked =  v;
    }

    int getLayoutIndex(View v)
    {

        int i=0;
        LinearLayout layoutDay=(LinearLayout) v.getParent();
        int layoutDayID=layoutDay.getId();
        if(DayLineId==null)return -1;

        //Busca entre todos los ID guardados en el array
        // el que corresponde con el View recibido por esta funcion
        // para saber a que dia del mes pertenece
        do
        {
            if (layoutDayID== DayLineId[i])break;
            i++;
            if (i==DayLineId.length)return -1;         //No se ha encontrado id Relaccionado
        }while (true);

        return i;
    }
    @Override
    public boolean onContextItemSelected(MenuItem item) {
        int i = 0;
        LinearLayout layoutDay = (LinearLayout) gViewLongClicked.getParent();
        int layoutDayID = layoutDay.getId();
        if (DayLineId == null) return true;

        //Busca entre todos los ID guardados en el array
        // el que corresponde con el View recibido por esta funcion
        // para saber a que dia del mes pertenece
        do {
            if (layoutDayID == DayLineId[i]) break;
            i++;
            if (i == DayLineId.length) return true;         //No se ha encontrado id Relaccionado
        } while (true);

        txtStartime = (TextView) layoutDay.findViewById(R.id.startTime);
        txtEndTime = (TextView) layoutDay.findViewById(R.id.EndTime);
        txtClient = (TextView) layoutDay.findViewById(R.id.Client);
        txtHorasExtras = (TextView) layoutDay.findViewById(R.id.TotalHoras);
        txtDayNumber = (TextView) layoutDay.findViewById(R.id.DayNumber);

        switch (item.getItemId()) {
            case R.id.mnu1_Deseleccionar:
                DeselectDay(layoutDay);
                return true;
            case R.id.mnu1_Seleccionar:
                if (thereIsAnyDaySelected()) {
                } else {
                    SelectDay(layoutDay);
                }
                return true;
            case R.id.mnu1_option1:
                gViewLongClicked.performClick();
                return true;
            case R.id.mnu1_option2:
                if (FileHandling.exist(fileNameDay[i], this)) {
                    Log.d("MonthActivity", fileNameDay[i] + " exists");
                    FileHandling.EraseFile(fileNameDay[i], this);
                    txtStartime.setText("");
                    txtEndTime.setText("");
                    txtClient.setText("");
                    txtHorasExtras.setText("");
                }
                return true;
            case R.id.mnu1_option3:

                PassingDAta.fileNameSelected = fileNameDay[i];
                PassingDAta.SelectedDayOfMonth = i;
                PassingDAta.thereIsAnyDayClicked= true;
                //lo que sigue es Por redundancia y eso.
                //en realidad no lo usa, al menos de momento, pero si el usuario ha selecionado
                //un dia, es interesante que el día esté registrado en el array de dias seleccionados

                PassingDAta.FileNameArray[0]=fileNameDay[i];
                PassingDAta.NDaysSelected=1;
                    //PassingDAta.SendParteToClipboard();

                ParteDeHoras pdh=new ParteDeHoras();
                FH.LoadParteFromFileToClass(PassingDAta.fileNameSelected,this,pdh);
                pdh.Fecha=FileHandling.getDatefromFileName(PassingDAta.fileNameSelected);
                PassingDAta.SendParteToClipboard(pdh);
                    Toast.makeText(this,"Enviando "+fileNameDay[i]+" al portapapeles.",Toast.LENGTH_LONG).show();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
    public void fillMonthTable (Calendar MonthToShow)
    {
        int newId;
        SummaryDay summaryDay = new SummaryDay();
        //Calcuar cuantos dias tiene el mes
        Calendar cal_comodin = (Calendar) MonthToShow.clone();
        cal_comodin.set(Calendar.DAY_OF_MONTH, 32);
        Last_day_in_month = cal_comodin.get(Calendar.DAY_OF_MONTH);
        Last_day_in_month = 31 - Last_day_in_month + 1;

        cal_comodin =(Calendar) MonthToShow.clone();
        layout_tabla.removeAllViews();
        for (int i = 0; i < Last_day_in_month; i++) {
            // create a new linearLayout

            View v = LayoutInflater.from(this).inflate(R.layout.control_dia_resumen, null);


            final LinearLayout layoutDay = (LinearLayout) v;
            // add the line of day to the main linearlayout
            layout_tabla.addView(v);
            newId=layout_tabla.generateViewId();
            layoutDay.setId(newId);
            // save a reference to "the day" for later
            layoutDayArray[i] = layoutDay;
            DayLineId[i]=newId;
            //Get acces to the inner TextViews
            txtDayNumber=(TextView)layoutDay.findViewById(R.id.DayNumber);
            txtDayNumber.setText(""+(i+1));
            txtStartime=(TextView)layoutDay.findViewById(R.id.startTime);
            txtEndTime=(TextView)layoutDay.findViewById(R.id.EndTime);
            txtClient=(TextView)layoutDay.findViewById(R.id.Client);
            txtHorasExtras=(TextView)layoutDay.findViewById(R.id.TotalHoras);
            registerForContextMenu(txtDayNumber);
            registerForContextMenu(txtStartime);
            registerForContextMenu(txtEndTime);
            registerForContextMenu(txtClient);
            registerForContextMenu(txtHorasExtras);
            cal_comodin.set(Calendar.DAY_OF_MONTH,i+1);
            //Date dat=cal.getTime();
            fileNameDay[i]=FileHandling.getFileName(cal_comodin);
            daySelected[i]=false;

            if(FileHandling.exist(fileNameDay[i],this))
            {
                Log.d("MonthActivity",fileNameDay[i]+" exists");
                summaryDay.LoadSummaryDayFromFile(fileNameDay[i],this);
                txtStartime.setText(summaryDay.HI);
                txtEndTime.setText(summaryDay.HF);
                txtClient.setText(summaryDay.Observaciones);
                txtHorasExtras.setText(summaryDay.TotalHoras);

            }
            else
            {
                Log.d("MonthActivity",fileNameDay[i]+" doesn't exist");

                txtClient.setText("");
            }
        }
        int i=0;

    }

    public void onClickDay (View v) {
        int i = 0;
        LinearLayout layoutDay = (LinearLayout) v.getParent();
        int layoutDayID = layoutDay.getId();
        if (DayLineId == null) return;
        if (fileNameDay == null) return;


        //Busca entre todos los ID guardados en el array
        // el que corresponde con el View recibido por esta funcion
        // para saber a que dia del mes pertenece
        do {
            if (layoutDayID == DayLineId[i]) break;
            i++;
            if (i == DayLineId.length) return;         //No se ha encontrado id Relaccionado
        } while (true);

        //Conociendo la posicion en el Array del View recibido por esta funcion
        //se puede conocer toda la informacion necesaria: Dia, mes, nombre de archivo, etc...
        PassingDAta.SelectedYear = selectedMonth.get(Calendar.YEAR);
        PassingDAta.SelectedMonth = selectedMonth.get(Calendar.MONTH);

        //Si no hay ningún día seleccionado el onClick significa que el
        //usuario quiere ir al dia clickado
        //Si ya hay un día seleccionado y el usuario pincha en otro día
        //significa que el usuario quiere seleccionar algun día más
        //Si el día está seleccionado, significa que el usuario quiere
        //deseleccionarlo
        if(daySelected[i])
        {
            DeselectDay(layoutDay);
        }
        else {
            if (thereIsAnyDaySelected()) {
                SelectDay(layoutDay);
            } else {
                PassingDAta.fileNameSelected = fileNameDay[i];
                PassingDAta.SelectedDayOfMonth = i;
                PassingDAta.thereIsAnyDayClicked= true;
                //lo que sigue es Por redundancia y eso.
                //en realidad no lo usa, al menos de momento, pero si el usuario ha selecionado
                //un dia, es interesante que el día esté registrado en el array de dias seleccionados

                PassingDAta.FileNameArray[0]=fileNameDay[i];
                PassingDAta.NDaysSelected=1;

                //Dicho esto, se vuelve a la activity principal para mostrar el dia clickado
                finish();
            }
        }
    }
    public boolean thereIsAnyDaySelected ()
    {
        for (int i=0;i<Last_day_in_month;i++)
        {
            if(daySelected[i]) return (anySelected=true);
        }
        return (anySelected=false);
    }
    public void SelectDay (LinearLayout layoutDay)
    {
        int i=0;
        int layoutDayID=layoutDay.getId();

        //Busca entre todos los ID guardados en el array
        // el que corresponde con el View recibido por esta funcion
        // para saber a que dia del mes pertenece
        do
        {
            if (layoutDayID== DayLineId[i])break;
            i++;
            if (i==DayLineId.length)return;         //No se ha encontrado id Relaccionado
        }while (true);

        // Actualiza las variables para marcar el Layout como "seleccionado"
        daySelected[i]=true;
        anySelected=true;

        // Establece el background del dia en el color "colorDaySelected"
        txtStartime=(TextView)layoutDay.findViewById(R.id.startTime);
        txtEndTime=(TextView)layoutDay.findViewById(R.id.EndTime);
        txtClient=(TextView)layoutDay.findViewById(R.id.Client);
        txtHorasExtras=(TextView)layoutDay.findViewById(R.id.TotalHoras);
        txtDayNumber=(TextView)layoutDay.findViewById(R.id.DayNumber);

        txtDayNumber.setBackgroundColor(getResources().getColor(R.color.colorDaySelected));
        txtStartime.setBackgroundColor(getResources().getColor(R.color.colorDaySelected));
        txtEndTime.setBackgroundColor(getResources().getColor(R.color.colorDaySelected));
        txtClient.setBackgroundColor(getResources().getColor(R.color.colorDaySelected));
        txtHorasExtras.setBackgroundColor(getResources().getColor(R.color.colorDaySelected));

        // Actualiza los iconos para adecuarse a la seleccion

        ImageButton shareButton= findViewById(R.id.month_share);
        shareButton.setImageResource(R.mipmap.ic_share);
    }
    public void DeselectDay (LinearLayout layoutDay)
    {
        int i=0;
        int layoutDayID=layoutDay.getId();

        //Busca entre todos los ID guardados en el array
        // el que corresponde con el View recibido por esta funcion
        // para saber a que dia del mes pertenece
        do
        {
            if (layoutDayID== DayLineId[i])break;
            i++;
            if (i==DayLineId.length)return;         //No se ha encontrado id Relaccionado
        }while (true);

        // Actualiza las variables para marcar el Layout como "seleccionado"
        daySelected[i]=false;
        if(!thereIsAnyDaySelected()) {
            // Actualiza los iconos para adecuarse a la seleccion
            ImageButton shareButton = findViewById(R.id.month_share);
            shareButton.setImageResource(R.mipmap.ic_share_disabled);
        }

        // Establece el background del dia en el color "colorDaySelected"
        txtStartime=(TextView)layoutDay.findViewById(R.id.startTime);
        txtEndTime=(TextView)layoutDay.findViewById(R.id.EndTime);
        txtClient=(TextView)layoutDay.findViewById(R.id.Client);
        txtHorasExtras=(TextView)layoutDay.findViewById(R.id.TotalHoras);
        txtDayNumber=(TextView)layoutDay.findViewById(R.id.DayNumber);

        txtDayNumber.setBackgroundColor(getResources().getColor(R.color.colorBackcolor));
        txtStartime.setBackgroundColor(getResources().getColor(R.color.colorBackcolor));
        txtEndTime.setBackgroundColor(getResources().getColor(R.color.colorBackcolor));
        txtClient.setBackgroundColor(getResources().getColor(R.color.colorBackcolor));
        txtHorasExtras.setBackgroundColor(getResources().getColor(R.color.colorBackcolor));

        }
    public void onNext (View v)
    {
        selectedMonth.set(Calendar.MONTH,selectedMonth.get(Calendar.MONTH)+1);
        txtFechaSeleccionada.setText(MiFecha.MonthYearToString(selectedMonth));
        fillMonthTable(selectedMonth);
        layout_tabla.invalidate();
    }
    public void onPrev (View v)
    {
        selectedMonth.set(Calendar.MONTH,selectedMonth.get(Calendar.MONTH)-1);
        txtFechaSeleccionada.setText(MiFecha.MonthYearToString(selectedMonth));
        fillMonthTable(selectedMonth);
        layout_tabla.invalidate();

    }
    public void onShare (View v)
    {
        int i,j=0;
        ParteDeHoras pdh=new ParteDeHoras();

        //Busca todos los parte seleccionado
        anySelected=false;
        for (i=0;i<Last_day_in_month;i++)
        {
            if(daySelected[i])
            {
                anySelected=true;
                PassingDAta.FileNameArray[j]=fileNameDay[i];
                PassingDAta.fileNameSelected=fileNameDay[i];
                PassingDAta.SelectedDayOfMonth=i;
                j++;
            }
        }
        if(!anySelected)return;
        //Carga el parte seleccionado en la clase de
        // intercambio de datos entre acividades "PassingDAta"
        PassingDAta.SelectedYear=selectedMonth.get(Calendar.YEAR);
        PassingDAta.SelectedMonth=selectedMonth.get(Calendar.MONTH);
        PassingDAta.NDaysSelected=j;

        Intent intent = new Intent(this, ShareActivity.class);

        startActivity(intent);
        //Testing the posibilite to draw a View in memory (without showing it to the user)
//        LinearLayout linearLayout=new LinearLayout(this);
//        for(i=0;i<Last_day_in_month;i++)
//        {
//            if(daySelected[i])
//            {
//                ParteShare.CreateViewFromPDH(pdh,linearLayout);
//                ParteShare.ShareScreenShot(this,linearLayout);
//            }
//        }
    }
}
