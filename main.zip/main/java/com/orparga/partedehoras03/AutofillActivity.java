package com.orparga.partedehoras03;

import android.app.TimePickerDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.TimePicker;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.TimeZone;

public class AutofillActivity extends AppCompatActivity {

    TimePickerDialog.OnTimeSetListener timeListener;
    TimePickerDialog timePicker;
    Calendar cal_TimeSelected;
    SimpleDateFormat sdf,sdf_date;
    TextView txt_inicio;
    TextView txt_salida;
    TextView txt_cliente;
    TextView txt_tareas;
    TextView txt_Clicked;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_autofill);

        //Previene el caso en el que la actividad regrese a la actividad principal
        //por un metodo alternativo a pulsat "OK". Como pulsar Cancel o el backbutton

        PassingDAta.fill_ok_pressed=false;
        //Inicializar las variables para la activity
        sdf = new SimpleDateFormat("HH:mm");
        sdf.setTimeZone(TimeZone.getTimeZone("GMT +0"));
        sdf_date = new SimpleDateFormat("dd/MM/yy");
        sdf_date.setTimeZone(TimeZone.getTimeZone("GMT +0"));

        txt_inicio=(TextView)findViewById(R.id.fill_inicio);
        txt_salida=(TextView)findViewById(R.id.fill_salida);
        txt_cliente=(TextView)findViewById(R.id.fill_cliente);
        txt_tareas=(TextView)findViewById(R.id.fill_tareas);

        cal_TimeSelected=Calendar.getInstance();


        timeListener = new TimePickerDialog.OnTimeSetListener() {
            @Override
            public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                cal_TimeSelected.clear();
                cal_TimeSelected.setTimeZone(TimeZone.getTimeZone("GMT"));
                cal_TimeSelected.set(Calendar.HOUR_OF_DAY, hourOfDay);
                cal_TimeSelected.set(Calendar.MINUTE, minute);
                txt_Clicked.setText(sdf.format(cal_TimeSelected.getTime()));
            }
        };

        //Preparar la UI
            txt_inicio.setText(PassingDAta.cnf_HI_jornada);
            txt_salida.setText(PassingDAta.cnf_HF_jornada);
            txt_cliente.setText(PassingDAta.cnf_cliente_usual);
            txt_tareas.setText(PassingDAta.cnf_tarea_usual);
    }

    public void onClick_Cancel (View v)
    {
        PassingDAta.fill_ok_pressed=false;
        finish();
    }
    public void onClick_OK (View v)
    {
        SaveDAta();
        PassingDAta.fill_ok_pressed=true;
        finish();
    }

    public void SaveDAta ()
    {

        PassingDAta.fill_hora_inicio=txt_inicio.getText().toString();
        PassingDAta.fill_hora_salida=txt_salida.getText().toString();
        PassingDAta.fill_cliente=txt_cliente.getText().toString();
        PassingDAta.fill_tareas=txt_tareas.getText().toString();
    }


    public void onClickHoraInicio(View v) {
        txt_Clicked=txt_inicio;
        timePicker=new TimePickerDialog(this, timeListener, 0,0, true);
        timePicker.show();

    }
    public void onClickHoraSalida(View v) {

        txt_Clicked=txt_salida;
        timePicker=new TimePickerDialog(this, timeListener, 0,0, true);
        timePicker.show();
    }

}
