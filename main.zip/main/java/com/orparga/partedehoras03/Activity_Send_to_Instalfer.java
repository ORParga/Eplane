package com.orparga.partedehoras03;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.AppCompatButton;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.DatePicker;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TableLayout;
import android.widget.TableRow;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class Activity_Send_to_Instalfer extends AppCompatActivity {
    private static final String CERO = "0";
    private static final String BARRA = "/";//Calendario para obtener fecha & hora
    public final Calendar c = Calendar.getInstance();

    //Variables para obtener la fecha
    final int mes = c.get(Calendar.MONTH);
    final int dia = c.get(Calendar.DAY_OF_MONTH);
    final int anio = c.get(Calendar.YEAR);

    //VCariables para obtener el dia de hoy
    Calendar endCalendar,beginingCalendar;
    Date BeginingTime,endTime;
    SimpleDateFormat sdf_dayOfYear,sdf_dayOfWeek;
    Locale spanish = new Locale("es", "ES");
    String today,today_week;
    String strBegining,strBeginning_week;
    String strEnd,strEnd_week;
    //Widgets
     AppCompatButton btnBegining;
     AppCompatButton btnEnd;
    TableLayout table;
    @Override
    protected void onCreate( Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        PassingDAta.fromActivity= PassingDAta.fromActivityEnum.Send_to_Instalfer;
        setContentView(R.layout.activity_send_to_instalfer);

         btnBegining=findViewById(R.id.activity_send_instalfer_btn_begining);
         btnEnd=findViewById(R.id.activity_send_instalfer_btn_end);

        table = (TableLayout) findViewById(R.id.send_to_instalfer_table);

        beginingCalendar = Calendar.getInstance();
        BeginingTime= beginingCalendar.getTime();

        endCalendar = Calendar.getInstance();
        endTime= endCalendar.getTime();

        sdf_dayOfWeek =new SimpleDateFormat("EEEE",spanish);
        sdf_dayOfYear=new SimpleDateFormat("dd/MMMM/yy",spanish);
        today=sdf_dayOfYear.format(BeginingTime);
        today_week = sdf_dayOfWeek.format(BeginingTime);
        btnBegining.setText(today_week+"\n"+today);
        btnEnd.setText(today_week+"\n"+today);

        fillTable();
    }
    public void onClick_Inicio(View v){obtenerFecha(btnBegining);}
    public void onClick_Fin(View v){obtenerFecha(btnEnd);}
    private void obtenerFecha(final AppCompatButton btn){
        DatePickerDialog recogerFecha = new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {

                //Esta variable lo que realiza es aumentar en uno el mes ya que comienza desde 0 = enero
                final int mesActual = month + 1;
                //Formateo el día obtenido: antepone el 0 si son menores de 10
                String diaFormateado = (dayOfMonth < 10)? CERO + String.valueOf(dayOfMonth):String.valueOf(dayOfMonth);
                //Formateo el mes obtenido: antepone el 0 si son menores de 10
                String mesFormateado = (mesActual < 10)? CERO + String.valueOf(mesActual):String.valueOf(mesActual);
                //Muestro la fecha con el formato deseado
                if(btn==btnBegining){
                    beginingCalendar.set(Calendar.DAY_OF_MONTH,dayOfMonth);
                    beginingCalendar.set(Calendar.MONTH,month);
                    beginingCalendar.set(Calendar.YEAR,year);
                }
                if(btn==btnEnd){
                    endCalendar.set(Calendar.DAY_OF_MONTH,dayOfMonth);
                    endCalendar.set(Calendar.MONTH,month);
                    endCalendar.set(Calendar.YEAR,year);
                }
                UpdateButtons();
                fillTable();


            }
            //Estos valores deben ir en ese orden, de lo contrario no mostrara la fecha actual
            /**
             *También puede cargar los valores que usted desee
             */
        },anio, mes, dia);
        //Muestro el widget
        recogerFecha.show();

    }
    private void UpdateButtons(){

        BeginingTime= beginingCalendar.getTime();
        endTime= endCalendar.getTime();

        sdf_dayOfYear=new SimpleDateFormat("dd/MMMM/yy",spanish);
        sdf_dayOfWeek =new SimpleDateFormat("EEEE",spanish);

         strBegining=sdf_dayOfYear.format(BeginingTime);
         strBeginning_week=sdf_dayOfWeek.format(BeginingTime);
         strEnd=sdf_dayOfYear.format(endTime);
         strEnd_week=sdf_dayOfWeek.format(endTime);

        btnBegining.setText(strBeginning_week+"\n"+strBegining);
        btnEnd.setText(strEnd_week+"\n"+strEnd);
    }
    private void fillTable(){
        View vTableCeld=null;
        table.removeAllViews();
        TableRow tittleTableRow = new TableRow(this);
        for (int i = 0; i < 10; i++) {

            View vTableRow = LayoutInflater.from(this).inflate(R.layout.control_send_to_instalfer_fila, null);


            final TableRow tableRow = (TableRow) vTableRow;
            for(int celdNumber=0; celdNumber<10;celdNumber++) {
                 vTableCeld = LayoutInflater.from(this).inflate(R.layout.control_send_to_instalfer_celda, null);
                tableRow.addView(vTableCeld);
            }
            // add the line of day to the main linearlayout
            table.addView(vTableRow);
        }
    }
}
