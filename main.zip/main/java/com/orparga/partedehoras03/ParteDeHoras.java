package com.orparga.partedehoras03;

import android.content.Context;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;

/**
 * Created by OSCAR on 01/04/2018.
 */
public class ParteDeHoras {

    public static final int Extra_lenght = 2;
    public static final int Normal_lenght = 8;

    //fields para facilitar el trabajo con el archivo Json (instalfer_parte_atributes.json)
    public String[] fieldName;
    public int[] fieldIndex;
    public String[][] fieldPointer;

    public String[] HI_Extra;
    public String[] HF_Extra;
    public String[] Cliente_Extra;
    public String[] Observaciones_Extra;

    public String Total_Extra;

    public String NumeroParte;
    public String Fecha;

    public String Operario;

    public String[] HI_Norm;
    public String[] HF_Norm;
    public String[] Cliente_Norm;
    public String[] Observaciones_Norm;

    public String Total_Normales;


    public ParteDeHoras(){
        //8 lineas
        HI_Extra=new String[Extra_lenght];
        HF_Extra=new String[Extra_lenght];
        Cliente_Extra=new String[Extra_lenght];
        Observaciones_Extra=new String[Extra_lenght];

        //4 lineas
        Total_Extra="";
        NumeroParte="";
        Fecha ="";
        Operario="";

        //32 lineas
        HI_Norm=new String[Normal_lenght];
        HF_Norm=new String[Normal_lenght];
        Cliente_Norm=new String[Normal_lenght];
        Observaciones_Norm=new String[Normal_lenght];

        //1 linea
        Total_Normales="";

        //total= 45 lineas

        IniFields();
    };
    private void IniFields ()
    {
        fieldName=new String[13];
        fieldIndex=new int[13];
        fieldPointer=new String[13][8];

        fieldName[0]="HI_EXTRA";
        fieldName[1]="HF_EXTRA";
        fieldName[2]="CLIENTE_EXTRA";
        fieldName[3]="TRABAJO_EXTRA";
        fieldName[4]="TOTAL_EXTRA";
        fieldName[5]="NUMERO_PARTE";
        fieldName[6]="FECHA";
        fieldName[7]="OPERARIO";
        fieldName[8]="HI_NORMAL";
        fieldName[9]="HF_NORMAL";
        fieldName[10]="CLIENTE_NORMAL";
        fieldName[11]="TRABAJO_NORMAL";
        fieldName[12]="TOTAL_NORMAL";

        fieldIndex[0]=Extra_lenght;
        fieldIndex[1]=Extra_lenght;
        fieldIndex[2]=Extra_lenght;
        fieldIndex[3]=Extra_lenght;
        fieldIndex[4]=1;
        fieldIndex[5]=1;
        fieldIndex[6]=1;
        fieldIndex[7]=1;
        fieldIndex[8]=Normal_lenght;
        fieldIndex[9]=Normal_lenght;
        fieldIndex[10]=Normal_lenght;
        fieldIndex[11]=Normal_lenght;
        fieldIndex[12]=1;

        LoadFields();

    }
    public void LoadFields ()
    {

        for(int i=0;i<Extra_lenght;i++)
        {
            fieldPointer[0][i]=HI_Extra[i];
            fieldPointer[1][i]=HF_Extra[i];
            fieldPointer[2][i]=Cliente_Extra[i];
            fieldPointer[3][i]=Observaciones_Extra[i];
        }

        fieldPointer[4][0]=Total_Extra;
        fieldPointer[5][0]=NumeroParte;
        fieldPointer[6][0]=Fecha;
        fieldPointer[7][0]=Operario;

        for(int i=0;i<Normal_lenght;i++)
        {
            fieldPointer[8][i]=HI_Norm[i];
            fieldPointer[9][i]=HF_Norm[i];
            fieldPointer[10][i]=Cliente_Norm[i];
            fieldPointer[11][i]=Observaciones_Norm[i];
        }

        fieldPointer[12][0]=Total_Normales;
    }
    public String GetFieldContent (String fieldName,int index)
    {
        String returnValue="";

        for(int i=0;i<this.fieldName.length;i++)
        {
            if(fieldName.equals(this.fieldName[i]))
            {
                if(index<fieldIndex[i])
                {
                    return fieldPointer[i][index];
                }
            }
        }

        return returnValue;
    }
    public static ParteDeHoras CopyParte (ParteDeHoras Origin,ParteDeHoras Destination)
    {
        int i;

        if ((Origin==null)||(Destination==null)) return null;

        Destination.Fecha=Origin.Fecha;
        Destination.Operario=Origin.Operario;
        Destination.NumeroParte=Origin.NumeroParte;
        Destination.Total_Normales=Origin.Total_Normales;
        Destination.Total_Extra=Origin.Total_Extra;


        if(Origin.HI_Extra==null)Destination.HI_Extra=null;
        else
        {
            Destination.HI_Extra=new String[Origin.HI_Extra.length];
            for (i=0;i<Origin.HI_Extra.length;i++)Destination.HI_Extra[i]=Origin.HI_Extra[i];
        }
        if(Origin.HF_Extra==null)Destination.HF_Extra=null;
        else
        {
            Destination.HF_Extra=new String[Origin.HF_Extra.length];
            for (i=0;i<Origin.HF_Extra.length;i++)Destination.HF_Extra[i]=Origin.HF_Extra[i];
        }
        if(Origin.Cliente_Extra==null)Destination.Cliente_Extra=null;
        else
        {
            Destination.Cliente_Extra=new String[Origin.Cliente_Extra.length];
            for (i=0;i<Origin.Cliente_Extra.length;i++)Destination.Cliente_Extra[i]=Origin.Cliente_Extra[i];
        }
        if(Origin.Observaciones_Extra==null)Destination.Observaciones_Extra=null;
        else
        {
            Destination.Observaciones_Extra=new String[Origin.Observaciones_Extra.length];
            for (i=0;i<Origin.Observaciones_Extra.length;i++)Destination.Observaciones_Extra[i]=Origin.Observaciones_Extra[i];
        }

        if(Origin.HI_Norm==null)Destination.HI_Norm=null;
        else
        {
            Destination.HI_Norm=new String[Origin.HI_Norm.length];
            for (i=0;i<Origin.HI_Norm.length;i++)Destination.HI_Norm[i]=Origin.HI_Norm[i];
        }
        if(Origin.HF_Norm==null)Destination.HF_Norm=null;
        else
        {
            Destination.HF_Norm=new String[Origin.HF_Norm.length];
            for (i=0;i<Origin.HF_Norm.length;i++)Destination.HF_Norm[i]=Origin.HF_Norm[i];
        }
        if(Origin.Cliente_Norm==null)Destination.Cliente_Norm=null;
        else
        {
            Destination.Cliente_Norm=new String[Origin.Cliente_Norm.length];
            for (i=0;i<Origin.Cliente_Norm.length;i++)Destination.Cliente_Norm[i]=Origin.Cliente_Norm[i];
        }
        if(Origin.Observaciones_Norm==null)Destination.Observaciones_Norm=null;
        else
        {
            Destination.Observaciones_Norm=new String[Origin.Observaciones_Norm.length];
            for (i=0;i<Origin.Observaciones_Norm.length;i++)Destination.Observaciones_Norm[i]=Origin.Observaciones_Norm[i];
        }

        return Destination;
    }
    public void Clear()
    {
        for(int i=0;i<2;i++)
        {
            HI_Extra[i]="";
            HF_Extra[i]="";
            Cliente_Extra[i]="";
            Observaciones_Extra[i]="";
        }

        Total_Extra="";
        NumeroParte="";
        Fecha="";
        Operario="";

        for(int i=0;i<8;i++)
        {
            HI_Norm[i]="";
            HF_Norm[i]="";
            Cliente_Norm[i]="";
            Observaciones_Norm[i]="";

        }
        Total_Normales="";


    }
    public boolean NothingToSave()
    {
        if(Total_Extra!="")return false;
        //if(NumeroParte!="")return false;
        //if(Fecha!="")return false;
        if((!Operario.equals(""))&&(!Operario.equals(PassingDAta.cnf_Nombre_operario)))return false;
        if(Total_Normales!="")return false;

        if(HI_Extra!=null)
        {
            for(int i=0;i<HI_Extra.length;i++)
            {
                if(!HI_Extra[i].equals(""))return false;
                if(!HF_Extra[i].equals(""))return false;
                if(!Cliente_Extra[i].equals(""))return false;
                if(!Observaciones_Extra[i].equals(""))return false;
            }
        }
        if(HI_Norm!=null)
        {
            for(int i=0;i<HI_Norm.length;i++)
            {
                if(!HI_Norm[i].equals(""))return false;
                if(!HF_Norm[i].equals(""))return false;
                if(!Cliente_Norm[i].equals(""))return false;
                if(!Observaciones_Norm[i].equals(""))return false;
            }

        }
        return true;
    }
    public boolean SaveToFile(OutputStreamWriter file)
    {
        String LinesInFile="";


        if(file==null)return false;

        try {

            for( int i=0;i<ParteDeHoras.Extra_lenght;i++) {
                LinesInFile += CreateLineForFile("HI_Extra", i, HI_Extra[i]);
                LinesInFile += CreateLineForFile("HF_Extra", i, HF_Extra[i]);
                LinesInFile += CreateLineForFile("Cliente_Extra", i, Cliente_Extra[i]);
                LinesInFile += CreateLineForFile("Observaciones_Extra", i, Observaciones_Extra[i]);
            }
            file.write(LinesInFile);

            LinesInFile = CreateLineForFile("Total_Extra", 0, Total_Extra);
            LinesInFile += CreateLineForFile("Total_Normales", 0, Total_Extra);
            LinesInFile += CreateLineForFile("NumeroParte", 0, NumeroParte);
            LinesInFile += CreateLineForFile("Fecha", 0, Fecha);
            LinesInFile += CreateLineForFile("Operario", 0, Operario);
            file.write(LinesInFile);

            LinesInFile="";
            for( int i=0;i<ParteDeHoras.Normal_lenght;i++) {
                LinesInFile += CreateLineForFile("HI_Norm", i, HI_Norm[i]);
                LinesInFile += CreateLineForFile("HF_Norm", i, HF_Norm[i]);
                LinesInFile += CreateLineForFile("Cliente_Norm", i, Cliente_Norm[i]);
                LinesInFile += CreateLineForFile("Observaciones_Norm", i, Observaciones_Norm[i]);
            }
            file.write(LinesInFile);
        }
        catch (FileNotFoundException e)
        {
            e.printStackTrace();
            return false;
        }
        catch (IOException e)
        {
            e.printStackTrace();
            return false;
        }
        return true;
    }
    ///Devuelve un String con el Ttulo el inidice y el valor especificado, separado por comas
    //y con un simbilo "\n" al final
    public boolean LoadFromFile(String FileName, Context context)
    {
        boolean returnValue=false;
        int ExceptionCase=0;
        int fileLenght;
        byte[] buffer;
        String[] LinesInFile;
        FileInputStream file=null;
        //Testing File
        //      File path = context.getFilesDir();
        //      File file2 = new File(path, FileName);
        //      int length = (int) file2.length();

        //      byte[] bytes = new byte[length];

        //Se inicializa el array con el numero máximo de lineas que puede tener
        //un archivo de Parte de Horas
        LinesInFile=new String[45];
        try {
            //Abrimos el archivo
            file = context.openFileInput(FileName);
            //Asociamos un objeto BufferedReader, que permite leer un archivo de
            //texto linea por linea
            BufferedReader br = new BufferedReader(new InputStreamReader(file));
            //Limpiamos el objeto pdh (Parte De Horas) donde guardaremos los datos del
            //archivo
            this.Clear();
            //Leemos todas las lineas una a una y las interpretamos con
            //el metodo "decodeString"
            for (int i = 0; i < LinesInFile.length; ++i) {
                LinesInFile[i] = br.readLine();
                if(LinesInFile[i]==null)break;//Se ha alcanzado el final del archivo
                decodeStringFromFileToClass(LinesInFile[i],this);
            }
            //Si ha salido correctamente, el valor devuelto será true
            returnValue=true;
            if(file!=null) file.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            returnValue = false;
            ExceptionCase=1;
        } catch (IOException e) {
            e.printStackTrace();
            returnValue =  false;
            ExceptionCase=2;
        }
        if((ExceptionCase==1)||(ExceptionCase==2))
        {
            //Posibilidad de manejat los errores individualmente en el futuro
        }

        //Comprueva si el Total de Horas está en blanco y puede ser calculado
        if(this.Total_Normales=="") ValidarTotalNormales();
        //Comprueva si el Total de Extras está en blanco y puede ser calculado
        if(this.Total_Extra=="") ValidarTotalExtras();
        //Comprueva Si hay zonas en blanco que se puedan rellenar con valores por defecto
        if(this.Operario=="")this.Operario=PassingDAta.cnf_Nombre_operario;
        return returnValue;
    }

    static public boolean decodeStringFromFileToClass (String line, ParteDeHoras l_pdh)
    {
        String lineArray[];

        if(l_pdh==null)return false;
        if(line==null)return false;
        lineArray=line.split(",");
        if(lineArray.length<3)return true;
        switch (lineArray[0])
        {
            case "HI_Extra":
                l_pdh.HI_Extra[Integer.parseInt(lineArray[1])]=lineArray[2];
                break;
            case "HF_Extra":
                l_pdh.HF_Extra[Integer.parseInt(lineArray[1])]=lineArray[2];
                break;
            case "Cliente_Extra":
                l_pdh.Cliente_Extra[Integer.parseInt(lineArray[1])]=lineArray[2];
                break;
            case "Observaciones_Extra":
                l_pdh.Observaciones_Extra[Integer.parseInt(lineArray[1])]=lineArray[2];
                break;
            case "Total_Extra":
                l_pdh.Total_Extra=lineArray[2];
                break;
            case  "NumeroParte":
                l_pdh.NumeroParte=lineArray[2];
                break;
            case "Fecha":
                l_pdh.Fecha=lineArray[2];
                break;
            case "Operario":
                l_pdh.Operario=lineArray[2];
                break;
            case "HI_Norm":
                l_pdh.HI_Norm[Integer.parseInt(lineArray[1])]=lineArray[2];
                break;
            case "HF_Norm":
                l_pdh.HF_Norm[Integer.parseInt(lineArray[1])]=lineArray[2];
                break;
            case "Cliente_Norm":
                l_pdh.Cliente_Norm[Integer.parseInt(lineArray[1])]=lineArray[2];
                break;
            case "Observaciones_Norm":
                l_pdh.Observaciones_Norm[Integer.parseInt(lineArray[1])]=lineArray[2];
                break;
            case "Total_Normales":
                l_pdh.Total_Normales=lineArray[2];
                break;
            default:
                return false;
        }

        return true;
    }
    protected String CreateLineForFile(String Tittle, int index, String value)
    {
        if (value==null)return "";
        if(value.equals("")||value.equals(" "))
            return"";
        return Tittle+","+index+","+value+"\n";
    }
    public static String GetStringFromMillisHour (long HourInMilis)
    {
        SimpleDateFormat l_sdf;
        Date hora;

        //Conversor de string a milliseconds
        l_sdf= new SimpleDateFormat("HH:mm");
        l_sdf.setTimeZone(TimeZone.getTimeZone( "GMT +0"));

        hora=new Date();
        hora.setTime(HourInMilis);

        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(HourInMilis);
        return l_sdf.format(calendar.getTime());
    }
    public static long GetMillisFromStringHour (String l_hour)
    {
        //Declaraciones de variables
        long f;
        SimpleDateFormat l_sdf;
        Date l_Date_HF;
        Calendar l_cl_HF= Calendar.getInstance();

        if(l_hour==null)return -1;
        if(l_hour.equals(""))return -1;

        //Conversor de string a milliseconds
        l_sdf= new SimpleDateFormat("HH:mm");
        l_sdf.setTimeZone(TimeZone.getTimeZone( "GMT +0"));

        //Como SimpleDateFormat funciona con la clase Date
        //hay que hacer la conversion de String a Date
        try {
            l_Date_HF=l_sdf.parse(l_hour);
        }
        catch (ParseException e) {
            e.printStackTrace();
            return 0;
        }

        //para pasar a miliseconds... usamos la clase Calendar
        l_cl_HF.setTime(l_Date_HF);
        f=l_cl_HF.getTimeInMillis();
        return f;
    }
    public static long GetMillisFrom_IntervaloEntreHoras(String Hora_Inicio,String Hora_Final)
    {
        if((Hora_Inicio==null)||(Hora_Final==null))return 0;
        long Inicio= GetMillisFromStringHour(Hora_Inicio);
        long Final =GetMillisFromStringHour(Hora_Final);

        if((Inicio==-1)||(Final==-1)) return 0;

        return Final-Inicio;
    }
    static long GetTotalMillisInParte (Entrada[] entradaArray,int NEntradasEnArray)
    {
        long returnValue=0;


        if(entradaArray==null)return 0;
        if(NEntradasEnArray>entradaArray.length)return 0;
        for(int i=0;i<NEntradasEnArray;i++)
        {
            returnValue+=GetMillisFrom_IntervaloEntreHoras(entradaArray[i].HI,entradaArray[i].HF);
        }

        return returnValue;
    }
    static long GetTotalMillisInParte (ParteDeHoras local_pdh)
    {
        long return_value=0;

        if(local_pdh==null)return 0;

        if(local_pdh.HI_Norm!=null) {
            if (local_pdh.HF_Norm != null) {

                for (int i = 0; (i < local_pdh.HI_Norm.length) || (i < local_pdh.HF_Norm.length); i++) {
                    return_value+=ParteDeHoras.GetMillisFrom_IntervaloEntreHoras(local_pdh.HI_Norm[i],local_pdh.HF_Norm[i]);
                }
            }
        }
        if(local_pdh.HI_Extra!=null) {
            if (local_pdh.HF_Extra != null) {

                for (int i = 0; (i < local_pdh.HI_Extra.length) || (i < local_pdh.HF_Extra.length); i++) {
                    return_value+=ParteDeHoras.GetMillisFrom_IntervaloEntreHoras(local_pdh.HI_Norm[i],local_pdh.HF_Norm[i]);
                }
            }
        }
        return return_value;
    }

    public int getEntradaArray (Entrada[] entradaArray)
    {
        //Busca el Numero de Entrada empezando a contar por las horas normales
        //en segundo lugar, sigue contando por las horas extras
        int EntradaActual = 0, index = 0;
        int returnValue=0;
        if(entradaArray==null)return 0;
        for (; index < ParteDeHoras.Normal_lenght; index++) {
            //Si hay algo escrito en algun campo ya se la considera entrada
            if (HI_Norm[index] != null) {
                if (!HI_Norm[index].equals("")) {
                    if (EntradaActual < entradaArray.length) {
                        entradaArray[EntradaActual]=new Entrada(HI_Norm[index], HF_Norm[index], Cliente_Norm[index], Observaciones_Norm[index], Entrada.TipoDeHora.NORMAL);
                            EntradaActual++;
                            returnValue=EntradaActual;
                            continue;
                    }
                    return 0;
                }
            }

            if (HF_Norm[index] != null) {
                if (!HF_Norm[index].equals("")) {
                    if (EntradaActual < entradaArray.length) {
                        entradaArray[EntradaActual]=new Entrada(HI_Norm[index], HF_Norm[index], Cliente_Norm[index], Observaciones_Norm[index], Entrada.TipoDeHora.NORMAL);
                            EntradaActual++;
                            returnValue=EntradaActual;
                            continue;
                    }
                    return 0;
                }
            }

            if (Cliente_Norm[index] != null) {
                if (!Cliente_Norm[index].equals("")) {
                    if (EntradaActual < entradaArray.length) {
                        entradaArray[EntradaActual] = new Entrada(HI_Norm[index], HF_Norm[index], Cliente_Norm[index], Observaciones_Norm[index], Entrada.TipoDeHora.NORMAL);
                        EntradaActual++;
                        returnValue = EntradaActual;
                        continue;
                    }
                    return 0;
                }
            }

            if (Observaciones_Norm[index] != null) {
                if (!Observaciones_Norm[index].equals("")) {
                    if (EntradaActual < entradaArray.length) {
                        entradaArray[EntradaActual]=new Entrada(HI_Norm[index], HF_Norm[index], Cliente_Norm[index], Observaciones_Norm[index], Entrada.TipoDeHora.NORMAL);
                            EntradaActual++;
                            returnValue=EntradaActual;
                            continue;
                    }
                    return 0;
                }
            }

        }
        for (; index < ParteDeHoras.Extra_lenght; index++) {
            //Si hay algo escrito en algun campo ya se la considera entrada
            if (HI_Extra[index] != null) {
                if (!HI_Extra[index].equals("")) {
                    if (EntradaActual < entradaArray.length) {
                        entradaArray[EntradaActual]=new Entrada(HI_Extra[index], HF_Extra[index], Cliente_Extra[index], Observaciones_Extra[index], Entrada.TipoDeHora.EXTRA);
                            EntradaActual++;
                            returnValue=EntradaActual;
                            continue;
                    }
                    return 0;
                }
            }

            if (HF_Extra[index] != null) {
                if (!HF_Extra[index].equals("")) {
                    if (EntradaActual < entradaArray.length) {
                        entradaArray[EntradaActual]=new Entrada(HI_Extra[index], HF_Extra[index], Cliente_Extra[index], Observaciones_Extra[index], Entrada.TipoDeHora.EXTRA);
                            EntradaActual++;
                            returnValue=EntradaActual;
                            continue;
                    }
                    return 0;
                }
            }

            if (Cliente_Extra[index] != null) {
                if (!Cliente_Extra[index].equals("")) {
                    if (EntradaActual < entradaArray.length) {
                        entradaArray[EntradaActual]=new Entrada(HI_Extra[index], HF_Extra[index], Cliente_Extra[index], Observaciones_Extra[index], Entrada.TipoDeHora.EXTRA);
                            EntradaActual++;
                            returnValue=EntradaActual;
                            continue;
                    }
                    return 0;
                }
            }

            if (Observaciones_Extra[index] != null) {
                if (!Observaciones_Extra[index].equals("")) {
                    if (EntradaActual < entradaArray.length) {
                        entradaArray[EntradaActual]=new Entrada(HI_Extra[index], HF_Extra[index], Cliente_Extra[index], Observaciones_Extra[index], Entrada.TipoDeHora.EXTRA);
                            EntradaActual++;
                            returnValue=EntradaActual;
                            continue;
                    }
                    return 0;
                }
            }

        }
        return returnValue;
    }

    public boolean LoadFromEntradaArray (Entrada[] entradaArray,int NEntradas)
    {
        int CurrentNormal=0,CurrentExtra=0;
        Clear();

        if(entradaArray==null)return false;
        if(NEntradas>entradaArray.length)return false;
        for(int i=0;i<NEntradas;i++)
        {
            if(entradaArray[i]!=null)
            {
                if(entradaArray[i].tipoDeHora==Entrada.TipoDeHora.NORMAL)
                {
                    if(CurrentNormal>=ParteDeHoras.Normal_lenght)return false;
                    HI_Norm[CurrentNormal]=entradaArray[i].HI;
                    HF_Norm[CurrentNormal]=entradaArray[i].HF;
                    Cliente_Norm[CurrentNormal]=entradaArray[i].Cliente;
                    Observaciones_Norm[CurrentNormal]=entradaArray[i].Observaciones;
                    CurrentNormal++;
                }
                if(entradaArray[i].tipoDeHora==Entrada.TipoDeHora.EXTRA)
                {
                    if(CurrentExtra>=ParteDeHoras.Extra_lenght)return false;
                    HI_Extra[CurrentExtra]=entradaArray[i].HI;
                    HF_Extra[CurrentExtra]=entradaArray[i].HF;
                    Cliente_Extra[CurrentExtra]=entradaArray[i].Cliente;
                    Observaciones_Extra[CurrentExtra]=entradaArray[i].Observaciones;
                    CurrentExtra++;
                }
            }
        }

        return true;
    }
    public boolean getEntrada (Entrada entrada,int NEntrada) {
        //Busca el Numero de Entrada empezando a contar por las horas normales
        //en segundo lugar, sigue contando por las horas extras
        int EntradaActual = 0, index = 0;
        for (; index < ParteDeHoras.Normal_lenght; index++) {
            //Si hay algo escrito en algun campo ya se la considera entrada
            if (HI_Norm[index] != null) {
                if (!HI_Norm[index].equals("")) {
                    if (EntradaActual == NEntrada) {
                        entrada.Fill(HI_Norm[index], HF_Norm[index], Cliente_Norm[index], Observaciones_Norm[index], Entrada.TipoDeHora.NORMAL);
                        return true;
                    }
                    EntradaActual++;
                    continue;
                }
            }
            if (HF_Norm[index] != null) {
                if (!HF_Norm[index].equals("")) {
                    if (EntradaActual == NEntrada) {
                        entrada.Fill(HI_Norm[index], HF_Norm[index], Cliente_Norm[index], Observaciones_Norm[index], Entrada.TipoDeHora.NORMAL);
                        return true;
                    }
                    EntradaActual++;
                    continue;
                }
            }
            if (Cliente_Norm[index] != null) {
                if (!Cliente_Norm[index].equals("")) {
                    if (EntradaActual == NEntrada) {
                        entrada.Fill(HI_Norm[index], HF_Norm[index], Cliente_Norm[index], Observaciones_Norm[index], Entrada.TipoDeHora.NORMAL);
                        return true;
                    }
                    EntradaActual++;
                    continue;
                }
            }
            if (Observaciones_Norm[index] != null) {
                if (!Observaciones_Norm[index].equals("")) {
                    if (EntradaActual == NEntrada) {
                        entrada.Fill(HI_Norm[index], HF_Norm[index], Cliente_Norm[index], Observaciones_Norm[index], Entrada.TipoDeHora.NORMAL);
                        return true;
                    }
                    EntradaActual++;
                    continue;
                }
            }
        }
        index=0;
        for (; index < ParteDeHoras.Extra_lenght; index++) {
            //Si hay algo escrito en algun campo ya se la considera entrada
            if (HI_Extra[index] != null) {
                if (!HI_Extra[index].equals("")) {
                    if (EntradaActual == NEntrada) {
                        entrada.Fill(HI_Extra[index], HF_Extra[index], Cliente_Extra[index], Observaciones_Extra[index], Entrada.TipoDeHora.EXTRA);
                        return true;
                    }
                    EntradaActual++;
                    continue;
                }
            }
            if (HF_Extra[index] != null) {
                if (!HF_Extra[index].equals("")) {
                    if (EntradaActual == NEntrada) {
                        entrada.Fill(HI_Extra[index], HF_Extra[index], Cliente_Extra[index], Observaciones_Extra[index], Entrada.TipoDeHora.EXTRA);
                        return true;
                    }
                    EntradaActual++;
                    continue;
                }
            }
            if (Cliente_Extra[index] != null) {
                if (!Cliente_Extra[index].equals("")) {
                    if (EntradaActual == NEntrada) {
                        entrada.Fill(HI_Extra[index], HF_Extra[index], Cliente_Extra[index], Observaciones_Extra[index], Entrada.TipoDeHora.EXTRA);
                        return true;
                    }
                    EntradaActual++;
                    continue;
                }
            }
            if (Observaciones_Extra[index] != null) {
                if (!Observaciones_Extra[index].equals("")) {
                    if (EntradaActual == NEntrada) {
                        entrada.Fill(HI_Extra[index], HF_Extra[index], Cliente_Extra[index], Observaciones_Extra[index], Entrada.TipoDeHora.EXTRA);
                        return true;
                    }
                    EntradaActual++;
                    continue;
                }
            }
        }

        return false;
    }

    //Calcula las horas extras y las registra en su variable
    public void ValidarTotalExtras() {
        long differ, differ2,differ3;
        String HI = HI_Extra[0];
        String HF = HF_Extra[0];
        String str_differ;
        differ = GetMillisFrom_IntervaloEntreHoras(HI, HF);
        HI = HI_Extra[1];
        HF = HF_Extra[1];
        differ2 = GetMillisFrom_IntervaloEntreHoras(HI, HF);

        differ3 = differ + differ2;

        if(differ3>0) Total_Extra = GetStringFromMillisHour(differ3);
    }
    //Calcula las horas normales y las presenta en el cuadro de texo correspondiente
    public void ValidarTotalNormales() {
        String HI, HF,str_differ;
        long differ = 0, differ2 = 0, total = 0;
        for (int index = 0; index < 8; index++) {

            HI = HI_Norm[index];
            HF = HF_Norm[index];
            differ = GetMillisFrom_IntervaloEntreHoras(HI, HF);
            total += differ;
        }

        if(total>0) Total_Normales = MiFecha.millisecondsToShortTime(total);

    }
}
