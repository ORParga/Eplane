package com.orparga.partedehoras03;

import android.widget.TextView;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;
import java.util.TimeZone;
import java.util.Date;

/**
 * Created by OSCAR on 30/03/2018.
 * Utilidades para convertir Milisegundos a dias horas, minutos y segundos
 * guardandolos en las variables de MiFecha.
 */
public class MiFecha {
    public long milliseconds=0;
    public long seconds=0;
    public long minutes=0;
    public long horas=0;
    public long dias=0;

    /**
     * Guarga los milisegundos en las variables del objeto MiFecha creado
     * @param milliseconds
     */
    public MiFecha(long milliseconds)
    {
        set(milliseconds);
    }

    /**
     * devuelve las horas y los minutos que representa un numero "milisegundos"
     * olvidandose de los días, los segundos y los milisegundos
     * @param milliseconds
     * @return
     */
    static public String millisecondsToShortTime (long milliseconds)
    {
        if(milliseconds<0)return "00:00";
        String returnValue="";
        MiFecha mf=new MiFecha(milliseconds);
        returnValue=mf.toShortTime();
        return returnValue;
    }

    /**
     * devuelve el contenido de las variables "horas" y "minutos"
     * en formato "hh:mm"
     * si el valor guardado en "milisegundos es negativo" el valor devuelto es "00:00"
     * @return
     */
    public String toShortTime ()
    {
        if(milliseconds<0)return "00:00";
        String returnValue="";
        if(horas<10)returnValue="0";
        returnValue+=""+horas+":";
        if(minutes<10)returnValue+="0";
        returnValue+=minutes;

        return returnValue;
    }

    /**
     * guarda en las variable internas el valor de milisegundos convertido
     * a milisegundos + segundos + minutos+ horas + dias
     * @param milliseconds
     */
    public void set (long milliseconds)
    {
        long comodin_seconds;
        long comodin_minutes;
        long comodin_hours;

        if(milliseconds<0)return;

        comodin_seconds=milliseconds/1000;
        this.milliseconds=milliseconds-(comodin_seconds*1000);

        comodin_minutes=comodin_seconds/60;
        this.seconds=comodin_seconds-(comodin_minutes*60);

        comodin_hours=comodin_minutes/60;
        this.minutes=comodin_minutes-(comodin_hours*60);

        this.dias=comodin_hours/24;
        this.horas=comodin_hours-(this.dias*24);
    }

    /**
     * convierte Calendar a dd/MM/yy
     * @param day
     * @return
     */
    public static String CalendarToString(Calendar day)
    {

        SimpleDateFormat sdf_date;

        sdf_date = new SimpleDateFormat("dd/MM/yy");
        sdf_date.setTimeZone(TimeZone.getTimeZone("GMT +0"));
        return sdf_date.format(day.getTime());
    }
    /**
     * convierte Calendar a hh:
     * @param Hora
     * @param Hora
     * @return
     */
    public static String HoraMinuteToString(int Hora,int Minuto)
    {

        Calendar cal = Calendar.getInstance();
        String returnValue;
        try {

            SimpleDateFormat sdf_date;
            sdf_date = new SimpleDateFormat("HH:mm");
            sdf_date.setTimeZone(TimeZone.getTimeZone("GMT +0"));

            cal = Calendar.getInstance();
            cal.setTimeZone(TimeZone.getTimeZone("GMT"));
            cal.set(Calendar.HOUR_OF_DAY, Hora);
            cal.set(Calendar.MINUTE, Minuto);
            returnValue=sdf_date.format(cal.getTime());
        }
        catch (Exception e)
        {

            //Si todo lo anterior falla, se utiliza la hora 00:00
            e.printStackTrace();
            returnValue="00:00";
        }
        return returnValue;
    }

    /**
     * Convierte Calendar a "July 2018"
     * @param day
     * @return
     */
    public static String MonthYearToString(Calendar day)
    {

        SimpleDateFormat sdf_date;

        sdf_date = new SimpleDateFormat("MMMM yyyy",new Locale("es", "ES"));
        sdf_date.setTimeZone(TimeZone.getTimeZone("GMT +0"));
        return sdf_date.format(day.getTime());
    }
    public static Calendar StringTimeToCalendar (String TimeInHoursMinutes)
    {
        Calendar cal = Calendar.getInstance();
        cal.setTimeZone(TimeZone.getTimeZone("GMT"));
        SimpleDateFormat sdf = new SimpleDateFormat("HH:mm");
        sdf.setTimeZone(TimeZone.getTimeZone("GMT +0"));
        try {
            cal.setTime(sdf.parse(TimeInHoursMinutes));// all done
        } catch (ParseException e) {
            e.printStackTrace();
            return null;
        }
        return cal;
    }
    public static Calendar GetRecommentedHourForDialog (TextView clickedTextView)
    {
        //Primero intenta presentar en el dialogo de seleccion de hora,
        //la hora escrita en el ciew que se ha hecho click
        Calendar cal=MiFecha.StringTimeToCalendar(clickedTextView.getText().toString());
        //Si no hay hora en el view, se intenta usar la hora por defecto (assingDAta.cnf_HI_jornada)
        if (cal==null)
        {
            cal=Calendar.getInstance();
            cal.setTimeZone(TimeZone.getTimeZone("GMT"));
            try {
                SimpleDateFormat sdf = new SimpleDateFormat("HH:mm");
                sdf.setTimeZone(TimeZone.getTimeZone("GMT +0"));
                cal.setTime(sdf.parse(PassingDAta.cnf_HI_jornada));
            }
            catch (ParseException e)
            {
                //Si todo lo anterior falla, se utiliza la hora 00:00
                e.printStackTrace();
                cal=Calendar.getInstance();
                cal.setTimeZone(TimeZone.getTimeZone("GMT"));
                cal.set(Calendar.HOUR_OF_DAY,0);
                cal.set(Calendar.MINUTE,0);
            }
        }
        return cal;
    }

    public static long getDifferBetweenCeldsStatic(TextView HF,TextView HI)
    {
        return getDifferBetweenCeldsStatic(HF.getText().toString(),HI.getText().toString());
    }
    public static long getDifferBetweenCeldsStatic(String HF,String HI)
    {
        long l_differ=0,l_differ2,f,i,m;
        Calendar l_cl_HI= Calendar.getInstance();
        Calendar l_cl_HF=Calendar.getInstance();
        Calendar l_cl_Medianoche= Calendar.getInstance();
        java.util.Date l_Date_HI,l_Date_HF,l_date_Medianoche;
        SimpleDateFormat l_sdf;

        l_sdf= new SimpleDateFormat("HH:mm");
        l_sdf.setTimeZone(TimeZone.getTimeZone( "GMT +0"));

        l_cl_Medianoche.set(Calendar.HOUR,24);

        try {
            l_Date_HI= l_sdf.parse(HI);
            l_Date_HF=l_sdf.parse(HF);
            l_date_Medianoche=l_sdf.parse("24:00");
        }
        catch (ParseException e) {
            e.printStackTrace();
        return 0;
    }
        l_cl_HI.setTime(l_Date_HI);
        l_cl_HF.setTime(l_Date_HF);
        l_cl_Medianoche.setTime(l_date_Medianoche);

        f=l_cl_HF.getTimeInMillis();
        i=l_cl_HI.getTimeInMillis();
        m=l_cl_Medianoche.getTimeInMillis();
        if(f<i){
            //Si la hora final es mayor que la hora inicial se presupone
            // trabajo nocturno
            l_differ2=m-i;
            l_differ=f+l_differ2;
        }else
        {
            l_differ=f-i;
        }

        return l_differ;
    }
    protected static long getDifferBetweenCelds(TextView HF, TextView HI) {
        SimpleDateFormat sdf = new SimpleDateFormat("HH:mm");
        sdf.setTimeZone(TimeZone.getTimeZone("GMT +0"));
        Calendar cl_HI = Calendar.getInstance();
        Calendar cl_HF = Calendar.getInstance();
        Calendar cl_Medianoche = Calendar.getInstance();
        cl_Medianoche.set(Calendar.HOUR, 24);

        Date date_HI,date_HF,date_Medianoche;
        long f,i,m,differ,differ2;
        try {
            date_HI = sdf.parse(HI.getText().toString());
            date_HF = sdf.parse(HF.getText().toString());
            date_Medianoche = sdf.parse("24:00");
        } catch (ParseException e) {
            e.printStackTrace();
            return 0;
        }

        cl_HI.setTime(date_HI);
        cl_HF.setTime(date_HF);
        cl_Medianoche.setTime(date_Medianoche);
        f = cl_HF.getTimeInMillis();
        i = cl_HI.getTimeInMillis();
        m = cl_Medianoche.getTimeInMillis();
        if (f < i) {
            //Si la hora final es mayor que la hora inicial se presupone
            // trabajo nocturno
            differ2 = m - i;
            differ = f + differ2;
        } else {
            differ = f - i;
        }

        return differ;
    }

}
