package com.orparga.partedehoras03;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.StaggeredGridLayoutManager;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;


public class ShareActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener{

    final Activity activity=this;
    Spinner spinner;
    ParteDeHoras pdh=new ParteDeHoras();


    private RecyclerView recyclerView;
    private RecyclerView.Adapter mAdapter;
    private RecyclerView.LayoutManager layoutManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_share);

        spinner= (Spinner) findViewById(R.id.share_options_spinner);
// Create an ArrayAdapter using the string array and a default spinner layout
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.share_options, android.R.layout.simple_spinner_item);
// Specify the layout to use when the list of choices appears
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
// Apply the adapter to the spinner
        spinner.setAdapter(adapter);
        spinner.setOnItemSelectedListener(this);

        setRecyclerView();
    }

    private void setRecyclerView()
    {
        PassingDAta.activity=this;
        recyclerView = (RecyclerView) findViewById(R.id.pdh_recycler_view);

        // use this setting to improve performance if you know that changes
        // in content do not change the layout size of the RecyclerView
        recyclerView.setHasFixedSize(true);
        // use a linear layout manager
        layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);
        // specify an adapter (see also next example)
        mAdapter = new PDH_RecyclerView_Adapter(PassingDAta.FileNameArray);
        recyclerView.setAdapter(mAdapter);
    }

    public void onClick_ShareSelected (View v) {

        String[] pdhFileArray = PassingDAta.FileNameArray, SharedfileNames, SharedPathsToFiles;

        ImageView imageView;
        RecyclerView recyclerView;
        LinearLayout childLinear;
        Drawable drawable;
        BitmapDrawable bitmapDrawable;
        Bitmap[] bitmapArray;
        int i = 0, nItem = 0;

        ParteDeHoras pdh = new ParteDeHoras();
        List<Box> lista_box = new ArrayList<>(); //la lista para el dibujo de las tablas y recuadros
        List<Area> lista_area = new ArrayList<>(); //la lista para el tamaño del parte de horas, etc...
        ParteShare.ReadJson(PassingDAta.activity, lista_box, lista_area);

        SharedfileNames = new String[PassingDAta.NDaysSelected];
        SharedPathsToFiles = new String[PassingDAta.NDaysSelected];

        //Crea un array de Nombres de archivos jpeg en memoria compartida
        for (; i < PassingDAta.NDaysSelected; i++) {
            //Carga el archivo con el parte de horas en un objeto "ParteDeHoras"
            FileHandling FH = new FileHandling();
            if (pdhFileArray != null) {
                if (i < pdhFileArray.length) {
                    if (!pdhFileArray[i].equals("")) {
                        FH.LoadParteFromFileToClass(pdhFileArray[i], PassingDAta.activity, pdh);
                        if (pdh != null) {
                            pdh.LoadFields();
                            //Calcula el tamaño del bitmap a partir de la configuracion de usuario(para el ancho) y del tamaño del parte según el Json (para el alto)
                            if (lista_area != null)
                                if ((nItem = Area.SearchForName(lista_area, "page")) != -1) {
                                    PassingDAta.cnf_ParteHeight_Bitmap = ((float) lista_area.get(nItem).bottom / (float) lista_area.get(nItem).right) * PassingDAta.cnf_ParteWidth_Bitmap;
                                    PassingDAta.scalePrint_bmp = PassingDAta.cnf_ParteWidth_Bitmap / (float) lista_area.get(nItem).right;
                                }
                            //Crea un objeto bitmap con las medidas guardadas los datos de configuracion
                            final Bitmap bitmap = Bitmap.createBitmap((int) PassingDAta.cnf_ParteWidth_Bitmap, (int) PassingDAta.cnf_ParteHeight_Bitmap, Bitmap.Config.ARGB_8888);
                            CanvasParaParte canvasParaParte = new CanvasParaParte(bitmap);
                            canvasParaParte.drawColor(Color.WHITE);
                            PassingDAta.WhatPrint = PassingDAta.whatPrintEnum.All;
                            //Carga el objeto "Parte de Horas" en el bitmap
                            ParteShare.DrawParteOnCanvas(lista_box, pdh, canvasParaParte, PassingDAta.scalePrint_bmp);
                            //Carga el bitmap en un archivo jpeg en la memoria compartida
                            try {
                                // Find the root of the external storage.
                                // See http://developer.android.com/guide/topics/data/data-  storage.html#filesExternal

                                File root = android.os.Environment.getExternalStorageDirectory();

                                File dir = new File(root.getAbsolutePath() + "/share");
                                if (dir.mkdirs()) {
                                    Log.d("", "Directory created");
                                } else {
                                    Log.d("", "Directory not created");
                                }
                                SharedfileNames[i] = new String("share" + i + ".jpg");
                                SharedPathsToFiles[i] = new String(root.getAbsolutePath() + "/share/" + SharedfileNames[i]);
                                File imageFile = new File(dir, SharedfileNames[i]);
                                //outputStream = new FileOutputStream(imageFile);
                                FileOutputStream outputStream = new FileOutputStream(imageFile);
                                int quality = 100;
                                bitmap.compress(Bitmap.CompressFormat.JPEG, quality, outputStream);
                                outputStream.flush();
                                outputStream.close();
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    }
                }
            }
        }

        ParteShare.ShareFile(
                SharedPathsToFiles,
                activity.getResources().getString(R.string.email_extra_subject),
                PassingDAta.NDaysSelected,
                this);

    }

    public void onItemSelected(AdapterView<?> parent, View view,
                               int pos, long id) {
        // An item was selected. You can retrieve the selected item using
        // parent.getItemAtPosition(pos)
    }

    public void onNothingSelected(AdapterView<?> parent) {
        // Another interface callback
    }


}
