package com.orparga.partedehoras03;


import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Rect;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.content.ContextCompat;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;

import static android.util.TypedValue.COMPLEX_UNIT_PX;


/**
 * A simple {@link Fragment} subclass.
 */
public class FragmentParte02 extends Fragment implements View.OnClickListener {

    //The main View for this Fragment loaded in onCreateView()
    View mainView;

    int[] HI_Norm, HF_Norm, Cliente_Norm, Observaciones_Norm;
    Calendar myCalendar,CalendarForPicker;

    //Variables de configuracion
    boolean cnf_primeraVez=false;
    boolean cnf_algoFallo=false;
    Calendar cal_Inicio_Jornada;
    Calendar cal_Fin_Jornada;
    Calendar cal_Inicio_Comida;
    Calendar cal_Fin_Comida;
    long cnf_mañana;
    long cnf_tarde;

    boolean AutoEditing=false ;

    //Variables para manejar los controles
    TextView lblFecha,txtOperario,txtNumeroParte;
    View viewForContextMenu;
    View[] ControlesTextYEdit;
    EditText[] ControlesEditables;
    TextView[] ControlesTextView;
    TextView[] ControlesTextExtra;
    TextView[] ControlesTextNormal;

    //Variables para el control de fecha
    SimpleDateFormat sdf,sdf_date;
    long differ, differ2, differ3;
    long i, f, m;
    Date date_HI, date_HF, date_Medianoche;
    Calendar cl_HI, cl_HF, cl_differ, cl_Medianoche;
    String str_differ;

    //Variables para el manejo de archivos
    FileHandling FH;
    ParteShare parteShare;
    String NombreDeArchivo;
    final int REQUEST_WRITE_PERMISSION = 786;
    boolean TengoPermiso=false;
    View.OnClickListener onExtraListener,onNormalListener;
    View.OnLongClickListener onLongClickListener;

    View lblClicked;
    
    //Menu contextual
    View gViewLongClicked;

    //Clases internas
    protected ParteDeHoras pdh;
    private static final String[] COUNTRIES = new String[] {
            "Belgium", "France", "Italy", "Germany", "Spain"
    };

    DatePickerDialog.OnDateSetListener date;
    TimePickerDialog timeExtraPicker,timeNormPicker;
    TimePickerDialog.OnTimeSetListener timeExtraListener, timeNormListener;
    TimePickerDialog.OnDismissListener timeDismissListener;
    View.OnLongClickListener longClickListener;

    public FragmentParte02() {
        // Required empty public constructor
    }


    protected void CargarControlesTextView (View mainView)
    {
        ControlesTextView=new TextView[25];
        ControlesTextExtra=new TextView[4];
        ControlesTextNormal=new TextView[16];

        int i=0,j=0;
        ControlesTextView[i++]=(TextView)mainView.findViewById(R.id.HI_Extra1);ControlesTextExtra[j++]=ControlesTextView[i-1];
        ControlesTextView[i++]=(TextView)mainView.findViewById(R.id.HF_Extra1);ControlesTextExtra[j++]=ControlesTextView[i-1];
        ControlesTextView[i++]=(TextView)mainView.findViewById(R.id.HI_Extra2);ControlesTextExtra[j++]=ControlesTextView[i-1];
        ControlesTextView[i++]=(TextView)mainView.findViewById(R.id.HF_Extra2);ControlesTextExtra[j++]=ControlesTextView[i-1];
        ControlesTextView[i++]=(TextView)mainView.findViewById(R.id.lblTotal_Extra);
        ControlesTextView[i++]=(TextView)mainView.findViewById(R.id.txtNumero);
        ControlesTextView[i++]=(TextView)mainView.findViewById(R.id.txtFecha);
        ControlesTextView[i++]=(TextView)mainView.findViewById(R.id.txtOperario);

        j=0;
        ControlesTextView[i++]=(TextView)mainView.findViewById(R.id.HI_Norm1);ControlesTextNormal[j++]=ControlesTextView[i-1];
        ControlesTextView[i++]=(TextView)mainView.findViewById(R.id.HF_Norm1);ControlesTextNormal[j++]=ControlesTextView[i-1];
        ControlesTextView[i++]=(TextView)mainView.findViewById(R.id.HI_Norm2);ControlesTextNormal[j++]=ControlesTextView[i-1];
        ControlesTextView[i++]=(TextView)mainView.findViewById(R.id.HF_Norm2);ControlesTextNormal[j++]=ControlesTextView[i-1];
        ControlesTextView[i++]=(TextView)mainView.findViewById(R.id.HI_Norm3);ControlesTextNormal[j++]=ControlesTextView[i-1];
        ControlesTextView[i++]=(TextView)mainView.findViewById(R.id.HF_Norm3);ControlesTextNormal[j++]=ControlesTextView[i-1];
        ControlesTextView[i++]=(TextView)mainView.findViewById(R.id.HI_Norm4);ControlesTextNormal[j++]=ControlesTextView[i-1];
        ControlesTextView[i++]=(TextView)mainView.findViewById(R.id.HF_Norm4);ControlesTextNormal[j++]=ControlesTextView[i-1];
        ControlesTextView[i++]=(TextView)mainView.findViewById(R.id.HI_Norm5);ControlesTextNormal[j++]=ControlesTextView[i-1];
        ControlesTextView[i++]=(TextView)mainView.findViewById(R.id.HF_Norm5);ControlesTextNormal[j++]=ControlesTextView[i-1];
        ControlesTextView[i++]=(TextView)mainView.findViewById(R.id.HI_Norm6);ControlesTextNormal[j++]=ControlesTextView[i-1];
        ControlesTextView[i++]=(TextView)mainView.findViewById(R.id.HF_Norm6);ControlesTextNormal[j++]=ControlesTextView[i-1];
        ControlesTextView[i++]=(TextView)mainView.findViewById(R.id.HI_Norm7);ControlesTextNormal[j++]=ControlesTextView[i-1];
        ControlesTextView[i++]=(TextView)mainView.findViewById(R.id.HF_Norm7);ControlesTextNormal[j++]=ControlesTextView[i-1];
        ControlesTextView[i++]=(TextView)mainView.findViewById(R.id.HI_Norm8);ControlesTextNormal[j++]=ControlesTextView[i-1];
        ControlesTextView[i++]=(TextView)mainView.findViewById(R.id.HF_Norm8);ControlesTextNormal[j++]=ControlesTextView[i-1];

        ControlesTextView[i++]=(TextView)mainView.findViewById(R.id.lblTotal_Norm);
    }

    protected void CargarControlesEditables (View mainView)
    {
        ControlesEditables=new EditText[20];

        int i=0;
        ControlesEditables[i++]=(EditText)mainView.findViewById(R.id.Cliente_Extra1);
//        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
//                android.R.layout.simple_dropdown_item_1line, COUNTRIES);
//        ControlesEditables[i].setAdapter(adapter);
        ControlesEditables[i++]=(EditText)mainView.findViewById(R.id.Observaciones_Extra1);
        ControlesEditables[i++]=(EditText)mainView.findViewById(R.id.Cliente_Extra2);
        ControlesEditables[i++]=(EditText)mainView.findViewById(R.id.Observaciones_Extra2);

        //ControlesEditables[i++]=(EditText)mainView.findViewById(R.id.txtOperario);

        ControlesEditables[i++]=(EditText)mainView.findViewById(R.id.Cliente_Norm1);
        ControlesEditables[i++]=(EditText)mainView.findViewById(R.id.Observaciones_Norm1);

        ControlesEditables[i++]=(EditText)mainView.findViewById(R.id.Cliente_Norm2);
        ControlesEditables[i++]=(EditText)mainView.findViewById(R.id.Observaciones_Norm2);

        ControlesEditables[i++]=(EditText)mainView.findViewById(R.id.Cliente_Norm3);
        ControlesEditables[i++]=(EditText)mainView.findViewById(R.id.Observaciones_Norm3);

        ControlesEditables[i++]=(EditText)mainView.findViewById(R.id.Cliente_Norm4);
        ControlesEditables[i++]=(EditText)mainView.findViewById(R.id.Observaciones_Norm4);

        ControlesEditables[i++]=(EditText)mainView.findViewById(R.id.Cliente_Norm5);
        ControlesEditables[i++]=(EditText)mainView.findViewById(R.id.Observaciones_Norm5);

        ControlesEditables[i++]=(EditText)mainView.findViewById(R.id.Cliente_Norm6);
        ControlesEditables[i++]=(EditText)mainView.findViewById(R.id.Observaciones_Norm6);

        ControlesEditables[i++]=(EditText)mainView.findViewById(R.id.Cliente_Norm7);
        ControlesEditables[i++]=(EditText)mainView.findViewById(R.id.Observaciones_Norm7);

        ControlesEditables[i++]=(EditText)mainView.findViewById(R.id.Cliente_Norm8);
        ControlesEditables[i++]=(EditText)mainView.findViewById(R.id.Observaciones_Norm8);


    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.HI_Extra1:
                Log.d("Log","Test Submit!#@%!#%");
                break;
            default:
                break;
        }

    }
    protected void IniOnClickListeners ()
    {


        onExtraListener=new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                view.setBackgroundColor(ContextCompat.getColor(getActivity(), R.color.colorTextViewSelected));
                //Guarda el View en el que se ha hecho click. para recuperarlo cuendo
                //regrese del dialogo de seleccion de hora
                lblClicked = view;
                TextView txtView=(TextView)lblClicked;
                Calendar cal=MiFecha.GetRecommentedHourForDialog(txtView);
                timeExtraPicker= new TimePickerDialog(getActivity(),R.style.DialogTheme, timeExtraListener,
                        cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE), true);
                timeExtraPicker.setOnDismissListener(timeDismissListener);
                timeExtraPicker.show();
            }
        };
        onNormalListener=new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                view.setBackgroundColor(ContextCompat.getColor(getActivity(), R.color.colorTextViewSelected));
                //Guarda el View en el que se ha hecho click. para recuperarlo cuendo
                //regrese del dialogo de seleccion de hora
                lblClicked = view;
                TextView txtView=(TextView)lblClicked;
                Calendar cal=MiFecha.GetRecommentedHourForDialog(txtView);
                timeNormPicker=new TimePickerDialog(getActivity(),R.style.DialogTheme, timeNormListener,
                        cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE), true);
                timeNormPicker.setOnDismissListener(timeDismissListener);
                timeNormPicker.show();
            }
        };
        for (int i=0;i<ControlesTextExtra.length;i++)
        {
            ControlesTextExtra[i].setOnClickListener(onExtraListener);
        }
        for (int i=0;i<ControlesTextNormal.length;i++)
        {
            ControlesTextNormal[i].setOnClickListener(onNormalListener);
        }

    }
    @Override
    public void onCreateContextMenu(ContextMenu menu, View v,
                                    ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        MenuInflater inflater =getActivity().getMenuInflater();
        inflater.inflate(R.menu.context_menu_main_long_click_in_hour, menu);
        gViewLongClicked =  v;
    }
    @Override
    public boolean onContextItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.mnu1_Seleccionar:
                return true;
            case R.id.mnu1_option1:
                gViewLongClicked.performClick();
                return true;
            case R.id.mnu1_option2:
                ((TextView)gViewLongClicked).setText("");
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
    private void IniOnTimeListeners()
    {

        date = new DatePickerDialog.OnDateSetListener() {

            @Override
            public void onDateSet(DatePicker view, int year, int mes,
                                  int dia) {
                // El cuadro de fecha controla el parte que se está viendo.
                //Cuando el usuario pulsa cambia de fecha,
                // el programa debe guardar el parte que esta haciendo
                // y cargar el parte de la nueva fecha seleccionada

                //primero guarda el trabajo hecho en la fecha que había en
                // el cuadro de la fecha

                SaveParteOnClass();
                if(!pdh.NothingToSave())
                    FH.SaveParteFromClassToFile(getActivity(), pdh);
                else
                    FH.EraseFile(pdh,getActivity().getBaseContext());
                // despues carga el archivo correspondiente a la nueva fecha
                myCalendar.set(Calendar.YEAR, year);
                myCalendar.set(Calendar.MONTH, mes);
                myCalendar.set(Calendar.DAY_OF_MONTH, dia);
                pdh.Clear();
                AutoEditing=true;
                if( FH.LoadParteFromFileToClass(myCalendar,getActivity(), pdh))
                {
                    ShowParteFromClass();
                    ValidarTotalExtras();
                    ValidarTotalNormales();
                }
                else
                {
                    ClearParte();
                }
                updateFecha();
                updateOperario();
                AutoEditing=false;
            }

        };

        timeExtraListener = new TimePickerDialog.OnTimeSetListener() {
            @Override
            public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                myCalendar.set(Calendar.HOUR_OF_DAY, hourOfDay);
                myCalendar.set(Calendar.MINUTE, minute);
                updateLabelTime_Extra();
            }
        };
        timeNormListener = new TimePickerDialog.OnTimeSetListener() {
            @Override
            public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                myCalendar.set(Calendar.HOUR_OF_DAY, hourOfDay);
                myCalendar.set(Calendar.MINUTE, minute);
                updateLabelTime_Norm();
            }
        };
        timeDismissListener= new DialogInterface.OnDismissListener() {
            public void onDismiss(DialogInterface dialog) {
                lblClicked.setBackgroundColor(ContextCompat.getColor(getActivity(), R.color.colorBackcolor));
            }
        };

    }
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        mainView= inflater.inflate(R.layout.fragment_parte_02, container, false);
        IniClassVariables();
        CargarControlesTextView(mainView);
        CargarControlesEditables(mainView);


        //Inicializar listeners
        IniListeners();
        mListener.onTestImterface(1);
        return mainView;
    }
    @Override
    public void onResume() {
        ParteDeHoras pdh_local;
        Calendar cal_jornada_duracion;
        Calendar cal_Inicio, com_Inicio, extra_Inicio;
        Calendar cal_Salida, com_Salida, extra_Salida;
        //Calendar difference;
        long jornada_normal_millis, jornada_normal_hours;
        long jornada_hoy_millis, jornada_hoy_hours;
        long trabajadas_millis, trabajadas_hours;
        long comida_millis, comida_hours;
        long mañana_duracion, tarde_duracion;
        long fin_horas_normales;
        long jornada_normal_milis;

        super.onResume();

        pdh_local = new ParteDeHoras();
        cal_jornada_duracion = Calendar.getInstance();
        cal_Inicio = Calendar.getInstance();
        cal_Salida = Calendar.getInstance();
        com_Inicio = Calendar.getInstance();
        com_Salida = Calendar.getInstance();
        extra_Inicio = Calendar.getInstance();
        extra_Salida = Calendar.getInstance();

        try {
            switch (PassingDAta.fromActivity) {
                case Autofill:
                    if(PassingDAta.fill_ok_pressed) {
                        //Calcula la duracion de la jornada y de la comida
                        cal_jornada_duracion.setTime(sdf.parse(PassingDAta.cnf_jornada_normal));
                        cal_Inicio.setTime(sdf.parse(PassingDAta.fill_hora_inicio));
                        cal_Salida.setTime(sdf.parse(PassingDAta.fill_hora_salida));
                        jornada_hoy_millis = cal_Salida.getTimeInMillis() - cal_Inicio.getTimeInMillis();
                        jornada_hoy_hours = jornada_hoy_millis / (60 * 60 * 1000);
                        com_Inicio.setTime(sdf.parse(PassingDAta.cnf_HI_comida));
                        com_Salida.setTime(sdf.parse(PassingDAta.cnf_HF_comida));
                        comida_millis = com_Salida.getTimeInMillis() - com_Inicio.getTimeInMillis();
                        comida_hours = comida_millis / (60 * 60 * 1000);

                        //Introduce la mañana
                        pdh_local.HI_Norm[0] = PassingDAta.fill_hora_inicio;
                        pdh_local.Cliente_Norm[0] = PassingDAta.fill_cliente;
                        pdh_local.Observaciones_Norm[0] = PassingDAta.fill_tareas;

                        if (cal_Salida.getTimeInMillis() > com_Salida.getTimeInMillis()) {
                            //Si hay descanso para comer
                            pdh_local.HF_Norm[0] = PassingDAta.cnf_HI_comida;

                            pdh_local.HI_Norm[1] = PassingDAta.cnf_HF_comida;
                            pdh_local.Cliente_Norm[1] = PassingDAta.fill_cliente;
                            pdh_local.Observaciones_Norm[1] = PassingDAta.fill_tareas;
                            //Recalcula la duracion de la jornada
                            trabajadas_millis = jornada_hoy_millis - (comida_millis);
                            trabajadas_hours = trabajadas_millis / (60 * 60 * 1000);
                            if (trabajadas_millis > cal_jornada_duracion.getTimeInMillis()) {
                                //Si hay horas extras
                                mañana_duracion = com_Inicio.getTimeInMillis() - cal_Inicio.getTimeInMillis();
                                tarde_duracion = cal_Salida.getTimeInMillis() - com_Salida.getTimeInMillis();
                                fin_horas_normales = cal_Inicio.getTimeInMillis() + cal_jornada_duracion.getTimeInMillis() + comida_millis;
                                //extra_Inicio.setTimeInMillis(fin_horas_normales);
                                pdh_local.HF_Norm[1] = MiFecha.millisecondsToShortTime(fin_horas_normales);
                                pdh_local.HI_Extra[0] = pdh_local.HF_Norm[1];
                                pdh_local.HF_Extra[0] = PassingDAta.fill_hora_salida;
                                pdh_local.Cliente_Extra[0] = PassingDAta.fill_cliente;
                                pdh_local.Observaciones_Extra[0] = PassingDAta.fill_tareas;
                            } else {
                                //Si no hay horas extras
                                pdh_local.HF_Norm[1] = PassingDAta.fill_hora_salida;
                            }

                        } else {
                            //Si solo se trabaja por la mañana
                            pdh_local.HF_Norm[0] = PassingDAta.fill_hora_salida;
                        }
                        SaveParteOnClass();
                        pdh_local.NumeroParte = pdh.NumeroParte;
                        pdh_local.Fecha = pdh.Fecha;
                        pdh_local.Operario = pdh.Operario;
                        ShowParteFromClass(pdh_local);
                        ValidarTotalNormales();
                        ValidarTotalExtras();
                        if (pdh.NothingToSave()) {
                            Log.d("onResume", "Nothing To Save");
                        } else {
                            Log.d("onResume", "Something To Save");
                            SaveParteOnClass();
                            FH.SaveParteFromClassToFile(getActivity(), pdh);
                        }
                    }
                    break;
                case Month:
                    if(PassingDAta.thereIsAnyDayClicked)
                    {
                        pdh.Clear();
                        FH.LoadParteFromFileToClass(PassingDAta.fileNameSelected,getActivity(),pdh);
                        pdh.Fecha=FileHandling.getDatefromFileName(PassingDAta.fileNameSelected);
                        ShowParteFromClass(pdh);
                    }
                    break;
                case None:
                    int i=0;
                    break;
                    default:
                        int j=0;
                        break;
            }
        } catch (Exception e) {
            Log.d("onResume", "exception");
        }
    }

    public void IniListeners()
    {
        IniOnClickListeners();
        IniOnTimeListeners();
    }

    private void updateLabelTime_Norm() {
        if (lblClicked != null) {
            ((TextView) lblClicked).setText(sdf.format(myCalendar.getTime()));
        }
        ValidarTotalNormales();
        lblClicked.setBackgroundColor(ContextCompat.getColor(getActivity(), R.color.colorBackcolor));
        ResizeTextToFit((TextView)lblClicked);

    }

    private void updateLabelTime_Extra() {
        if (lblClicked != null) {
            ((TextView) lblClicked).setText(sdf.format(myCalendar.getTime()));
            ValidarTotalExtras();
            SaveParteOnClass();
            if(!pdh.NothingToSave())
                FH.SaveParteFromClassToFile(getActivity(), pdh);
            else
                FH.EraseFile(pdh,getActivity().getBaseContext());
            lblClicked.setBackgroundColor(ContextCompat.getColor(getActivity(), R.color.colorBackcolor));
            ResizeTextToFit((TextView)lblClicked);
        }
    }
    private void ResizeTextToFit(TextView tv)
    {
        if (tv==null)return;

        if(PassingDAta.InitialTextSize!=0)
        {
            tv.setTextSize(COMPLEX_UNIT_PX, PassingDAta.InitialTextSize);
        }
        else
            {
                if(!tv.getText().equals("")) {
                    int MinWidth = 10;
                    Rect bounds = new Rect();
                    int BoxHeight, BoxWidth, BoxHeight2, BoxWidth2, TextWidth;
                    float TextSize = tv.getTextSize();
                    tv.measure(0, 0);
                    BoxHeight = tv.getMeasuredHeight();
                    BoxWidth = tv.getMeasuredWidth();
                    BoxHeight2 = tv.getHeight();
                    BoxWidth2 = tv.getWidth();

                    tv.getPaint().getTextBounds(tv.getText().toString(), 0, tv.getText().length(), bounds);
                    TextWidth = bounds.right - bounds.left;
                    while ((TextWidth > (BoxWidth - 10)) && (TextWidth > MinWidth)) {
                        tv.getPaint().getTextBounds(tv.getText().toString(), 0, tv.getText().length(), bounds);
                        TextWidth = bounds.right - bounds.left;
                        TextSize--;
                        tv.setTextSize(COMPLEX_UNIT_PX, TextSize);
                    }
                    if (PassingDAta.InitialTextSize == 0)
                        PassingDAta.InitialTextSize = tv.getTextSize();
                }
        }
    }

    public void onClickLabel_Cliente(View v) {
        Log.d("onClickLabel_Cliente", v.toString());
    }

    public void onClickLabel_Obsevaciones(View v) {
        Log.d("onClickLabel_Obsevaci", v.toString());
    }

    public void IniClassVariables ()
    {

        //Inicializa variables de uso general
        sdf = new SimpleDateFormat("HH:mm");
        sdf.setTimeZone(TimeZone.getTimeZone("GMT +0"));
        sdf_date = new SimpleDateFormat("dd/MM/yy");
        sdf_date.setTimeZone(TimeZone.getTimeZone("GMT +0"));
        myCalendar = Calendar.getInstance();
        myCalendar.setTimeZone(TimeZone.getTimeZone("GMT"));
        CalendarForPicker = Calendar.getInstance();
        CalendarForPicker.setTimeZone(TimeZone.getTimeZone("GMT"));
        pdh=new ParteDeHoras();
        FH = new FileHandling();
        parteShare=new ParteShare();


        //Inicializa calgunos controles de texto
        CargarArrayDeIDs();
        CargarControlesEditables();
        CargarControlesTextView();
        CargarTextWatchers();
        CargarArrayDeControles();
        CargarMenusContextuales();

        //Carga el archivo de Configuracion
        IniArchivoDeConfiguracion();

        //Comprueba si hay un archivo en memoria para el dia de hoy
        IniArchivoEnMemoriaParaDiaDeHoy();

    }

    protected void CargarArrayDeIDs() {
        HI_Norm = new int[8];
        HF_Norm = new int[8];
        Cliente_Norm = new int[8];
        Observaciones_Norm = new int[8];

        HI_Norm[0] = R.id.HI_Norm1;
        HI_Norm[1] = R.id.HI_Norm2;
        HI_Norm[2] = R.id.HI_Norm3;
        HI_Norm[3] = R.id.HI_Norm4;
        HI_Norm[4] = R.id.HI_Norm5;
        HI_Norm[5] = R.id.HI_Norm6;
        HI_Norm[6] = R.id.HI_Norm7;
        HI_Norm[7] = R.id.HI_Norm8;

        HF_Norm[0] = R.id.HF_Norm1;
        HF_Norm[1] = R.id.HF_Norm2;
        HF_Norm[2] = R.id.HF_Norm3;
        HF_Norm[3] = R.id.HF_Norm4;
        HF_Norm[4] = R.id.HF_Norm5;
        HF_Norm[5] = R.id.HF_Norm6;
        HF_Norm[6] = R.id.HF_Norm7;
        HF_Norm[7] = R.id.HF_Norm8;

        Cliente_Norm[0] = R.id.Cliente_Norm1;
        Cliente_Norm[1] = R.id.Cliente_Norm2;
        Cliente_Norm[2] = R.id.Cliente_Norm3;
        Cliente_Norm[3] = R.id.Cliente_Norm4;
        Cliente_Norm[4] = R.id.Cliente_Norm5;
        Cliente_Norm[5] = R.id.Cliente_Norm6;
        Cliente_Norm[6] = R.id.Cliente_Norm7;
        Cliente_Norm[7] = R.id.Cliente_Norm8;

        Observaciones_Norm[0] = R.id.Observaciones_Norm1;
        Observaciones_Norm[1] = R.id.Observaciones_Norm2;
        Observaciones_Norm[2] = R.id.Observaciones_Norm3;
        Observaciones_Norm[3] = R.id.Observaciones_Norm4;
        Observaciones_Norm[4] = R.id.Observaciones_Norm5;
        Observaciones_Norm[5] = R.id.Observaciones_Norm6;
        Observaciones_Norm[6] = R.id.Observaciones_Norm7;
        Observaciones_Norm[7] = R.id.Observaciones_Norm8;
    }

    protected  void CargarArrayDeControles ()
    {
        ControlesTextYEdit=new View[45];

        int i=0;
        ControlesTextYEdit[i++]=mainView.findViewById(R.id.HI_Extra1);
        ControlesTextYEdit[i++]=mainView.findViewById(R.id.HF_Extra1);
        ControlesTextYEdit[i++]=mainView.findViewById(R.id.Cliente_Extra1);
        ControlesTextYEdit[i++]=mainView.findViewById(R.id.Observaciones_Extra1);
        ControlesTextYEdit[i++]=mainView.findViewById(R.id.HI_Extra2);
        ControlesTextYEdit[i++]=mainView.findViewById(R.id.HF_Extra2);
        ControlesTextYEdit[i++]=mainView.findViewById(R.id.Cliente_Extra2);
        ControlesTextYEdit[i++]=mainView.findViewById(R.id.Observaciones_Extra2);

        ControlesTextYEdit[i++]=mainView.findViewById(R.id.lblTotal_Extra);

        ControlesTextYEdit[i++]=mainView.findViewById(R.id.txtNumero);
        ControlesTextYEdit[i++]=mainView.findViewById(R.id.txtFecha);
        ControlesTextYEdit[i++]=mainView.findViewById(R.id.txtOperario);

        ControlesTextYEdit[i++]=mainView.findViewById(R.id.HI_Norm1);
        ControlesTextYEdit[i++]=mainView.findViewById(R.id.HF_Norm1);
        ControlesTextYEdit[i++]=mainView.findViewById(R.id.Cliente_Norm1);
        ControlesTextYEdit[i++]=mainView.findViewById(R.id.Observaciones_Norm1);

        ControlesTextYEdit[i++]=mainView.findViewById(R.id.HI_Norm2);
        ControlesTextYEdit[i++]=mainView.findViewById(R.id.HF_Norm2);
        ControlesTextYEdit[i++]=mainView.findViewById(R.id.Cliente_Norm2);
        ControlesTextYEdit[i++]=mainView.findViewById(R.id.Observaciones_Norm2);

        ControlesTextYEdit[i++]=mainView.findViewById(R.id.HI_Norm3);
        ControlesTextYEdit[i++]=mainView.findViewById(R.id.HF_Norm3);
        ControlesTextYEdit[i++]=mainView.findViewById(R.id.Cliente_Norm3);
        ControlesTextYEdit[i++]=mainView.findViewById(R.id.Observaciones_Norm3);

        ControlesTextYEdit[i++]=mainView.findViewById(R.id.HI_Norm4);
        ControlesTextYEdit[i++]=mainView.findViewById(R.id.HF_Norm4);
        ControlesTextYEdit[i++]=mainView.findViewById(R.id.Cliente_Norm4);
        ControlesTextYEdit[i++]=mainView.findViewById(R.id.Observaciones_Norm4);

        ControlesTextYEdit[i++]=mainView.findViewById(R.id.HI_Norm5);
        ControlesTextYEdit[i++]=mainView.findViewById(R.id.HF_Norm5);
        ControlesTextYEdit[i++]=mainView.findViewById(R.id.Cliente_Norm5);
        ControlesTextYEdit[i++]=mainView.findViewById(R.id.Observaciones_Norm5);

        ControlesTextYEdit[i++]=mainView.findViewById(R.id.HI_Norm6);
        ControlesTextYEdit[i++]=mainView.findViewById(R.id.HF_Norm6);
        ControlesTextYEdit[i++]=mainView.findViewById(R.id.Cliente_Norm6);
        ControlesTextYEdit[i++]=mainView.findViewById(R.id.Observaciones_Norm6);

        ControlesTextYEdit[i++]=mainView.findViewById(R.id.HI_Norm7);
        ControlesTextYEdit[i++]=mainView.findViewById(R.id.HF_Norm7);
        ControlesTextYEdit[i++]=mainView.findViewById(R.id.Cliente_Norm7);
        ControlesTextYEdit[i++]=mainView.findViewById(R.id.Observaciones_Norm7);

        ControlesTextYEdit[i++]=mainView.findViewById(R.id.HI_Norm8);
        ControlesTextYEdit[i++]=mainView.findViewById(R.id.HF_Norm8);
        ControlesTextYEdit[i++]=mainView.findViewById(R.id.Cliente_Norm8);
        ControlesTextYEdit[i++]=mainView.findViewById(R.id.Observaciones_Norm8);

        ControlesTextYEdit[i++]=mainView.findViewById(R.id.lblTotal_Norm);

    }

    protected void CargarControlesEditables ()
    {
        ControlesEditables=new EditText[20];

        int i=0;
        ControlesEditables[i++]=(EditText)mainView.findViewById(R.id.Cliente_Extra1);
        ControlesEditables[i++]=(EditText)mainView.findViewById(R.id.Observaciones_Extra1);
        ControlesEditables[i++]=(EditText)mainView.findViewById(R.id.Cliente_Extra2);
        ControlesEditables[i++]=(EditText)mainView.findViewById(R.id.Observaciones_Extra2);

        //ControlesEditables[i++]=(EditText)mainView.findViewById(R.id.txtOperario);

        ControlesEditables[i++]=(EditText)mainView.findViewById(R.id.Cliente_Norm1);
        ControlesEditables[i++]=(EditText)mainView.findViewById(R.id.Observaciones_Norm1);

        ControlesEditables[i++]=(EditText)mainView.findViewById(R.id.Cliente_Norm2);
        ControlesEditables[i++]=(EditText)mainView.findViewById(R.id.Observaciones_Norm2);

        ControlesEditables[i++]=(EditText)mainView.findViewById(R.id.Cliente_Norm3);
        ControlesEditables[i++]=(EditText)mainView.findViewById(R.id.Observaciones_Norm3);

        ControlesEditables[i++]=(EditText)mainView.findViewById(R.id.Cliente_Norm4);
        ControlesEditables[i++]=(EditText)mainView.findViewById(R.id.Observaciones_Norm4);

        ControlesEditables[i++]=(EditText)mainView.findViewById(R.id.Cliente_Norm5);
        ControlesEditables[i++]=(EditText)mainView.findViewById(R.id.Observaciones_Norm5);

        ControlesEditables[i++]=(EditText)mainView.findViewById(R.id.Cliente_Norm6);
        ControlesEditables[i++]=(EditText)mainView.findViewById(R.id.Observaciones_Norm6);

        ControlesEditables[i++]=(EditText)mainView.findViewById(R.id.Cliente_Norm7);
        ControlesEditables[i++]=(EditText)mainView.findViewById(R.id.Observaciones_Norm7);

        ControlesEditables[i++]=(EditText)mainView.findViewById(R.id.Cliente_Norm8);
        ControlesEditables[i++]=(EditText)mainView.findViewById(R.id.Observaciones_Norm8);


    }
    protected void CargarControlesTextView ()
    {
        ControlesTextView=new TextView[25];

        int i=0;
        ControlesTextView[i++]=(TextView)mainView.findViewById(R.id.HI_Extra1);
        ControlesTextView[i++]=(TextView)mainView.findViewById(R.id.HF_Extra1);
        ControlesTextView[i++]=(TextView)mainView.findViewById(R.id.HI_Extra2);
        ControlesTextView[i++]=(TextView)mainView.findViewById(R.id.HF_Extra2);
        ControlesTextView[i++]=(TextView)mainView.findViewById(R.id.lblTotal_Extra);
        ControlesTextView[i++]=(TextView)mainView.findViewById(R.id.txtNumero);
        ControlesTextView[i++]=(TextView)mainView.findViewById(R.id.txtFecha);
        ControlesTextView[i++]=(TextView)mainView.findViewById(R.id.txtOperario);

        ControlesTextView[i++]=(TextView)mainView.findViewById(R.id.HI_Norm1);
        ControlesTextView[i++]=(TextView)mainView.findViewById(R.id.HF_Norm1);
        ControlesTextView[i++]=(TextView)mainView.findViewById(R.id.HI_Norm2);
        ControlesTextView[i++]=(TextView)mainView.findViewById(R.id.HF_Norm2);
        ControlesTextView[i++]=(TextView)mainView.findViewById(R.id.HI_Norm3);
        ControlesTextView[i++]=(TextView)mainView.findViewById(R.id.HF_Norm3);
        ControlesTextView[i++]=(TextView)mainView.findViewById(R.id.HI_Norm4);
        ControlesTextView[i++]=(TextView)mainView.findViewById(R.id.HF_Norm4);
        ControlesTextView[i++]=(TextView)mainView.findViewById(R.id.HI_Norm5);
        ControlesTextView[i++]=(TextView)mainView.findViewById(R.id.HF_Norm5);
        ControlesTextView[i++]=(TextView)mainView.findViewById(R.id.HI_Norm6);
        ControlesTextView[i++]=(TextView)mainView.findViewById(R.id.HF_Norm6);
        ControlesTextView[i++]=(TextView)mainView.findViewById(R.id.HI_Norm7);
        ControlesTextView[i++]=(TextView)mainView.findViewById(R.id.HF_Norm7);
        ControlesTextView[i++]=(TextView)mainView.findViewById(R.id.HI_Norm8);
        ControlesTextView[i++]=(TextView)mainView.findViewById(R.id.HF_Norm8);

        ControlesTextView[i++]=(TextView)mainView.findViewById(R.id.lblTotal_Norm);
    }
    protected boolean CargarMenusContextuales()
    {
        if(ControlesTextView==null)return false;
        for(int i=0;i<ControlesTextView.length;i++)
        {
            registerForContextMenu(ControlesTextView[i]);
        }
        return true;
    }
    protected boolean CargarTextWatchers ()
    {
        if (ControlesEditables==null)return false;

        for(int i=0;i<ControlesEditables.length;i++)
        {
            ControlesEditables[i].addTextChangedListener(filterTextWatcher);
        }

        return true;
    }
    private TextWatcher filterTextWatcher = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {

        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {

            if(AutoEditing != true){
                SaveParteOnClass();
                if (pdh.NothingToSave())
                {
                    Log.d("onTextChangued", "Nothing To Save");
                }
                else {
                    Log.d("onTextChangued", "Something To Save");
                    SaveParteOnClass();
                    FH.SaveParteFromClassToFile(getActivity(), pdh);
                }
            }
        }

        @Override
        public void afterTextChanged(Editable s) {

        }
    };

    public void IniArchivoDeConfiguracion ()
    {

        //Carga el archivo de configuracion
        lblFecha = (TextView) mainView.findViewById(R.id.txtFecha);
        txtNumeroParte=(TextView) mainView.findViewById(R.id.txtNumero);
        txtOperario=(TextView)mainView.findViewById(R.id.txtOperario);
        FileOutputStream fileConfigOut;
        FileInputStream fileConfigIn=null;
        boolean outputValue=false,inputValue=false;
        byte[] buffer;

        buffer=new byte[1024];
        try {
            fileConfigIn = getActivity().openFileInput("configuration");
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            cnf_primeraVez=true;
        }
        if(!cnf_algoFallo) {
            if (cnf_primeraVez) {
                try {
                    fileConfigOut = getActivity().openFileOutput("configuration", Context.MODE_PRIVATE);
                    fileConfigOut.write(("operario,"+getString(R.string.cnf_default_operario)+";").getBytes());
                    fileConfigOut.write(("jornada_normal,"+getString(R.string.cnf_default_jornada_normal)+";").getBytes());
                    fileConfigOut.write(("HI_jornada,"+getString(R.string.cnf_default_HI_0)+";").getBytes());
                    fileConfigOut.write(("HF_jornada,"+getString(R.string.cnf_default_HF_1)+";").getBytes());
                    fileConfigOut.write(("HI_comida,"+getString(R.string.cnf_default_HF_0)+";").getBytes());
                    fileConfigOut.write(("HF_comida,"+getString(R.string.cnf_default_HI_1)+";").getBytes());
                    fileConfigOut.write(("ultimo_parte,0;").getBytes());
                    fileConfigOut.close();
                    PassingDAta.cnf_Nombre_operario=getString(R.string.cnf_default_operario);
                    PassingDAta.cnf_jornada_normal=getString(R.string.cnf_default_jornada_normal);
                    PassingDAta.cnf_HI_jornada=getString(R.string.cnf_default_HI_0);
                    PassingDAta.cnf_HI_comida=getString(R.string.cnf_default_HF_0);
                    PassingDAta.cnf_HF_comida=getString(R.string.cnf_default_HI_1);
                    PassingDAta.cnf_HF_jornada=getString(R.string.cnf_default_HF_1);
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            } else {
                try {
                    fileConfigIn =getActivity().openFileInput("configuration");
                    fileConfigIn.read(buffer);
                    fileConfigIn.close();
                    String bufferString = new String(buffer);
                    String[] bufferLines = bufferString.split(";");
                    for (String item:bufferLines) {
                        String[] bufferValues=item.split(",");
                        decodeConfigurationValue(bufferValues);
                    }

                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            //Calcular duracion de la mañana y tarde
            cal_Inicio_Jornada = Calendar.getInstance();
            cal_Fin_Jornada=Calendar.getInstance();
            cal_Inicio_Comida=Calendar.getInstance();
            cal_Fin_Comida=Calendar.getInstance();

            try {
                cal_Inicio_Jornada.setTime( sdf.parse(PassingDAta.cnf_HI_jornada));
                cal_Fin_Jornada.setTime( sdf.parse(PassingDAta.cnf_HF_jornada));
                cal_Inicio_Comida.setTime( sdf.parse(PassingDAta.cnf_HI_comida));
                cal_Fin_Comida.setTime( sdf.parse(PassingDAta.cnf_HF_comida));
            }
            catch (Exception e)
            {

            }
            cnf_mañana=cal_Inicio_Comida.getTimeInMillis()-cal_Inicio_Jornada.getTimeInMillis();
            cnf_tarde=cal_Fin_Jornada.getTimeInMillis()-cal_Fin_Jornada.getTimeInMillis();
        }

    }
    public void IniArchivoEnMemoriaParaDiaDeHoy ()
    {
        //Comprueba si hay un archivo en memoria para el dia de hoy
        NombreDeArchivo=FileHandling.getFileName(Calendar.getInstance());
        if(FileHandling.exist(NombreDeArchivo,getActivity().getBaseContext()))
        {
            Log.d("OnCreate","file for today exists");

            FH.LoadParteFromFileToClass(NombreDeArchivo,getActivity(),pdh);
            pdh.Fecha=sdf_date.format(myCalendar.getTime());
            ShowParteFromClass(pdh);
            ValidarTotalExtras();
            ValidarTotalNormales();
        }
        else
        {
            Log.d("OnCreate","file for today NOT exists");
            txtOperario.setText(PassingDAta.cnf_Nombre_operario);
            lblFecha.setText(sdf_date.format(myCalendar.getTime()));
            //txtNumeroParte.setText(""+(Integer.parseInt(PassingDAta.cnf_ultimo_parte)+1));
        }

    }
    private void updateFecha() {

        lblFecha.setText(sdf_date.format(myCalendar.getTime()));
    }
    private void updateOperario(){
        txtOperario.setText(PassingDAta.cnf_Nombre_operario);
    }
    protected void ClearParte()
    {
        AutoEditing = true;

        ((TextView)mainView.findViewById(R.id.HI_Extra1)).setText("");
        ((TextView)mainView.findViewById(R.id.HI_Extra2)).setText("");

        ((TextView)mainView.findViewById(R.id.HF_Extra1)).setText("");
        ((TextView)mainView.findViewById(R.id.HF_Extra2)).setText("");

        ((TextView)mainView.findViewById(R.id.Cliente_Extra1)).setText("");
        ((TextView)mainView.findViewById(R.id.Cliente_Extra2)).setText("");

        ((TextView)mainView.findViewById(R.id.Observaciones_Extra1)).setText("");
        ((TextView)mainView.findViewById(R.id.Observaciones_Extra2)).setText("");

        ((TextView)mainView.findViewById(R.id.lblTotal_Extra)).setText("");
        ((TextView)mainView.findViewById(R.id.txtNumero)).setText("");
        ((TextView)mainView.findViewById(R.id.txtFecha)).setText("");
        ((TextView)mainView.findViewById(R.id.txtOperario)).setText("");

        for(int i=0;i<HI_Norm.length;i++)
        {
            ((TextView)mainView.findViewById(HI_Norm[i])).setText("");
            ((TextView)mainView.findViewById(HF_Norm[i])).setText("");
            ((TextView)mainView.findViewById(Cliente_Norm[i])).setText("");
            ((TextView)mainView.findViewById(Observaciones_Norm[i])).setText("");
        }

        ((TextView)mainView.findViewById(R.id.lblTotal_Norm)).setText("");


        AutoEditing = false;
    }

    private void SaveParteOnClass ()
    {
        pdh.Clear();
        pdh.HI_Extra[0]=((TextView)mainView.findViewById(R.id.HI_Extra1)).getText().toString();
        pdh.HI_Extra[1]=((TextView)mainView.findViewById(R.id.HI_Extra2)).getText().toString();

        pdh.HF_Extra[0]=((TextView)mainView.findViewById(R.id.HF_Extra1)).getText().toString();
        pdh.HF_Extra[1]=((TextView)mainView.findViewById(R.id.HF_Extra2)).getText().toString();

        pdh.Cliente_Extra[0]=((TextView)mainView.findViewById(R.id.Cliente_Extra1)).getText().toString();
        pdh.Cliente_Extra[1]=((TextView)mainView.findViewById(R.id.Cliente_Extra2)).getText().toString();

        pdh.Observaciones_Extra[0]=((TextView)mainView.findViewById(R.id.Observaciones_Extra1)).getText().toString();
        pdh.Observaciones_Extra[1]=((TextView)mainView.findViewById(R.id.Observaciones_Extra2)).getText().toString();

        pdh.Total_Extra=((TextView)mainView.findViewById(R.id.lblTotal_Extra)).getText().toString();
        pdh.NumeroParte=((TextView)mainView.findViewById(R.id.txtNumero)).getText().toString();
        pdh.Fecha=((TextView)mainView.findViewById(R.id.txtFecha)).getText().toString();
        pdh.Operario=((TextView)mainView.findViewById(R.id.txtOperario)).getText().toString();

        for(int i=0;i<HI_Norm.length;i++)
        {
            pdh.HI_Norm[i]=((TextView)mainView.findViewById(HI_Norm[i])).getText().toString();
            pdh.HF_Norm[i]=((TextView)mainView.findViewById(HF_Norm[i])).getText().toString();
            pdh.Cliente_Norm[i]=((TextView)mainView.findViewById(Cliente_Norm[i])).getText().toString();
            pdh.Observaciones_Norm[i]=((TextView)mainView.findViewById(Observaciones_Norm[i])).getText().toString();
        }

        pdh.Total_Normales=((TextView)mainView.findViewById(R.id.lblTotal_Norm)).getText().toString();
    }
    protected void SaveParteOnClass (ParteDeHoras pdh)
    {
        pdh.Clear();
        pdh.HI_Extra[0]=((TextView)mainView.findViewById(R.id.HI_Extra1)).getText().toString();
        pdh.HI_Extra[1]=((TextView)mainView.findViewById(R.id.HI_Extra2)).getText().toString();

        pdh.HF_Extra[0]=((TextView)mainView.findViewById(R.id.HF_Extra1)).getText().toString();
        pdh.HF_Extra[1]=((TextView)mainView.findViewById(R.id.HF_Extra2)).getText().toString();

        pdh.Cliente_Extra[0]=((TextView)mainView.findViewById(R.id.Cliente_Extra1)).getText().toString();
        pdh.Cliente_Extra[1]=((TextView)mainView.findViewById(R.id.Cliente_Extra2)).getText().toString();

        pdh.Observaciones_Extra[0]=((TextView)mainView.findViewById(R.id.Observaciones_Extra1)).getText().toString();
        pdh.Observaciones_Extra[1]=((TextView)mainView.findViewById(R.id.Observaciones_Extra2)).getText().toString();

        pdh.Total_Extra=((TextView)mainView.findViewById(R.id.lblTotal_Extra)).getText().toString();
        pdh.NumeroParte=((TextView)mainView.findViewById(R.id.txtNumero)).getText().toString();
        pdh.Fecha=((TextView)mainView.findViewById(R.id.txtFecha)).getText().toString();
        pdh.Operario=((TextView)mainView.findViewById(R.id.txtOperario)).getText().toString();

        for(int i=0;i<HI_Norm.length;i++)
        {
            pdh.HI_Norm[i]=((TextView)mainView.findViewById(HI_Norm[i])).getText().toString();
            pdh.HF_Norm[i]=((TextView)mainView.findViewById(HF_Norm[i])).getText().toString();
            pdh.Cliente_Norm[i]=((TextView)mainView.findViewById(Cliente_Norm[i])).getText().toString();
            pdh.Observaciones_Norm[i]=((TextView)mainView.findViewById(Observaciones_Norm[i])).getText().toString();
        }

        pdh.Total_Normales=((TextView)mainView.findViewById(R.id.lblTotal_Norm)).getText().toString();
    }
    protected void ShowParteFromClass()
    {
        ShowParteFromClass(pdh);

    }

    protected void ShowParteFromClass( ParteDeHoras pdh)
    {
        AutoEditing=true;
        TextView comodin;
        comodin=(TextView)mainView.findViewById(R.id.HI_Extra1);
        comodin.setText(pdh.HI_Extra[0]);
        ResizeTextToFit(comodin);

        comodin=((TextView)mainView.findViewById(R.id.HI_Extra2));
        comodin.setText(pdh.HI_Extra[1]);
        ResizeTextToFit(comodin);

        comodin=((TextView)mainView.findViewById(R.id.HF_Extra1));
        comodin.setText(pdh.HF_Extra[0]);
        ResizeTextToFit(comodin);

        comodin=((TextView)mainView.findViewById(R.id.HF_Extra2));
        comodin.setText(pdh.HF_Extra[1]);
        ResizeTextToFit(comodin);

        ((TextView)mainView.findViewById(R.id.Cliente_Extra1)).setText( pdh.Cliente_Extra[0]);
        ((TextView)mainView.findViewById(R.id.Cliente_Extra2)).setText(pdh.Cliente_Extra[1]);

        ((TextView)mainView.findViewById(R.id.Observaciones_Extra1)).setText(pdh.Observaciones_Extra[0]);
        ((TextView)mainView.findViewById(R.id.Observaciones_Extra2)).setText(pdh.Observaciones_Extra[1]);

        ((TextView)mainView.findViewById(R.id.lblTotal_Extra)).setText(pdh.Total_Extra);
        ((TextView)mainView.findViewById(R.id.txtNumero)).setText(pdh.NumeroParte);
        ((TextView)mainView.findViewById(R.id.txtFecha)).setText(pdh.Fecha);
        ((TextView)mainView.findViewById(R.id.txtOperario)).setText(pdh.Operario);

        for(int i=0;i<HI_Norm.length;i++)
        {
            comodin=((TextView)mainView.findViewById(HI_Norm[i]));
            comodin.setText(pdh.HI_Norm[i]);
            ResizeTextToFit(comodin);

            comodin=((TextView)mainView.findViewById(HF_Norm[i]));
            comodin.setText(pdh.HF_Norm[i]);
            ResizeTextToFit(comodin);

            ((TextView)mainView.findViewById(Cliente_Norm[i])).setText(pdh.Cliente_Norm[i]);
            ((TextView)mainView.findViewById(Observaciones_Norm[i])).setText(pdh.Observaciones_Norm[i]);
        }

        ((TextView)mainView.findViewById(R.id.lblTotal_Norm)).setText(pdh.Total_Normales);
        AutoEditing=false;
    }
    //Calcula las horas extras y las presenta en el cuadro de texo correspondiente
    protected void ValidarTotalExtras() {
        long differ, differ2;
        TextView HI = (TextView) mainView.findViewById(R.id.HI_Extra1);
        TextView HF = (TextView) mainView.findViewById(R.id.HF_Extra1);
        autocorregirHora(HI, HF);
        differ = getDifferBetweenCelds(HF, HI);
        HI = (TextView) mainView.findViewById(R.id.HI_Extra2);
        HF = (TextView) mainView.findViewById(R.id.HF_Extra2);
        autocorregirHora(HI, HF);
        differ2 = getDifferBetweenCelds(HF, HI);

        differ3 = differ + differ2;


        TextView totExtra = (TextView) mainView.findViewById(R.id.lblTotal_Extra);
        str_differ = MiFecha.millisecondsToShortTime(differ3);

        if(differ3==0)totExtra.setText("");
        else totExtra.setText(str_differ);
    }
    protected void autocorregirHora(TextView HI, TextView HF) {
        Date date_HI, date_HF;
        //Corrige ortografia en HI
        String strHI = HI.getText().toString();
        strHI = strHI.replace('/', ':');
        strHI = strHI.replace('.', ':');
        strHI = strHI.replace('\'', ':');
        HI.setText(strHI);
        try {
            date_HI = sdf.parse(strHI);
        } catch (ParseException e) {
            e.printStackTrace();
            return;
        }
        HI.setText(sdf.format(date_HI));
        //Corrige ortografia en HF

        String strHF = HF.getText().toString();
        strHF = strHF.replace('/', ':');
        strHF = strHF.replace('.', ':');
        strHF = strHF.replace('\'', ':');
        HF.setText(strHF);

        try {
            date_HF = sdf.parse(strHF);
        } catch (ParseException e) {
            e.printStackTrace();
            return;
        }
        HF.setText(sdf.format(date_HF));

        if (date_HF.before(date_HI)) {
            Calendar cl_HI = Calendar.getInstance();
            Calendar cl_HF = Calendar.getInstance();
            cl_HI.setTime(date_HI);
            cl_HF.setTime(date_HF);

            //Solo corrige la hora final si la hora inicio es menor de las 12 del mediodia
            int a = cl_HI.get(Calendar.HOUR_OF_DAY);
            if (a <= 12) {
                if (cl_HF.get(Calendar.HOUR_OF_DAY) < cl_HI.get(Calendar.HOUR_OF_DAY)) {
                    cl_HF.set(Calendar.HOUR_OF_DAY, cl_HF.get(Calendar.HOUR_OF_DAY) + 12);
                    strHF = sdf.format(cl_HF.getTime());
                    HF.setText(strHF);
                }
            }
        }

    }
    //Calcula las horas normales y las presenta en el cuadro de texo correspondiente
    protected void ValidarTotalNormales() {
        TextView HI, HF;
        long differ = 0, differ2 = 0, total = 0;
        for (int index = 0; index < 8; index++) {

            HI = (TextView) mainView.findViewById(HI_Norm[index]);
            HF = (TextView) mainView.findViewById(HF_Norm[index]);
            autocorregirHora(HI, HF);
            differ = getDifferBetweenCelds(HF, HI);
            total += differ;
        }

        TextView totNorm = (TextView) mainView.findViewById(R.id.lblTotal_Norm);
        str_differ = MiFecha.millisecondsToShortTime(total);


        if(total==0)totNorm.setText("");
        else totNorm.setText(str_differ);

        SaveParteOnClass();
        if(!pdh.NothingToSave())
            FH.SaveParteFromClassToFile(getActivity(), pdh);
        else
            FH.EraseFile(pdh,getActivity().getBaseContext());
    }

    protected void decodeConfigurationValue(String[] line)
    {
        if (line==null)return;
        switch (line[0])
        {
            case "operario":
                if(line.length>0)
                    PassingDAta.cnf_Nombre_operario=line[1];
                break;
            case "jornada_normal":
                if(line.length>0)
                    PassingDAta.cnf_jornada_normal=line[1];
                break;
            case "HI_jornada":
                if(line.length>0)
                    PassingDAta.cnf_HI_jornada=line[1];
                break;
            case "HF_jornada":
                if(line.length>0)
                    PassingDAta.cnf_HF_jornada=line[1];
                break;
            case "HI_comida":
                if(line.length>0)
                    PassingDAta.cnf_HI_comida=line[1];
                break;
            case "HF_comida":
                if(line.length>0)
                    PassingDAta.cnf_HF_comida=line[1];
                break;
            case "ultimo_parte":
                if(line.length>0)
                    PassingDAta.cnf_ultimo_parte=line[1];
                break;
            default:
                break;
        }
    }
    protected long getDifferBetweenCelds(TextView HF, TextView HI) {
        cl_HI = Calendar.getInstance();
        cl_HF = Calendar.getInstance();
        cl_Medianoche = Calendar.getInstance();
        cl_Medianoche.set(Calendar.HOUR, 24);

        try {
            date_HI = sdf.parse(HI.getText().toString());
            date_HF = sdf.parse(HF.getText().toString());
            date_Medianoche = sdf.parse("24:00");
        } catch (ParseException e) {
            e.printStackTrace();
            return 0;
        }

        cl_HI.setTime(date_HI);
        cl_HF.setTime(date_HF);
        cl_Medianoche.setTime(date_Medianoche);
        f = cl_HF.getTimeInMillis();
        i = cl_HI.getTimeInMillis();
        m = cl_Medianoche.getTimeInMillis();
        if (f < i) {
            //Si la hora final es mayor que la hora inicial se presupone
            // trabajo nocturno
            differ2 = m - i;
            differ = f + differ2;
        } else {
            differ = f - i;
        }

        return differ;
    }
    OnFragmentInteractionListener mListener;
    interface OnFragmentInteractionListener {
        void onTestImterface(int choice);
    }
    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            throw new ClassCastException(context.toString()
                    + getResources().getString(R.string.exception_message));
        }
    }
    public void CargarPartePorFecha(Calendar fecha)
    {
        CargarPartePorFecha(
                fecha.get(Calendar.YEAR),
                fecha.get(Calendar.MONTH),
                fecha.get(Calendar.DAY_OF_MONTH)
        );
    }
    public void CargarPartePorFecha(int year,int mes,int dia)
    {

        // El cuadro de fecha controla el parte que se está viendo.
        //Cuando el usuario pulsa cambia de fecha,
        // el programa debe guardar el parte que esta haciendo
        // y cargar el parte de la nueva fecha seleccionada

        //primero guarda el trabajo hecho en la fecha que había en
        // el cuadro de la fecha
                SaveParteOnClass();
                if(!pdh.NothingToSave())
                    FH.SaveParteFromClassToFile(getActivity(), pdh);
                else
                    FH.EraseFile(pdh,getActivity().getBaseContext());
        // despues carga el archivo correspondiente a la nueva fecha
                myCalendar.set(Calendar.YEAR, year);
                myCalendar.set(Calendar.MONTH, mes);
                myCalendar.set(Calendar.DAY_OF_MONTH, dia);
                pdh.Clear();
                AutoEditing=true;
                if( FH.LoadParteFromFileToClass(myCalendar,getActivity(), pdh))
                {
                    ShowParteFromClass();
                    ValidarTotalExtras();
                    ValidarTotalNormales();
                }
                else
                {
                    ClearParte();
                }
                updateFecha();
                updateOperario();
                AutoEditing=false;
    }

    /**
     * Carga los campos del parte de horas presentado en pantalla con la informacion
     * del pdh_local. Excepto la fecha
     * @param pdh_local
     */
    public void CargarParte_desde_Parte(ParteDeHoras pdh_local) {

        if (pdh_local == null) return;

        pdh.Clear();
        AutoEditing = true;
        String fecha = pdh.Fecha;
        ParteDeHoras.CopyParte(pdh_local, pdh);
        pdh.Fecha=fecha;
        ShowParteFromClass();
        ValidarTotalExtras();
        ValidarTotalNormales();
        updateFecha();
        updateOperario();
        AutoEditing = false;
    }
    public ParteDeHoras GetParteDeHoras (ParteDeHoras pdh)
    {
        SaveParteOnClass(pdh);

        return pdh;
    }

}
