package com.orparga.partedehoras03;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.v4.app.DialogFragment;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;

public class Activity_Intent_CSV_Dialog_Cliente extends DialogFragment {

    Dialog thisDialog;

    /* The activity that creates an instance of this dialog fragment must
 * implement this interface in order to receive event callbacks.
 * Each method passes the DialogFragment in case the host needs to query it. */
    public interface NoticeDialogListener {
        public void onClienteSeleccionado(DialogFragment dialog);
        public void onClientePositiveClick(DialogFragment dialog);
        public void onClienteNegativeClick(DialogFragment dialog);
    }
    // Use this instance of the interface to deliver action events
    NoticeDialogListener mListener;// Override the Fragment.onAttach() method to instantiate the NoticeDialogListener
    @Override
    public void onAttach(Context activity) {
        super.onAttach(activity);
        // Verify that the host activity implements the callback interface
        try {
            // Instantiate the NoticeDialogListener so we can send events to the host
            mListener = (NoticeDialogListener) activity;
        } catch (ClassCastException e) {
            // The activity doesn't implement the interface, throw exception
            throw new ClassCastException(activity.toString()
                    + " must implement all interface methods");
        }
    }
    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        //Inicializar las variables que leerá la clase llamante "Activity_Intent_CSV" al finalizar
        PassingDAta.CSV_Dialog_Accept = false;

        // Use the Builder class for convenient dialog construction
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        // Get the layout inflater
        LayoutInflater inflater = getActivity().getLayoutInflater();
        // Inflate and set the layout for the dialog
        // Pass null as the parent view because its going in the dialog layout
        View prompView =inflater.inflate(R.layout.dialog_cliente, null);
        builder.setView(prompView);
        final EditText userInput=(EditText)prompView.findViewById(R.id.AIC_Cliente) ;
        userInput.setText(PassingDAta.CSV_Dialog_Cliente);
        //builder.setTitle(R.string.AIC_Cliente_Tittle);
        //builder.setMessage(R.string.AIC_Cliente_Message);
        builder.setPositiveButton(R.string.AIC_OK, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                // FIRE ZE MISSILES!
                PassingDAta.CSV_Dialog_Accept=true;
                PassingDAta.CSV_Dialog_Cliente=userInput.getText().toString();
                mListener.onClientePositiveClick(Activity_Intent_CSV_Dialog_Cliente.this);
            }
        });
        builder.setNegativeButton(R.string.AIC_Cancel, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                // Send the negative button event back to the host activity
                PassingDAta.CSV_Dialog_Accept=false;
                mListener.onClienteNegativeClick(Activity_Intent_CSV_Dialog_Cliente.this);
            }
        });
        // Create the AlertDialog object and return it
        thisDialog=builder.create();
        return thisDialog;
    }
}
