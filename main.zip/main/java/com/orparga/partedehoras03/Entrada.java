package com.orparga.partedehoras03;

import static com.orparga.partedehoras03.ParteDeHoras.*;

public class Entrada {

    public enum TipoDeHora {NORMAL,EXTRA};

    public String HI = "";
    public String HF = "";
    public String Cliente = "";
    public String Observaciones = "";

    public TipoDeHora tipoDeHora = TipoDeHora.NORMAL;

    public Entrada(String HI, String HF, String cliente, String observaciones, TipoDeHora tipoDeHora) {
        this.HI = HI;
        this.HF = HF;
        Cliente = cliente;
        Observaciones = observaciones;
        this.tipoDeHora = tipoDeHora;
    }

    public Entrada(String HI, String HF, String cliente, String observaciones) {
        this.HI = HI;
        this.HF = HF;
        Cliente = cliente;
        Observaciones = observaciones;
    }

    public Entrada() {
    }

    public long Intervalo_Milis() {
        return GetMillisFrom_IntervaloEntreHoras(HI, HF);
    }

    public void Fill(String HI, String HF, String cliente, String observaciones, TipoDeHora tipoDeHora) {
        this.HI = HI;
        this.HF = HF;
        Cliente = cliente;
        Observaciones = observaciones;
        this.tipoDeHora = tipoDeHora;
    }
}
