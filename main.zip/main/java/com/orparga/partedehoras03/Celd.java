package com.orparga.partedehoras03;


import org.json.JSONObject;

public class Celd{
    public String type;
    public String name;
    public int index;
    public double top;
    public double bottom;
    public double left;
    public double right;
    public boolean border;
    public Label label;
    public BackColor back_color;
    public BackColor border_color;

    public Celd (JSONObject objetoJSON) {
        try {
            type = objetoJSON.getString("type");
        } catch (Exception e) {
            e.printStackTrace();
        }
        try {
            name = objetoJSON.getString("name");
        } catch (Exception e) {
            e.printStackTrace();
        }
        try {
            top = objetoJSON.getDouble("top");
        } catch (Exception e) {
            e.printStackTrace();
        }
        try {
            index = objetoJSON.getInt("index");
        } catch (Exception e) {
            e.printStackTrace();
        }
        try {
            left = objetoJSON.getDouble("left");
        } catch (Exception e) {
            e.printStackTrace();
        }
        try {
            bottom = objetoJSON.getDouble("bottom");
        } catch (Exception e) {
            e.printStackTrace();
        }
        try {
            right = objetoJSON.getDouble("right");
        } catch (Exception e) {
            e.printStackTrace();
        }
        try {
            border = objetoJSON.getBoolean("border");
        } catch (Exception e) {
            e.printStackTrace();
        }
        try {
            back_color = new BackColor( objetoJSON.getJSONObject("background_color"));
        } catch (Exception e) {
            e.printStackTrace();
        }
        try {
            border_color = new BackColor( objetoJSON.getJSONObject("border_color"));
        } catch (Exception e) {
            e.printStackTrace();
        }
        try {
            label = new Label(objetoJSON.getJSONObject("label"));
        } catch (Exception e) {
            e.printStackTrace();
        }

    }
}