package com.orparga.partedehoras03;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class Box {

    public String name;
    public String type;
    public int index;
    public double top;
    public double bottom;
    public double left;
    public double right;
    public boolean border;
    public String text;
    public String file;
    public List<Column> columns;

    public Box(JSONObject objetoJSON) {
        JSONArray jsonArray;
        columns = new ArrayList<>();

        try {
            name = objetoJSON.getString("name");
            type= objetoJSON.getString("type");
            index=objetoJSON.getInt("index");
            top = objetoJSON.getDouble("top");
            left = objetoJSON.getDouble("left");
            bottom = objetoJSON.getDouble("bottom");
            right = objetoJSON.getDouble("right");
            border=objetoJSON.getBoolean("border");

            switch (type)
            {
                case "basic":
                    text=objetoJSON.getString("text");
                    break;
                case "table":
                    text="";
                    try {
                        jsonArray = objetoJSON.getJSONArray("columns");
                        for (int i = 0; i < jsonArray.length(); i++) {
                            columns.add(new Column(jsonArray.getJSONObject(i)));
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }

                    break;
                case "underline":
                    text=objetoJSON.getString("text");
                    break;
                case "picture":
                    text=objetoJSON.getString("text");
                    file=objetoJSON.getString("file");
                    break;
            }

        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
    }

}