package com.orparga.partedehoras03;

public class GleeoData {
    public static final int DOMAIN = 0;
    public static final int PROJECT = 1;
    public static final int TASK = 2;
    public static final int DETAILS = 3;
    public static final int START = 4;
    public static final int END = 5;
    public static final int TIMEZONE = 6;
    public static final int DURATION = 7;
    public static final int DECIMAL_DURATION = 8;
    public static final int PROJECT_EXTRA_1 = 9;
    public static final int PROJECT_EXTRA_2 = 10;
    public static final int TASK_EXTRA_1 = 11;
    public static final int TASK_EXTRA_2= 12;
}
