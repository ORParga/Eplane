package com.orparga.partedehoras03;

import org.json.JSONObject;

public class Label {
    public double top;
    public double bottom;
    public double left;
    public double right;
    public String text;

    public Label(JSONObject objetoJSON) {
        try {
            text = objetoJSON.getString("text");
        } catch (Exception e) {
            e.printStackTrace();
        }
        try {
            top = objetoJSON.getDouble("top");
        } catch (Exception e) {
            e.printStackTrace();
        }
        try {
            left = objetoJSON.getDouble("left");
        } catch (Exception e) {
            e.printStackTrace();
        }
        try {
            bottom = objetoJSON.getDouble("bottom");
        } catch (Exception e) {
            e.printStackTrace();
        }
        try {
            right = objetoJSON.getDouble("right");
        } catch (Exception e) {
            e.printStackTrace();
        }

    }
}
