package com.orparga.partedehoras03;


import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class Column {
    public String nombre;
    public String type;
    public int index;
    public List<Celd> celds;

    public Column(JSONObject objetoJSON) {
        JSONArray jsonArray;
        celds = new ArrayList<>();

        try {
            nombre = objetoJSON.getString("name");
        } catch (Exception e) {
            e.printStackTrace();
        }
        try {
            type = objetoJSON.getString("type");
        } catch (Exception e) {
            e.printStackTrace();
        }
        try {
            index = objetoJSON.getInt("index");
        } catch (Exception e) {
            e.printStackTrace();
        }
        try {
            jsonArray = objetoJSON.getJSONArray("celds");
            for (int i = 0; i < jsonArray.length(); i++) {
                celds.add(new Celd(jsonArray.getJSONObject(i)));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}