package com.orparga.partedehoras03;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;

import static com.orparga.partedehoras03.PassingDAta.cnf_Printer_margin_left;
import static com.orparga.partedehoras03.PassingDAta.cnf_Printer_margin_top;
import static com.orparga.partedehoras03.PassingDAta.cnf_Share_margin_left;
import static com.orparga.partedehoras03.PassingDAta.cnf_Share_margin_top;

public class CanvasParaParte extends Canvas {

    public enum TYPE {PRINTER, SHARE}

    ;
    public float scalePrint = 2.8f;
    public TYPE defaultType = TYPE.PRINTER;
    public Paint paint = new Paint();

    public CanvasParaParte(Bitmap bitmap) {
        super(bitmap);
        //paint=new Paint();
        paint.setStrokeWidth(1);
    }

    public void drawText(String text, double x, double y) {
        this.drawText(text, x, y, defaultType);
    }

    public void drawText(String text, double x, double y, TYPE type) {
        float left = 0, top = 0;
        switch (type) {
            case PRINTER:
                left = cnf_Printer_margin_left;
                top = cnf_Printer_margin_top;
                break;
            case SHARE:
                left = cnf_Share_margin_left;
                top = cnf_Share_margin_top;
                break;
        }
        this.drawText(text,
                left + ((float) x * scalePrint),
                top + ((float) y * scalePrint),
                paint);
    }

    public void drawLine(double x1, double y1, double x2) {
        drawLine(x1, y1, x2, defaultType);
    }

    public void drawLine(double x1, double y1, double x2, TYPE type) {
        float left = 0, top = 0;
        switch (type) {
            case PRINTER:
                left = cnf_Printer_margin_left;
                top = cnf_Printer_margin_top;
                break;
            case SHARE:
                left = cnf_Share_margin_left;
                top = cnf_Share_margin_top;
                break;
        }
        this.drawLine(
                left + ((float) x1 * scalePrint),
                top + ((float) y1 * scalePrint),
                left + ((float) x2 * scalePrint),
                top + ((float) y1 * scalePrint),
                paint);
    }

    public void drawTextCentered(String text, double left, double bottom, double right) {
        drawTextCentered(text, left, bottom, right, defaultType);
    }

    public void drawTextCentered(String text, double left, double bottom, double right, TYPE type) {
        Rect TextBounds = new Rect();

        float left_margin = 0, top_margin = 0;
        switch (type) {
            case PRINTER:
                left_margin = cnf_Printer_margin_left;
                top_margin = cnf_Printer_margin_top;
                break;
            case SHARE:
                left_margin = cnf_Share_margin_left;
                top_margin = cnf_Share_margin_top;
                break;
        }
        paint.getTextBounds(text, 0, text.length(), TextBounds);
        double middleCeld = ((right - left) / 2) + left;
        double middleText = TextBounds.centerX();
        this.drawText(
                text,
                left_margin + ((float) ((middleCeld) * scalePrint - middleText)),
                top_margin + ((float) (bottom - 1) * scalePrint),
                paint);
    }

    public void drawBox(Box box) {
        drawBox(box, defaultType);
    }

    public void drawBox(Box box, TYPE type) {

        float left_margin = 0, top_margin = 0;
        switch (type) {
            case PRINTER:
                left_margin = cnf_Printer_margin_left;
                top_margin = cnf_Printer_margin_top;
                break;
            case SHARE:
                left_margin = cnf_Share_margin_left;
                top_margin = cnf_Share_margin_top;
                break;
        }
        this.drawRect(
                ((float) box.left * scalePrint) + left_margin,
                ((float) box.top * scalePrint) + top_margin,
                ((float) box.right * scalePrint) + left_margin,
                ((float) box.bottom * scalePrint) + top_margin,
                this.paint);
    }
    public void drawBitmap(Box box,Bitmap bitmap)
    {
        drawBitmap(box,bitmap,defaultType);
    }
    public void drawBitmap(Box box,Bitmap bitmap,TYPE type)
    {
        float left = 0, top = 0;
        switch (type) {
            case PRINTER:
                left = cnf_Printer_margin_left;
                top = cnf_Printer_margin_top;
                break;
            case SHARE:
                left = cnf_Share_margin_left;
                top = cnf_Share_margin_top;
                break;
        }


        Rect rectDest = new Rect(
                (int) ((box.left * scalePrint) + left),
                (int) ((box.top * scalePrint) + top),
                (int) ((box.right * scalePrint) + left),
                (int) ((box.bottom * scalePrint) + top));
        Rect rectSrc = new Rect(0, 0, PassingDAta.instalferlogo.getWidth(), PassingDAta.instalferlogo.getHeight());
        this.drawBitmap(PassingDAta.instalferlogo, rectSrc, rectDest, this.paint);
    }
    public void drawCeld(Celd celd) {
        drawCeld(celd,defaultType);
    }
        public void drawCeld(Celd celd, TYPE type) {

        float left_margin = 0, top_margin = 0;
        switch (type) {
            case PRINTER:
                left_margin = cnf_Printer_margin_left;
                top_margin = cnf_Printer_margin_top;
                break;
            case SHARE:
                left_margin = cnf_Share_margin_left;
                top_margin = cnf_Share_margin_top;
                break;
        }
        this.drawRect(
                ((float) celd.left * scalePrint) + left_margin,
                ((float) celd.top * scalePrint) + top_margin,
                ((float) celd.right * scalePrint) + left_margin,
                ((float) celd.bottom * scalePrint) + top_margin,
                this.paint);
    }
}
