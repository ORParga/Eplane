package com.orparga.partedehoras03;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.support.v7.app.AppCompatActivity;
import android.view.View;

/**
 * Created by OSCAR on 21/04/2018.
 */
public class PassingDAta {

    //Globales
    static boolean cnf_primeraVez=false;
    static boolean cnf_algoFallo=false;
    static String cnf_Nombre_operario="Oscar Rodriguez";
    static String cnf_jornada_normal;
    static String cnf_HI_jornada;
    static String cnf_HF_jornada;
    static String cnf_HI_comida;
    static String cnf_HF_comida;
    static String cnf_ultimo_parte="0";
    static String cnf_cliente_usual="";
    static String cnf_tarea_usual="Taller";
    static Bitmap instalferlogo;

    //Activity Autocompletar
    static String fill_hora_inicio="";
    static String fill_hora_salida="";
    static String fill_cliente="";
    static String fill_tareas="";
    static boolean fill_ok_pressed=false;

    //Activity Moth
    static int NDaysSelected=0;
    static String fileNameSelected="";
    static int SelectedDayOfMonth;
    static int SelectedMonth;
    static int SelectedYear;
    static boolean thereIsAnyDayClicked=false;

    //interaccion entre Activities
    public enum fromActivityEnum {None,Main,Autofill,Month,Intent_CSV,Send_to_Instalfer};
    static public fromActivityEnum fromActivity=fromActivityEnum.None;

    //Impresora
    static float cnf_Printer_margin_left=-30;
    static float cnf_Printer_margin_top=-9;
    static float cnf_Printer_scalePrint=2.8f;
    static float cnf_Printer_margin_left_default=-30;
    static float cnf_Printer_margin_top_default=-9;
    static float cnf_Printer_scalePrint_default=2.8f;
        public enum whatPrintEnum{All,JustData};
        static public whatPrintEnum WhatPrint=whatPrintEnum.JustData;
    public static float scalePrint_pdf=2.8f;
    public static float scalePrint_bmp=1f;

        //Initial State
        static float InitialTextSize=0;

        //Gleeo compativility
        static Intent gleeo_Intent;

        //Sharing ParteDeHoras
        static String[] FileNameArray=new String[31];
    static float cnf_ParteWidth_Bitmap=500;
    public static float cnf_ParteWidth_default =500;
    static float cnf_ParteHeight_Bitmap=500;
    static float cnf_Share_margin_left=-9;
    static float cnf_Share_margin_top=0;
    static AppCompatActivity activity;

    //Copying ParteDeHoras
    private static ParteDeHoras ParteInClipboard=new ParteDeHoras();
    public static ParteDeHoras ParteReturned=new ParteDeHoras();
    //Activity_Intent_CSV_Dialog_HN_HX
    static View CSV_View_Clicked;
    public enum HX_HN {HX,HN};
    static boolean CSV_Dialog_Accept=false;
    static HX_HN CSV_Dialog_HX_HN=HX_HN.HN;
    static String CSV_Dialog_Cliente="";
    static String CSV_Dialog_Trabajo="";
    static int CSV_Dialog_hour=0;
    static int CSV_Dialog_minute=0;

    static void Load_SharedPreferences (Context context){
        SharedPreferences sp= context.getSharedPreferences("config",Context.MODE_PRIVATE);
        cnf_Printer_margin_left = sp.getFloat("cnf_Printer_margin_left", cnf_Printer_margin_left_default);
        cnf_Printer_margin_top = sp.getFloat("cnf_Printer_margin_top", cnf_Printer_margin_top_default);
        cnf_Printer_scalePrint = sp.getFloat("cnf_scalePrint", cnf_Printer_scalePrint_default);

    }
    static void Save_SharedPreferences (Context context){
        SharedPreferences sp= context.getSharedPreferences("config",Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sp.edit();
        editor.putFloat("cnf_Printer_margin_left", cnf_Printer_margin_left);
        editor.putFloat("cnf_Printer_margin_top", cnf_Printer_margin_top);
        editor.putFloat("cnf_scalePrint", cnf_Printer_scalePrint);
        editor.commit();
    }

    static void SendParteToClipboard(ParteDeHoras parte)
    {
        ParteDeHoras.CopyParte(parte,ParteInClipboard);
    }
    static ParteDeHoras GetParteFromClipboard(){

        if(ParteDeHoras.CopyParte(ParteInClipboard,ParteReturned)==null)return null;
        return ParteReturned;
    }
    static boolean ThereIsParteInClipboard (){
        if(ParteInClipboard==null)return false;
        return true;
    }
}
