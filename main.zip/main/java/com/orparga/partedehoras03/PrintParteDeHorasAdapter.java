package com.orparga.partedehoras03;

import android.app.Activity;
import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.os.Bundle;
import android.os.CancellationSignal;
import android.os.ParcelFileDescriptor;
import android.print.PageRange;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.graphics.pdf.PdfDocument;
import android.print.PrintDocumentInfo;
import android.print.pdf.PrintedPdfDocument;
import android.view.View;
import android.widget.Button;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.StringWriter;
import java.io.UnsupportedEncodingException;
import java.io.Writer;
import java.util.ArrayList;
import java.util.List;

import static com.orparga.partedehoras03.PassingDAta.WhatPrint;
import static com.orparga.partedehoras03.PassingDAta.cnf_Printer_margin_left;
import static com.orparga.partedehoras03.PassingDAta.cnf_Printer_margin_top;

public class PrintParteDeHorasAdapter extends PrintDocumentAdapter {

    Context context;
    private int pageHeight;
    private int pageWidth;
    private int PrinterMarginTop= 0;
    private int PrinterMarginLeft= 0;
    private float scalePrint=PassingDAta.cnf_Printer_scalePrint;
    private ParteDeHoras sPDH;

    private Paint g_paint;
    private Canvas g_printerCanvas;

    public PdfDocument myPdfDocument;

    public class Picture{
        public String type;
        public String name;
        public int index;
        public double top;
        public double bottom;
        public double left;
        public double right;
        public boolean border;
        public String text;
        public String file;

        public Picture (JSONObject objetoJSON) {
            try {
                type = objetoJSON.getString("type");
            } catch (Exception e) {
                e.printStackTrace();
            }
            try {
                name = objetoJSON.getString("name");
            } catch (Exception e) {
                e.printStackTrace();
            }
            try {
                top = objetoJSON.getDouble("top");
            } catch (Exception e) {
                e.printStackTrace();
            }
            try {
                index = objetoJSON.getInt("index");
            } catch (Exception e) {
                e.printStackTrace();
            }
            try {
                left = objetoJSON.getDouble("left");
            } catch (Exception e) {
                e.printStackTrace();
            }
            try {
                bottom = objetoJSON.getDouble("bottom");
            } catch (Exception e) {
                e.printStackTrace();
            }
            try {
                right = objetoJSON.getDouble("right");
            } catch (Exception e) {
                e.printStackTrace();
            }
            try {
                border = objetoJSON.getBoolean("border");
            } catch (Exception e) {
                e.printStackTrace();
            }
            try{
                text=objetoJSON.getString("text");
            }
            catch (Exception e)
            {
                e.printStackTrace();
            }
            try{
                file=objetoJSON.getString("file");
            }
            catch (Exception e)
            {
                e.printStackTrace();
            }

        }
    }
    public PrintParteDeHorasAdapter(Context context,ParteDeHoras PDH)
    {
        this.context = context;
        this.sPDH=PDH;
    }

    @Override
    public void onLayout(PrintAttributes oldAttributes, PrintAttributes newAttributes, CancellationSignal cancellationSignal, LayoutResultCallback callback, Bundle bundle) {

        myPdfDocument = new PrintedPdfDocument(context, newAttributes);

        pageHeight =
                newAttributes.getMediaSize().getHeightMils()/1000 * 72;
        pageWidth =
                newAttributes.getMediaSize().getWidthMils()/1000 * 72;

        int topMils=newAttributes.getMinMargins().getTopMils();
        int bottomMils=newAttributes.getMinMargins().getBottomMils();
        int rightMils=newAttributes.getMinMargins().getRightMils();
        int leftMils=newAttributes.getMinMargins().getLeftMils();
        if (cancellationSignal.isCanceled() ) {
            callback.onLayoutCancelled();
            return;
        }


        PrintDocumentInfo.Builder builder = new PrintDocumentInfo
                .Builder("print_output.pdf")
                .setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT)
                .setPageCount(2);

        PrintDocumentInfo info = builder.build();
        callback.onLayoutFinished(info, true);
    }

    @Override
    public void onWrite(PageRange[] pageRanges, ParcelFileDescriptor destination, CancellationSignal cancellationSignal, WriteResultCallback writeResultCallback) {


        PdfDocument.PageInfo newPage = new PdfDocument.PageInfo.Builder(pageWidth,
                pageHeight, 1).create();

        PdfDocument.Page page =
                myPdfDocument.startPage(newPage);

        if (cancellationSignal.isCanceled()) {
            writeResultCallback.onWriteCancelled();
            myPdfDocument.close();
            myPdfDocument = null;
            return;
        }
        drawPage(page);
        myPdfDocument.finishPage(page);

        try {
            myPdfDocument.writeTo(new FileOutputStream(
                    destination.getFileDescriptor()));
        } catch (IOException e) {
            writeResultCallback.onWriteFailed(e.toString());
            return;
        } finally {
            myPdfDocument.close();
            myPdfDocument = null;
        }

        writeResultCallback.onWriteFinished(pageRanges);
    }

    private void drawPage(PdfDocument.Page page)
    {
        Canvas canvas = page.getCanvas();

        Paint paint = new Paint();

        PassingDAta.WhatPrint= PassingDAta.whatPrintEnum.JustData;
        PrintParteUsingJsonFile(paint,canvas);

    }

    /**
     * Test de uso de archivo Json
     * Carga desde el recurso R.raw.instalfer_parte_atributes un archivo Json
     * con un listado de areas de formulario (celdas, columnas, tablas, etc...)
     * y guarda sus elementos en un ArrayList "lista_box"
     * Despues dibuja estas areas en el objeto "paint" que recibe el metodo,
     * para acabar transfiriendolo al objeto printerCanvas
     * @param paint
     * @param printerCanvas
     */
    private void TestUsingJsonFile(Paint paint,Canvas printerCanvas) {

        JSONObject object;
        JSONArray json_array=new JSONArray();

        //Load Json resource

        InputStream is = context.getResources().openRawResource(R.raw.instalfer_parte_atributes);
        Writer writer = new StringWriter();
        char[] buffer = new char[1024];
        try {
            Reader reader = new BufferedReader(new InputStreamReader(is, "UTF-8"));
            int n;
            while ((n = reader.read(buffer)) != -1) {
                writer.write(buffer, 0, n);
            }
            is.close();
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        String jsonString = writer.toString();


        List<Box> lista_box = new ArrayList<>(); //inicializamos la lista donde almacenaremos los objetos

        try {
            object = new JSONObject(jsonString); //Creamos un objeto JSON a partir de la cadena
            json_array = object.optJSONArray("boxes"); //cogemos cada uno de los elementos dentro de la etiqueta "boxes"

            for (int i = 0; i < json_array.length(); i++) {
                lista_box.add(new Box(json_array.getJSONObject(i))); //creamos un objeto Box y lo insertamos en la lista
            }
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        //*********Busqueda dentro del Objeto json********************************
        paint.setStrokeWidth(1);

        for(int i=0;i<lista_box.size();i++)
        {
            Box box=lista_box.get(i);
            switch (box.type) {
                case "basic":
                    PrintParteDeHorasAdapter.setTextSizeForWidth(paint,((float)box.right*scalePrint)-((float)box.left*scalePrint),box.text);
                    paint.setStrokeWidth(0.1f);
                    paint.setStyle(Paint.Style.FILL);
                    paint.setColor(Color.BLACK);
                    printerCanvas.drawText(box.text,(int)box.left*scalePrint,(int)box.bottom*scalePrint,paint);
                    break;
                case "underline":
                    paint.setStrokeWidth(0.05f);
                    paint.setStyle(Paint.Style.STROKE);
                    paint.setColor(Color.BLACK);
                    printerCanvas.drawLine((float)box.left*scalePrint,(float)box.bottom*scalePrint,(float)box.right*scalePrint,(float)box.bottom*scalePrint,paint);
                    break;
                case "table":
                    paint.setStrokeWidth(0.5f);
                    paint.setStyle(Paint.Style.STROKE);
                    paint.setColor(Color.BLACK);
                    printerCanvas.drawRect(
                            (float)box.left*scalePrint,
                            (float)box.top*scalePrint,
                            (float)box.right*scalePrint,
                            (float)box.bottom*scalePrint,
                            paint);
                    Column column;
                    paint.setStrokeWidth(0.2f);
                    for (int j=0;j<box.columns.size();j++)
                    {
                        column=box.columns.get(j);
                        Celd celd;
                        int k=0;
                        for(k=0;k<column.celds.size();k++)
                        {
                            celd=column.celds.get(k);
                            paint.setStyle(Paint.Style.FILL);
                            //paint.setColor(Color.BLUE);
                            paint.setColor(Color.rgb(celd.back_color.red,celd.back_color.green,celd.back_color.blue));
                            printerCanvas.drawRect(
                                    (float)celd.left*scalePrint,
                                    (float)celd.top*scalePrint,
                                    (float)celd.right*scalePrint,
                                    (float)celd.bottom*scalePrint,
                                    paint);
                            paint.setColor(Color.rgb(celd.border_color.red,celd.border_color.green,celd.border_color.blue));
                            paint.setStyle(Paint.Style.STROKE);
                            printerCanvas.drawRect(
                                    (float)celd.left*scalePrint,
                                    (float)celd.top*scalePrint,
                                    (float)celd.right*scalePrint,
                                    (float)celd.bottom*scalePrint,
                                    paint);
                            paint.setColor(Color.BLACK);
                            paint.setStyle(Paint.Style.FILL);
                            if(!celd.label.text.equals("")) {
//                                PrintParteDeHorasAdapter.setTextSizeForWidth(
//                                        paint,
//                                        ((float) celd.label.right * scalePrint) - ((float) celd.label.left * scalePrint),
//                                        celd.label.text);
                                printerCanvas.drawText(
                                        celd.label.text,
                                        (float)celd.label.left*scalePrint,
                                        (float)celd.label.bottom*scalePrint,
                                        paint);
                            }
                        }
                    }
                    break;
                case "picture":
                    Bitmap b= BitmapFactory.decodeResource(context.getResources(), R.drawable.instalferlogo);
                    if(b!=null) {
                        Rect rectDest = new Rect((int) (box.left * scalePrint), (int) (box.top * scalePrint), (int) (box.right * scalePrint), (int) (box.bottom * scalePrint));
                        Rect rectSrc = new Rect(0, 0, b.getWidth(), b.getHeight());
                        printerCanvas.drawBitmap(b, rectSrc, rectDest, paint);
                    }
                    break;
            }
        }

    }
    /**
     * Prepara la impresion de un Parte de Horas
     * Carga desde el recurso R.raw.instalfer_parte_atributes un archivo Json
     * con un listado de areas de formulario (celdas, columnas, tablas, etc...)
     * y guarda sus elementos en un ArrayList "lista_box"
     * @param paint
     * @param printerCanvas
     */
    private void PrintParteUsingJsonFile(Paint paint,Canvas printerCanvas) {
        JSONObject object;
        JSONArray json_array=new JSONArray();

        g_paint=paint;
        g_printerCanvas=printerCanvas;

        String FieldContent;
        Rect TextBounds=new Rect();
        Rect TextCentereds=new Rect();

        //Load Json resource****************************************************************************************************
        //**********************************************************************************************************************
        InputStream is = context.getResources().openRawResource(R.raw.instalfer_parte_atributes);
        Writer writer = new StringWriter();
        char[] buffer = new char[1024];
        try {
            Reader reader = new BufferedReader(new InputStreamReader(is, "UTF-8"));
            int n;
            while ((n = reader.read(buffer)) != -1) {
                writer.write(buffer, 0, n);
            }
            is.close();
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        String jsonString = writer.toString();


        List<Box> lista_box = new ArrayList<>(); //inicializamos la lista donde almacenaremos los objetos

        try {
            object = new JSONObject(jsonString); //Creamos un objeto JSON a partir de la cadena
            json_array = object.optJSONArray("boxes"); //cogemos cada uno de los elementos dentro de la etiqueta "boxes"

            for (int i = 0; i < json_array.length(); i++) {
                lista_box.add(new Box(json_array.getJSONObject(i))); //creamos un objeto Box y lo insertamos en la lista
            }
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        paint.setStrokeWidth(1);

        //Preparar el parte de horas********************************************************************************************
        //**********************************************************************************************************************
        sPDH.LoadFields();


        //*********Dibujar el parte en  el objeto paint**************************************************************************
        // **********************************************************************************************************************

        float t= cnf_Printer_margin_top;
        float l= cnf_Printer_margin_left;
        for(int i=0;i<lista_box.size();i++)
        {
            Box box=lista_box.get(i);
            switch (box.type) {
                case "basic":
                    if(WhatPrint== PassingDAta.whatPrintEnum.All) {
                    PrintParteDeHorasAdapter.setTextSizeForWidth(paint,((float)box.right*scalePrint)-((float)box.left*scalePrint),box.text);
                    g_paint.setStrokeWidth(0.1f);
                    g_paint.setStyle(Paint.Style.FILL);
                    g_paint.setColor(Color.BLACK);
                        drawText(box.text, box.left, box.bottom);
                    }
                    break;
                case "underline":
                    g_paint.setStrokeWidth(0.05f);
                    g_paint.setColor(Color.BLACK);
                    if(WhatPrint== PassingDAta.whatPrintEnum.All) {
                        g_paint.setStyle(Paint.Style.STROKE);
                        drawLine(box.left, box.bottom, box.right);
                    }
                    g_paint.setStyle(Paint.Style.FILL);
                    if(!box.text.equals("")) {
                        if(WhatPrint== PassingDAta.whatPrintEnum.All) {
                            PrintParteDeHorasAdapter.setTextSizeForWidth(paint, ((float) box.right * scalePrint) - ((float) box.left * scalePrint), box.text);
                            drawText(box.text, box.left, box.bottom);
                        }
                    }
                    else {
                        FieldContent=sPDH.GetFieldContent(box.name, box.index);

                        if(!FieldContent.equals("")) {
                            drawTextCentered(FieldContent,box.left,box.bottom,box.right);
                        }

                    }
                    break;
                case "table":
                    paint.setStrokeWidth(0.5f);
                    paint.setColor(Color.BLACK);
                    paint.setStyle(Paint.Style.STROKE);
                    if(WhatPrint== PassingDAta.whatPrintEnum.All) {
                        printerCanvas.drawRect(
                                ((float) box.left * scalePrint) + cnf_Printer_margin_left,
                                ((float) box.top * scalePrint) + cnf_Printer_margin_top,
                                ((float) box.right * scalePrint) + cnf_Printer_margin_left,
                                ((float) box.bottom * scalePrint) + cnf_Printer_margin_top,
                                paint);
                    }
                    Column column;
                    paint.setStrokeWidth(0.2f);
                    for (int j=0;j<box.columns.size();j++)
                    {
                        column=box.columns.get(j);
                        Celd celd;
                        int k=0;
                        for(k=0;k<column.celds.size();k++)
                        {
                            celd=column.celds.get(k);
                            paint.setStyle(Paint.Style.FILL);
                            //Color de la linea de contorno del recuadro
                            paint.setColor(Color.rgb(celd.back_color.red,celd.back_color.green,celd.back_color.blue));

                            if(WhatPrint== PassingDAta.whatPrintEnum.All) {
                                printerCanvas.drawRect(
                                        ((float) celd.left * scalePrint) + cnf_Printer_margin_left,
                                        ((float) celd.top * scalePrint) + cnf_Printer_margin_top,
                                        ((float) celd.right * scalePrint) + cnf_Printer_margin_left,
                                        ((float) celd.bottom * scalePrint) + cnf_Printer_margin_top,
                                        paint);
                            }
                            //Color del relleno del recuadro
                            paint.setColor(Color.rgb(celd.border_color.red,celd.border_color.green,celd.border_color.blue));
                            paint.setStyle(Paint.Style.STROKE);

                            if(WhatPrint== PassingDAta.whatPrintEnum.All) {
                                printerCanvas.drawRect(
                                        ((float) celd.left * scalePrint) + cnf_Printer_margin_left,
                                        ((float) celd.top * scalePrint) + cnf_Printer_margin_top,
                                        ((float) celd.right * scalePrint) + cnf_Printer_margin_left,
                                        ((float) celd.bottom * scalePrint) + cnf_Printer_margin_top,
                                        paint);
                            }
                            //Color del texto
                            paint.setColor(Color.BLACK);
                            paint.setStyle(Paint.Style.FILL);
                            if(!celd.label.text.equals("")) {

                                if(WhatPrint== PassingDAta.whatPrintEnum.All) {
                                    drawText(
                                            celd.label.text,
                                            (float) celd.label.left,
                                            (float) celd.label.bottom);
                                }
                            }
                            else {
                                FieldContent=sPDH.GetFieldContent(celd.name, celd.index);

                                if(!FieldContent.equals("")) {
                                    drawTextCentered(FieldContent,celd.left,celd.bottom-1,celd.right);
//                                    paint.getTextBounds(FieldContent,0,FieldContent.length(),TextBounds);
//                                    double middleCeld = ((celd.right - celd.left) / 2) + celd.left;
//                                    double middleText = TextBounds.centerX();
//                                    printerCanvas.drawText(
//                                            FieldContent,
//                                            (float) ((middleCeld + 1) * scalePrint - middleText),
//                                            (float) (celd.bottom - 1) * scalePrint,
//                                            paint);
                                }

                            }
                        }
                    }
                    break;
                case "picture":

                    if(WhatPrint== PassingDAta.whatPrintEnum.All) {
                        if (PassingDAta.instalferlogo != null) {
                            Rect rectDest = new Rect(
                                    (int) ((box.left * scalePrint) + cnf_Printer_margin_left),
                                    (int) ((box.top * scalePrint) + cnf_Printer_margin_top),
                                    (int) ((box.right * scalePrint) + cnf_Printer_margin_left),
                                    (int) ((box.bottom * scalePrint) + cnf_Printer_margin_top));
                            Rect rectSrc = new Rect(0, 0, PassingDAta.instalferlogo.getWidth(), PassingDAta.instalferlogo.getHeight());
                            printerCanvas.drawBitmap(PassingDAta.instalferlogo, rectSrc, rectDest, paint);
                        }
                    }
                    break;
            }
        }

    }
    /**
     * Dibuja un parte de Horas en el Canvas.
     * @param paint objeto paint con las propiedades del dibujo.
     * @param printerCanvas objeto canvasdende se dibujar&aacute; el parte de Horas.
     */
    /**
     * Sets the text size for a Paint object so a given string of text will be a
     * given width.
     *
     * @param paint
     *            the Paint to set the text size for
     * @param desiredWidth
     *            the desired width
     * @param text
     *            the text that should be that width
     */
    private static void setTextSizeForWidth(Paint paint, float desiredWidth,
                                            String text) {

        // Pick a reasonably large value for the test. Larger values produce
        // more accurate results, but may cause problems with hardware
        // acceleration. But there are workarounds for that, too; refer to
        // http://stackoverflow.com/questions/6253528/font-size-too-large-to-fit-in-cache
        final float testTextSize = 16f;

        // Get the bounds of the text, using our testTextSize.
        paint.setTextSize(testTextSize);
        Rect bounds = new Rect();
        paint.getTextBounds(text, 0, text.length(), bounds);

        // Calculate the desired size as a proportion of our testTextSize.
        float desiredTextSize = testTextSize * desiredWidth / bounds.width();

        // Set the paint for that size.
        paint.setTextSize(desiredTextSize);
    }


     void drawText(String text,double x,double y)
    {
        g_printerCanvas.drawText(text,
                cnf_Printer_margin_left+((float)x*scalePrint),
                cnf_Printer_margin_top+((float)y*scalePrint),
                g_paint);
    }
    void drawLine(double x1,double y1,double x2) {
        g_printerCanvas.drawLine(
                cnf_Printer_margin_left + ((float)x1 * scalePrint),
                cnf_Printer_margin_top + ((float)y1 * scalePrint),
                cnf_Printer_margin_left + ((float)x2 * scalePrint),
                cnf_Printer_margin_top + ((float)y1 * scalePrint),
                g_paint);
    }
    void drawTextCentered (String text,double left,double bottom,double right) {
        Rect TextBounds=new Rect();

        g_paint.getTextBounds(text, 0, text.length(), TextBounds);
        double middleCeld = ((right - left) / 2) + left;
        double middleText = TextBounds.centerX();
        g_printerCanvas.drawText(
                text,
                cnf_Printer_margin_left +((float) ((middleCeld) * scalePrint - middleText)),
                cnf_Printer_margin_top +((float) (bottom - 1) * scalePrint),
                g_paint);
    }
    void drawTextCenteredAndResized (String text,double left,double bottom,double right) {
        Rect TextBounds=new Rect();

        float oldSize=g_paint.getTextSize();
        setTextSizeForWidth(g_paint,((float)right*scalePrint)-((float)left*scalePrint),text);
        g_paint.getTextBounds(text, 0, text.length(), TextBounds);
        double middleCeld = ((right - left) / 2) + left;
        double middleText = TextBounds.centerX();
        g_printerCanvas.drawText(
                text,
                cnf_Printer_margin_left +((float) ((middleCeld) * scalePrint - middleText)),
                cnf_Printer_margin_top +((float) (bottom - 1) * scalePrint),
                g_paint);
        g_paint.setTextSize(oldSize);
    }
}
