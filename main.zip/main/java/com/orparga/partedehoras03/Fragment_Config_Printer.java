package com.orparga.partedehoras03;

import android.content.Context;
import android.os.Bundle;
import android.os.Debug;
import android.print.PrintManager;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.text.Editable;
import android.text.TextWatcher;
import android.text.method.BaseKeyListener;
import android.text.method.KeyListener;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class Fragment_Config_Printer extends Fragment {
    Fragment_Config_Printer fragment;
    View view;
    EditText offxetX=null,offxetY=null,scale=null;
    float Last_valid_offsetX=PassingDAta.cnf_Printer_margin_left,Last_valid_offsetY=PassingDAta.cnf_Printer_margin_top,Last_valid_scale=PassingDAta.cnf_Printer_scalePrint;
    float Original_offsetX=PassingDAta.cnf_Printer_margin_left,Original_offsetY=PassingDAta.cnf_Printer_margin_top,Original_scale=PassingDAta.cnf_Printer_scalePrint;

    View.OnClickListener onClickListener_Test=new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            ParteDeHoras pdh=new ParteDeHoras();
            fragment.GetParteDeHoras(pdh);
            android.print.PrintManager printManager = (PrintManager) fragment.getContext()
                    .getSystemService(Context.PRINT_SERVICE);

            String jobName = fragment.getContext().getString(R.string.app_name) +
                    " Document";

            printManager.print(jobName, new PrintParteDeHorasAdapter(fragment.getContext(),pdh),
                    null);
        }
    };

    View.OnClickListener onClickListener_Restore=new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            if(offxetX!=null)
            {
                offxetX.setText(Float.toString(Original_offsetX));
                Last_valid_offsetX=Original_offsetX;
                PassingDAta.cnf_Printer_margin_left=Original_offsetX;
                offxetX.invalidate();
            }
            if(offxetY!=null)
            {
                offxetY.setText(Float.toString(Original_offsetY));
                Last_valid_offsetY=Original_offsetY;
                PassingDAta.cnf_Printer_margin_top=Original_offsetY;
                offxetY.invalidate();
            }
            if(scale!=null)
            {
                scale.setText(Float.toString(Original_scale));
                Last_valid_scale=Original_scale;
                PassingDAta.cnf_Printer_scalePrint=Original_scale;
                scale.invalidate();
            }
        }
    };
    View.OnClickListener onClickListener_Defaults= new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            if(offxetX!=null)
            {
                offxetX.setText(Float.toString(PassingDAta.cnf_Printer_margin_left_default));
                Last_valid_offsetX=PassingDAta.cnf_Printer_margin_left_default;
                PassingDAta.cnf_Printer_margin_left=PassingDAta.cnf_Printer_margin_left_default;
                offxetX.invalidate();
            }
            if(offxetY!=null)
            {
                offxetY.setText(Float.toString(PassingDAta.cnf_Printer_margin_top_default));
                Last_valid_offsetY=PassingDAta.cnf_Printer_margin_top_default;
                PassingDAta.cnf_Printer_margin_top=PassingDAta.cnf_Printer_margin_top_default;
                offxetY.invalidate();
            }
            if(offxetY!=null)
            {
                scale.setText(Float.toString(PassingDAta.cnf_Printer_scalePrint_default));
                Last_valid_scale=PassingDAta.cnf_Printer_scalePrint_default;
                PassingDAta.cnf_Printer_scalePrint=PassingDAta.cnf_Printer_scalePrint_default;
                scale.invalidate();
            }

        }
    };
    View.OnClickListener onClickListener_Aceptar=new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            PassingDAta.Save_SharedPreferences(getContext());
            getActivity().finish();
        }
    };
    View.OnClickListener onClickListener_Cancelar=new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            PassingDAta.cnf_Printer_margin_left=Original_offsetX;
            PassingDAta.cnf_Printer_margin_top=Original_offsetY;
            PassingDAta.cnf_Printer_scalePrint=Original_scale;
        }
    };
    TextWatcher textWatcherX=new TextWatcher() {

        @Override
        public void afterTextChanged(Editable s) {
        }

        @Override
        public void beforeTextChanged(CharSequence s, int start,
                                      int count, int after) {
        }

        @Override
        public void onTextChanged(CharSequence s, int start,
                                  int before, int count) {
            float new_offsetX;
            if(offxetX==null)return;
            Log.d("Fragment_Config_Printer", "Text changued:" + offxetX.getText());
            try {
                new_offsetX = Float.parseFloat(offxetX.getText().toString());
            }
            catch (NumberFormatException e){
                new_offsetX=0;
                offxetX.setText(Float.toString(0));
            }
            Last_valid_offsetX=new_offsetX;
            PassingDAta.cnf_Printer_margin_left=Last_valid_offsetX;
        }
    };
    TextWatcher textWatcherY=new TextWatcher() {

        @Override
        public void afterTextChanged(Editable s) {
        }

        @Override
        public void beforeTextChanged(CharSequence s, int start,
                                      int count, int after) {
        }

        @Override
        public void onTextChanged(CharSequence s, int start,
                                  int before, int count) {
            float new_offsetY;
            if(offxetY==null)return;
            Log.d("Fragment_Config_Printer", "Text changued:" + offxetY.getText());
            try {
                new_offsetY = Float.parseFloat(offxetY.getText().toString());
            }
            catch (NumberFormatException e){
                offxetY.setText(Float.toString(0));
                new_offsetY=0;
            }
            Last_valid_offsetY=new_offsetY;
            PassingDAta.cnf_Printer_margin_top=Last_valid_offsetY;
        }
    };
    TextWatcher textWatcherS=new TextWatcher() {

        @Override
        public void afterTextChanged(Editable s) {
        }

        @Override
        public void beforeTextChanged(CharSequence s, int start,
                                      int count, int after) {
        }

        @Override
        public void onTextChanged(CharSequence s, int start,
                                  int before, int count) {
            float new_scale;
            if(scale==null)return;
            Log.d("Fragment_Config_Printer", "Text changued:" + scale.getText());
            try {
                new_scale = Float.parseFloat(scale.getText().toString());
            }
            catch (NumberFormatException e){
                scale.setText(Float.toString(1));
                new_scale=1;
            }
            Last_valid_scale=new_scale;
            PassingDAta.cnf_Printer_scalePrint=Last_valid_scale;
        }
    };

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        fragment = this;
        view = inflater.inflate(R.layout.fragment_config_printer, container, false);
         offxetX = view.findViewById(R.id.config_printer_offsetX);
        offxetY = view.findViewById(R.id.config_printer_offsetY);
        scale = view.findViewById(R.id.config_printer_scale);
        Button btnTest = view.findViewById(R.id.config_printer_Test);
        Button btnRestaurar = view.findViewById(R.id.config_printer_Restore);
        Button btnDefaults = view.findViewById(R.id.config_printer_defaults);
        Button btnAceptar = view.findViewById(R.id.config_printer_Accept);
        Button btnCancel= view.findViewById(R.id.config_printer_cancel);

        offxetX.setText(Float.toString(PassingDAta.cnf_Printer_margin_left));
        offxetY.setText(Float.toString(PassingDAta.cnf_Printer_margin_top));
        scale.setText(Float.toString(PassingDAta.cnf_Printer_scalePrint));

        btnTest.setOnClickListener(onClickListener_Test);
        btnRestaurar.setOnClickListener(onClickListener_Restore);
        btnDefaults.setOnClickListener(onClickListener_Defaults);
        btnAceptar.setOnClickListener(onClickListener_Aceptar);
        btnCancel.setOnClickListener(onClickListener_Cancelar);

        offxetX.addTextChangedListener(textWatcherX);
        offxetY.addTextChangedListener(textWatcherY);
        scale.addTextChangedListener(textWatcherS);
        return view;
    }
    public ParteDeHoras GetParteDeHoras (ParteDeHoras pdh)
    {
        SaveTestParteOnClass(pdh);

        return pdh;
    }
    protected void SaveTestParteOnClass (ParteDeHoras pdh)
    {
        pdh.Clear();
        pdh.HI_Extra[0]="18:00";
        pdh.HI_Extra[1]="19:00";

        pdh.HF_Extra[0]="19:00";
        pdh.HF_Extra[1]="20:00";

        pdh.Cliente_Extra[0]="Cliente";
        pdh.Cliente_Extra[1]="Cliente";

        pdh.Observaciones_Extra[0]="Trabajo";
        pdh.Observaciones_Extra[1]="Trabajo";

        pdh.Total_Extra="02:00";
        pdh.NumeroParte="";
        pdh.Fecha="01/01/00";
        pdh.Operario=PassingDAta.cnf_Nombre_operario;

        for(int i=0;i<pdh.HI_Norm.length;i++)
        {
            pdh.HI_Norm[i]="00:00";
            pdh.HF_Norm[i]="00:00";
            pdh.Cliente_Norm[i]="Cliente";
            pdh.Observaciones_Norm[i]="Trabajo";
        }

        pdh.Total_Normales="00:00";
    }
}
