package com.orparga.partedehoras03;

import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.StrictMode;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.StringWriter;
import java.io.UnsupportedEncodingException;
import java.io.Writer;
import java.util.ArrayList;
import java.util.List;

import static com.orparga.partedehoras03.PassingDAta.WhatPrint;
import static com.orparga.partedehoras03.PassingDAta.cnf_Printer_margin_left;
import static com.orparga.partedehoras03.PassingDAta.cnf_Printer_margin_top;

public class ParteShare {

    public static boolean ShareFile (File file,Activity activity)

    {
        Uri uri= Uri.fromFile(file);
        Intent intent=new Intent();
        intent.setAction(Intent.ACTION_SEND);
        intent.setType("*/*");

        intent.putExtra(Intent.EXTRA_SUBJECT,"");
        intent.putExtra(android.content.Intent.EXTRA_TEXT, "");
        intent.putExtra(Intent.EXTRA_STREAM,uri);

        //those next two lines are a fuck so show that link for explanation
        //https://developer.android.com/reference/android/os/StrictMode.VmPolicy.Builder
        StrictMode.VmPolicy.Builder builder = new StrictMode.VmPolicy.Builder();
        StrictMode.setVmPolicy(builder.build());

        //continue happily
        activity.startActivity(Intent.createChooser(intent,"Share Cover Images"));

        return true;
    }
    public static boolean ShareFile (String[] fileNames,int NElements,Activity activity)

    {
        return ShareFile(fileNames,"",NElements,activity);
    }
    public static boolean ShareFile (String[] fileNames,String Email_coment_Subject,int NElements,Activity activity)

    {
        ArrayList<Uri> files=new ArrayList<Uri>();

        for(String path:fileNames )
        {
            File file=new File(path);
            Uri uri= Uri.fromFile(file);
            files.add(uri);
        }

        Intent intent=new Intent();
        intent.setAction(Intent.ACTION_SEND_MULTIPLE);
        intent.setType("*/*");

        intent.putExtra(Intent.EXTRA_SUBJECT, Email_coment_Subject);
        intent.putExtra(android.content.Intent.EXTRA_TEXT, "");
        intent.putParcelableArrayListExtra(Intent.EXTRA_STREAM, files);


        //those next two lines are a fuck so show that link for explanation
        //https://developer.android.com/reference/android/os/StrictMode.VmPolicy.Builder
        StrictMode.VmPolicy.Builder builder = new StrictMode.VmPolicy.Builder();
        StrictMode.setVmPolicy(builder.build());

        //continue happily
        activity.startActivity(Intent.createChooser(intent,activity.getResources().getString(R.string.share_intent_create_choser_coment)));

        return true;
    }

    public static void DrawParteOnCanvas (List<Box> lista_box,ParteDeHoras pdh,CanvasParaParte canvas,float scalePrint)
    {
        DrawParteOnCanvas(lista_box,pdh,canvas,scalePrint,CanvasParaParte.TYPE.SHARE);
    }
        public static void DrawParteOnCanvas (List<Box> lista_box,ParteDeHoras pdh,CanvasParaParte canvas,float scalePrint,CanvasParaParte.TYPE typeCanvas)
        {
        //*********Dibujar el parte en  el objeto paint**************************************************************************
        // **********************************************************************************************************************

        canvas.scalePrint=scalePrint;
            float defaultStrokeForUnderline=0.05f;
        canvas.defaultType= typeCanvas;
            switch (typeCanvas) {
                case PRINTER:
                    defaultStrokeForUnderline=0.05f;
                    break;
                case SHARE:
                    defaultStrokeForUnderline=0.2f;
                    break;
            }

        for(int i=0;i<lista_box.size();i++)
        {
            Box box=lista_box.get(i);
            switch (box.type) {
                case "basic":
                    if(WhatPrint== PassingDAta.whatPrintEnum.All) {
                        setTextSizeForWidth(canvas.paint,((float)box.right*scalePrint)-((float)box.left*scalePrint),box.text);
                        canvas.paint.setStrokeWidth(0.1f*scalePrint);
                        canvas.paint.setStyle(Paint.Style.FILL);
                        canvas.paint.setColor(Color.BLACK);
                        canvas.drawText(box.text, box.left, box.bottom);
                    }
                    break;
                case "underline":
                    canvas.paint.setStrokeWidth(defaultStrokeForUnderline*scalePrint);
                    canvas.paint.setColor(Color.BLACK);
                    if(WhatPrint== PassingDAta.whatPrintEnum.All) {
                        canvas.paint.setStyle(Paint.Style.STROKE);
                        canvas.drawLine(box.left, box.bottom, box.right);
                    }
                    canvas.paint.setStyle(Paint.Style.FILL);
                    if(!box.text.equals("")) {
                        if(WhatPrint== PassingDAta.whatPrintEnum.All) {
                            setTextSizeForWidth(canvas.paint, ((float) box.right * scalePrint) - ((float) box.left * scalePrint), box.text);
                            canvas.drawText(box.text, box.left, box.bottom);
                        }
                    }
                    else {
                        String FieldContent=pdh.GetFieldContent(box.name, box.index);

                        if(!FieldContent.equals("")) {
                            canvas.drawTextCentered(FieldContent,box.left,box.bottom,box.right);
                        }

                    }
                    break;
                case "table":
                    canvas.paint.setStrokeWidth(0.5f*scalePrint);
                    canvas.paint.setColor(Color.BLACK);
                    canvas.paint.setStyle(Paint.Style.STROKE);
                    if(WhatPrint== PassingDAta.whatPrintEnum.All) {
                        canvas.drawBox(box);
                    }
                    Column column;
                    canvas.paint.setStrokeWidth(0.3f*scalePrint);
                    for (int j=0;j<box.columns.size();j++)
                    {
                        column=box.columns.get(j);
                        Celd celd;
                        int k;
                        for(k=0;k<column.celds.size();k++)
                        {
                            celd=column.celds.get(k);
                            canvas.paint.setStyle(Paint.Style.FILL);
                            //Color del relleno del recuadro
                            canvas.paint.setColor(Color.rgb(celd.back_color.red,celd.back_color.green,celd.back_color.blue));
                            //Color de la linea de contorno del recuadro
                            canvas.paint.setColor(Color.rgb(celd.border_color.red,celd.border_color.green,celd.border_color.blue));
                            canvas.paint.setStyle(Paint.Style.STROKE);
                            if(WhatPrint== PassingDAta.whatPrintEnum.All) {
                                canvas.drawCeld(celd);
                            }
                            //Color del texto
                            canvas.paint.setColor(Color.BLACK);
                            canvas.paint.setStyle(Paint.Style.FILL);
                            if(!celd.label.text.equals("")) {

                                if(WhatPrint== PassingDAta.whatPrintEnum.All) {
                                    canvas.drawText(
                                            celd.label.text,
                                            (float) celd.label.left,
                                            (float) celd.label.bottom);
                                }
                            }
                            else {
                                String FieldContent=pdh.GetFieldContent(celd.name, celd.index);

                                if(FieldContent!=null)
                                if(!FieldContent.equals("")) {
                                    canvas.drawTextCentered(FieldContent,celd.left,celd.bottom-1,celd.right);
                                }

                            }
                        }
                    }
                    break;
                case "picture":

                    if(WhatPrint== PassingDAta.whatPrintEnum.All) {
                        if (PassingDAta.instalferlogo != null) {
                            canvas.drawBitmap(box,PassingDAta.instalferlogo);
                        }
                    }
                    break;
            }
        }
    }
    private static void setTextSizeForWidth(Paint paint, float desiredWidth,
                                            String text) {

        // Pick a reasonably large value for the test. Larger values produce
        // more accurate results, but may cause problems with hardware
        // acceleration. But there are workarounds for that, too; refer to
        // http://stackoverflow.com/questions/6253528/font-size-too-large-to-fit-in-cache
        final float testTextSize = 16f;

        // Get the bounds of the text, using our testTextSize.
        paint.setTextSize(testTextSize);
        Rect bounds = new Rect();
        paint.getTextBounds(text, 0, text.length(), bounds);

        // Calculate the desired size as a proportion of our testTextSize.
        float desiredTextSize = testTextSize * desiredWidth / bounds.width();

        // Set the paint for that size.
        paint.setTextSize(desiredTextSize);
    }

    //Under construccion... 18/04(2019
    public  static void CreateViewFromPDH (ParteDeHoras pdh, LinearLayout MainView)
    {
        Log.d("CreateViewFromPDH","Under Construccion");
        LinearLayout.LayoutParams relParentParam = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.MATCH_PARENT);
        MainView.setLayoutParams(relParentParam);

        // Create child ImageView
        ImageView imgView = new ImageView(MainView.getContext());
        LinearLayout.LayoutParams imgViewParams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        imgView.setLayoutParams(imgViewParams);
        imgView.setImageResource(R.drawable.instalferlogo);
        //imgViewParams.addRule(LinearLayout.CENTER_IN_PARENT);

        // Add child ImageView to parent RelativeLayout
        MainView.addView(imgView);
        MainView.setDrawingCacheEnabled(true);
        MainView.invalidate();
    }

    public static Bitmap CreatePictureFromPDH (ParteDeHoras pdh,Bitmap bitmap)
    { // setup initial color
        final int paintColor = Color.BLACK;
        // defines paint and canvas
        Paint drawPaint;

        //bitmap.setWidth(200);
        //bitmap.setHeight(200);

        Canvas canvas=new Canvas(bitmap);
        canvas.drawColor(Color.WHITE);
        Paint paint=new Paint();
        paint.setTextSize(100);
        paint.setColor(Color.RED);
        canvas.drawText("hola",100,100,paint);
        return bitmap;
    }
    public  static void ReadJson (Activity act, List<Box> lista_box, List<Area> lista_area)
    {
        JSONObject object;
        JSONArray json_array=new JSONArray();

        String FieldContent;
        Rect TextBounds=new Rect();
        Rect TextCentereds=new Rect();

        //Load Json resource****************************************************************************************************
        //**********************************************************************************************************************
        InputStream is = act.getResources().openRawResource(R.raw.instalfer_parte_atributes);
        Writer writer = new StringWriter();
        char[] buffer = new char[1024];
        try {
            Reader reader = new BufferedReader(new InputStreamReader(is, "UTF-8"));
            int n;
            while ((n = reader.read(buffer)) != -1) {
                writer.write(buffer, 0, n);
            }
            is.close();
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        String jsonString = writer.toString();


        try {
            object = new JSONObject(jsonString); //Creamos un objeto JSON a partir de la cadena

            if(lista_area!=null)
            {
                json_array = object.optJSONArray("areas"); //cogemos cada uno de los elementos dentro de la etiqueta "areas"

                for (int i = 0; i < json_array.length(); i++) {
                    lista_area.add(new Area(json_array.getJSONObject(i))); //creamos un objeto Box y lo insertamos en la lista
                }
            }
            if(lista_box!=null) {
                json_array = object.optJSONArray("boxes"); //cogemos cada uno de los elementos dentro de la etiqueta "boxes"

                for (int i = 0; i < json_array.length(); i++) {
                    lista_box.add(new Box(json_array.getJSONObject(i))); //creamos un objeto Box y lo insertamos en la lista
                }
            }
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
    }
    public static boolean ShareScreenShot (Activity act,View viewToShare) {
        String fileName = "shared.jpg";

        // create bitmap screen capture
        //        View v1 = act.getWindow().getDecorView().getRootView();
        //        v1.setDrawingCacheEnabled(true);
        //        Bitmap bitmap = Bitmap.createBitmap(v1.getDrawingCache());
        //        v1.setDrawingCacheEnabled(false);
        viewToShare.setDrawingCacheEnabled(true);
        Bitmap bitmap = Bitmap.createBitmap(viewToShare.getDrawingCache());
        viewToShare.setDrawingCacheEnabled(false);

        try {
            // Find the root of the external storage.
            // See http://developer.android.com/guide/topics/data/data-  storage.html#filesExternal

            File root = android.os.Environment.getExternalStorageDirectory();
            // tv.append("\nExternal file system root: "+root);

            // See http://stackoverflow.com/questions/3551821/android-write-to-sd-card-folder

            File dir = new File(root.getAbsolutePath() + "/share");
            if (dir.mkdirs()) {
                Log.d("", "Directory created");
            } else {
                Log.d("", "Directory not created");
            }
            File imageFile = new File(dir, fileName);
            //outputStream = new FileOutputStream(imageFile);
            FileOutputStream outputStream = new FileOutputStream(imageFile);
            int quality = 100;
            bitmap.compress(Bitmap.CompressFormat.JPEG, quality, outputStream);
            outputStream.flush();
            ShareFile(imageFile, act);
            outputStream.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            return false;
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }

        return true;

    }
}
