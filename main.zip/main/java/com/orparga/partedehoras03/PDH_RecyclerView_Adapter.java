package com.orparga.partedehoras03;

import android.graphics.Bitmap;
import android.graphics.Color;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;

import java.util.ArrayList;
import java.util.List;

public class PDH_RecyclerView_Adapter extends RecyclerView.Adapter<PDH_RecyclerView_Adapter.MyViewHolder> {
    private String[] pdhFileArray;

    // Provide a reference to the views for each data item
    // Complex data items may need more than one view per item, and
    // you provide access to all the views for a data item in a view holder
    public static class MyViewHolder extends RecyclerView.ViewHolder {
        // each data item is just a string in this case
        public LinearLayout linearLayout;
        public MyViewHolder(LinearLayout v) {
            super(v);
            linearLayout = v;
        }
    }

    // Provide a suitable constructor (depends on the kind of dataset)
    public PDH_RecyclerView_Adapter(String[] pdhFileArray) {
        this.pdhFileArray = pdhFileArray;
    }

    // Create new views (invoked by the layout manager)
    @Override
    public PDH_RecyclerView_Adapter.MyViewHolder onCreateViewHolder(ViewGroup parent,
                                                     int viewType) {
        // create a new view
        LinearLayout v = (LinearLayout) LayoutInflater.from(parent.getContext())
                .inflate(R.layout.share_parte_jpeg, parent, false);
        //...
        MyViewHolder vh = new MyViewHolder(v);
        return vh;
    }

    // Replace the contents of a view (invoked by the layout manager)
    @Override
    public void onBindViewHolder(MyViewHolder holder, int i) {
        // - get element from your dataset at this position
        // - replace the contents of the view with that element

        ParteDeHoras pdh=new ParteDeHoras();
        List<Box> lista_box = new ArrayList<>(); //la lista para el dibujo de las tablas y recuadros
        List<Area> lista_area = new ArrayList<>(); //la lista para el tamaño del parte de horas, etc...
        ParteShare.ReadJson(PassingDAta.activity, lista_box,lista_area);

        //Preparar el parte de horas a partir del nombre del archivo correspondiente al dia seleccionado************************
        //**********************************************************************************************************************
        FileHandling FH=new FileHandling();
        if(pdhFileArray!=null) {
            if(i<pdhFileArray.length) {
                if (!pdhFileArray[i].equals("")) {
                    FH.LoadParteFromFileToClass(pdhFileArray[i], PassingDAta.activity, pdh);
                    if (pdh != null) {
                        pdh.LoadFields();
                        if (lista_area != null)
                            if ((i = Area.SearchForName(lista_area, "page")) != -1) {
                                PassingDAta.cnf_ParteHeight_Bitmap = ((float) lista_area.get(i).bottom / (float) lista_area.get(i).right) * PassingDAta.cnf_ParteWidth_Bitmap;
                                PassingDAta.scalePrint_bmp = PassingDAta.cnf_ParteWidth_Bitmap / (float) lista_area.get(i).right;
                            }
                        final Bitmap bitmap = Bitmap.createBitmap((int) PassingDAta.cnf_ParteWidth_Bitmap, (int) PassingDAta.cnf_ParteHeight_Bitmap, Bitmap.Config.ARGB_8888);
                        CanvasParaParte canvasParaParte = new CanvasParaParte(bitmap);
                        canvasParaParte.drawColor(Color.WHITE);
                        PassingDAta.WhatPrint = PassingDAta.whatPrintEnum.All;
                        ParteShare.DrawParteOnCanvas(lista_box, pdh, canvasParaParte, PassingDAta.scalePrint_bmp);

                        ((ImageView)holder.linearLayout.findViewById(R.id.imageForPdH)).setImageBitmap(bitmap);
                        //holder.imageView.invalidate();
                    }
                }
            }
        }

    }

    // Return the size of your dataset (invoked by the layout manager)
    @Override
    public int getItemCount() {
        return PassingDAta.NDaysSelected;
    }
}
