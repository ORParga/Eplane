package com.orparga.partedehoras03;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.v4.app.DialogFragment;

public class Activity_Intent_CSV_Dialog_HN_HX extends DialogFragment {

    /* The activity that creates an instance of this dialog fragment must
     * implement this interface in order to receive event callbacks.
     * Each method passes the DialogFragment in case the host needs to query it. */
    public interface NoticeDialogListener {
        public void onTipoDeHoraSeleccionada(DialogFragment dialog);
    }
    // Use this instance of the interface to deliver action events
    NoticeDialogListener mListener;
    // Override the Fragment.onAttach() method to instantiate the NoticeDialogListener
    @Override
    public void onAttach(Context activity) {
        super.onAttach(activity);
        // Verify that the host activity implements the callback interface
        try {
            // Instantiate the NoticeDialogListener so we can send events to the host
            mListener = (NoticeDialogListener) activity;
        } catch (ClassCastException e) {
            // The activity doesn't implement the interface, throw exception
            throw new ClassCastException(activity.toString()
                    + " must implement onTipoDeHoraSeleccionada");
        }
    }
    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        //Inicializar las variables que leerá la clase llamante "Activity_Intent_CSV" al finalizar
        PassingDAta.CSV_Dialog_Accept=false;
        PassingDAta.CSV_Dialog_HX_HN=PassingDAta.HX_HN.HN;

        // Use the Builder class for convenient dialog construction
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setTitle(R.string.AIC_HX_HX_Tittle);
        builder.setItems(R.array.AIC_HX_HN, new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                // The 'which' argument contains the index position
                // of the selected item
                switch (which)
                {
                    case 0:
                        PassingDAta.CSV_Dialog_HX_HN= PassingDAta.HX_HN.HN;
                        break;
                    case 1:
                        PassingDAta.CSV_Dialog_HX_HN= PassingDAta.HX_HN.HX;
                        break;
                }
                mListener.onTipoDeHoraSeleccionada(Activity_Intent_CSV_Dialog_HN_HX.this);
            }
        });
        // Create the AlertDialog object and return it
        return builder.create();
    }
}
