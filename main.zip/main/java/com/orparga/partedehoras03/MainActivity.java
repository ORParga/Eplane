package com.orparga.partedehoras03;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.Fragment;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;
import android.print.PrintManager;

public class MainActivity extends AppCompatActivity implements FragmentParte02.OnFragmentInteractionListener,ActivityCompat.OnRequestPermissionsResultCallback  {

    FragmentParte02 fragment;
    DatePickerDialog.OnDateSetListener date;
    private int mRadioButtonChoice = 2; // The default (no choice).

    //Variables para el control de los calendarios
    private Calendar SelectedDate;
    private SimpleDateFormat sdfDayOfWeek,sdfDayOfYear;

    //Variables para el manejo de archivos
    FileHandling FH;
    String NombreDeArchivo;
    final int REQUEST_WRITE_PERMISSION = 786;
    boolean TengoPermiso=false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        fragment = (FragmentParte02) getSupportFragmentManager().findFragmentById(R.id.fragmentParte02_id);
        PassingDAta.instalferlogo = BitmapFactory.decodeResource(getResources(), R.drawable.instalferlogo);
        SelectedDate=Calendar.getInstance();
        SelectedDate.setTimeZone(TimeZone.getTimeZone("GMT"));

        Locale Spain=new Locale("es","ES");
        sdfDayOfWeek = new SimpleDateFormat("EEEE",Spain);
        sdfDayOfYear = new SimpleDateFormat("dd 'de' MMMM 'de' yyyy",Spain);
        sdfDayOfWeek.setTimeZone(TimeZone.getTimeZone("GMT +0"));
        sdfDayOfYear.setTimeZone(TimeZone.getTimeZone("GMT +0"));

        PassingDAta.Load_SharedPreferences(this);
        IniListeners();
        SetDateInTittle();
        //get the received intent
        Intent receivedIntent = getIntent();

        if(receivedIntent!= null) {
            //get the action
            String receivedAction = receivedIntent.getAction();
            //find out what we are dealing with
            String receivedType = receivedIntent.getType();

            if(receivedAction!=null)
            {

                //make sure it's an action and type we can handle
                if (receivedAction.equals(Intent.ACTION_SEND)) {

                    if (receivedType.startsWith("text/")) {
                        if(receivedType.endsWith("csv"))
                        {
                            DebugMessage("Intent_CSV");

                            Intent Intent_CSV = new Intent(this, Activity_Intent_CSV.class);
                            PassingDAta.fromActivity= PassingDAta.fromActivityEnum.Intent_CSV;
                            PassingDAta.gleeo_Intent=receivedIntent;

                            startActivity(Intent_CSV);
                            //content is being shared
                        }
                    }


                } else if (receivedAction.equals(Intent.ACTION_MAIN)) {
                    Toast.makeText(this, "" + getResources().getString(R.string.app_altermative_name)+" launched as MAIN.",
                            Toast.LENGTH_SHORT).show();
                    //app has been launched directly, not from share list
                }
                else {
                    Toast.makeText(this, "" + getResources().getString(R.string.app_altermative_name)+" not launched as MAIN nor SEND",
                            Toast.LENGTH_SHORT).show();

                }
            }
            if(receivedType!=null)
            {

            }

        }
    }


    @Override
    protected void onResume() {
        super.onResume();


        ImageButton btnPaste=findViewById(R.id.btn_Paste);
            if(PassingDAta.ThereIsParteInClipboard()){
                btnPaste.setImageResource(R.mipmap.ic_paste);
            }
            else{
                btnPaste.setImageResource(R.mipmap.ic_paste_dis);
            }
            btnPaste.invalidate();
            switch (PassingDAta.fromActivity) {
                case Autofill:
                    break;
                case Month:
                    if(PassingDAta.thereIsAnyDayClicked)
                    {
                        SelectedDate.setTimeZone(TimeZone.getTimeZone("GMT"));
                        SelectedDate.set(PassingDAta.SelectedYear,PassingDAta.SelectedMonth,PassingDAta.SelectedDayOfMonth+1);

                        SetDateInTittle();
                    }
                    break;
                case None:
                    break;
                    }

    }
    protected void SetDateInTittle ()
    {
        Date date=SelectedDate.getTime();
        String strDateWeek=sdfDayOfWeek.format(date);
        strDateWeek = strDateWeek.substring(0, 1).toUpperCase() + strDateWeek.substring(1);
        String strDateYear=sdfDayOfYear.format(date);

        TextView dayOfTheWeek=(TextView)findViewById(R.id.lblDayWeek);
        TextView dayOfTheYear=(TextView)findViewById(R.id.lblDayOfTheYear);
        dayOfTheWeek.setText(strDateWeek);
        dayOfTheYear.setText(strDateYear);
        dayOfTheWeek.refreshDrawableState();
        dayOfTheYear.refreshDrawableState();
    }

    protected void IniListeners ()
    {

        date = new DatePickerDialog.OnDateSetListener() {

            @Override
            public void onDateSet(DatePicker view, int year, int mes,
                                  int dia) {
                fragment.CargarPartePorFecha(year,mes,dia);

                SelectedDate.setTimeZone(TimeZone.getTimeZone("GMT"));
                SelectedDate.set(year,mes,dia);

                SetDateInTittle();
            }

        };
    }
    public void onClick_Prev (View v)
    {
        int day=SelectedDate.get(Calendar.DATE)-1;
        SelectedDate.set( Calendar.DATE,day);

        fragment.CargarPartePorFecha(SelectedDate);
        SetDateInTittle();
    }
    public void onClick_Next (View v)
    {
        int day=SelectedDate.get(Calendar.DATE)+1;
        SelectedDate.set( Calendar.DATE,day);

        fragment.CargarPartePorFecha(SelectedDate);
        SetDateInTittle();

    }
    public void onClick_Calendar (View v)
    {
        DebugMessage("action_Calendar");
        Intent Month = new Intent(this, MonthActivity.class);
        PassingDAta.fromActivity= PassingDAta.fromActivityEnum.Month;
        startActivity(Month);

    }
    public void onClick_AutoFill (View v)
    {
        DebugMessage("action_autofill");
        Intent Autofill = new Intent(this, AutofillActivity.class);
        PassingDAta.fromActivity= PassingDAta.fromActivityEnum.Autofill;
        startActivity(Autofill);
    }
    public void onClick_Printer (View v)
    {
        ParteDeHoras pdh=new ParteDeHoras();
        fragment.GetParteDeHoras(pdh);
        android.print.PrintManager printManager = (PrintManager) this
                .getSystemService(Context.PRINT_SERVICE);

        String jobName = this.getString(R.string.app_name) +
                " Document";

        printManager.print(jobName, new PrintParteDeHorasAdapter(this,pdh),
                null);
        DebugMessage("action_Printer");
    }
    public void onClick_Share (View v)
    {
        DebugMessage("action_Share");
        requestPermission();
    }
    public void onClick_Config (View v)
    {
        DebugMessage("En pruebas action_Config");
        Intent Config = new Intent(this, Activity_Config.class);
        PassingDAta.fromActivity= PassingDAta.fromActivityEnum.Main;
        startActivity(Config);
    }
    public void onClick_Instalfer (View v)
    {
        Toast.makeText(this,"Boton Instalfer en pruebas...CUIDADO",Toast.LENGTH_LONG).show();
        Intent Send_toInstalfer = new Intent(this, Activity_Send_to_Instalfer.class);
        PassingDAta.fromActivity= PassingDAta.fromActivityEnum.Main;
        startActivity(Send_toInstalfer);

    }
    public void onClick_Copy (View v){
        ParteDeHoras pdh_local=new ParteDeHoras();

        fragment.GetParteDeHoras(pdh_local);
        PassingDAta.SendParteToClipboard(pdh_local);
        Toast.makeText(this,"Parte "+PassingDAta.GetParteFromClipboard().Fecha+" copiado.",Toast.LENGTH_LONG).show();
    }
    public void onClick_Paste(View v){
        ParteDeHoras pdhorasEnClipboard=PassingDAta.GetParteFromClipboard();


        if(pdhorasEnClipboard!=null) {
            Toast.makeText(this, "Parte "+pdhorasEnClipboard.Fecha+" pegado.", Toast.LENGTH_LONG).show();
            fragment.CargarParte_desde_Parte(pdhorasEnClipboard);
            pdhorasEnClipboard.Fecha=MiFecha.CalendarToString(SelectedDate);
        }
        else
        {
            Toast.makeText(this, "No hay Parte en el portapapeles. Paste no implementado", Toast.LENGTH_LONG).show();

        }
    }
    public void onClick_SelectDate (View v)
    {
        new DatePickerDialog(this, date,
                SelectedDate.get(Calendar.YEAR), SelectedDate.get(Calendar.MONTH),
                SelectedDate.get(Calendar.DAY_OF_MONTH)).show();
    }

    //onTestImterface
    // funcion de prueba para testear la comunicacion entre Activity y Fragment
    @Override
    public void onTestImterface(int choice) {
    // Keep the radio button choice to pass it back to the fragment.
        mRadioButtonChoice = choice;
        //Toast.makeText(this, "MainActivity.onTestImterface() Choice is " + Integer.toString(choice),
        //        Toast.LENGTH_SHORT).show();
    }
    //Implementacion de la interfaz "OnRequestPermissionsResultCallback" (1 de 2)
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        if (requestCode == REQUEST_WRITE_PERMISSION && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            TengoPermiso=true;
            ShareCalback();
        }
        else
        {
            TengoPermiso=false;
            ShareCalback();
        }
    }

    //Implementacion de la interfaz "OnRequestPermissionsResultCallback" (2 de 2)
    private void requestPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            requestPermissions(new String[]{android.Manifest.permission.WRITE_EXTERNAL_STORAGE}, REQUEST_WRITE_PERMISSION);
        } else {
            TengoPermiso=true;
            ShareCalback();
        }
    }

    //Metodo callback para ser invocado tras haber adquirido permiso de escritura en sistema de archivos
    private void ShareCalback ()
    {

        final Handler handler;
        final AlertDialog.Builder builder;
        final AlertDialog dialog;

        if(TengoPermiso)
            ParteShare.ShareScreenShot(this,fragment.getView());
        else
        {
            handler = new Handler();
            builder = new AlertDialog.Builder(this);
            builder.setMessage("La app "+ getResources().getString( R.string.alternative_app_name)+" necesita permiso de acceso a archivos para poder compartir el parte de horas");
            dialog = builder.create();
            dialog.show();
            handler.postDelayed(new Runnable() {
                public void run() {
                    dialog.dismiss();
                }
            }, 3000); // Dismiss in 3 Seconds
        }
    }
    public void DebugMessage(String message)
    {
        Toast.makeText(this, message,
                Toast.LENGTH_SHORT).show();
        Log.d("", message);
    }
}
